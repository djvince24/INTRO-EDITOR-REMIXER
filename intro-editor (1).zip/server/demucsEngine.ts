import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { execSync } from 'node:child_process';
import { Worker } from 'node:worker_threads';
import * as ort from 'onnxruntime-node';

export type DemucsModelVariant = 'htdemucs' | 'htdemucs_ft';
export type DemucsModelPreference = 'auto' | DemucsModelVariant;
export type StemName = 'drums' | 'bass' | 'other' | 'vocals';

export const STEM_NAMES: StemName[] = ['drums', 'bass', 'other', 'vocals'];

const CACHE_ROOT = path.resolve(process.env.DEMUCS_CACHE_DIR || '/tmp/demucs-cache');
const MODELS_DIR = path.join(CACHE_ROOT, 'models');
const STEMS_DIR = path.join(CACHE_ROOT, 'stems');
const JOBS_DIR = path.join(CACHE_ROOT, 'jobs');

const MODEL_SOURCES: Record<
  DemucsModelVariant,
  Array<{ key: string; filename: string; url: string }>
> = {
  htdemucs: [
    {
      key: 'htdemucs',
      filename: 'htdemucs_fp16weights.onnx',
      url: 'https://huggingface.co/StemSplitio/htdemucs-onnx/resolve/main/htdemucs_fp16weights.onnx',
    },
  ],
  htdemucs_ft: [
    {
      key: 'drums',
      filename: 'htdemucs_ft_drums_fp16weights.onnx',
      url: 'https://huggingface.co/StemSplitio/htdemucs-ft-onnx/resolve/main/htdemucs_ft_drums_fp16weights.onnx',
    },
    {
      key: 'bass',
      filename: 'htdemucs_ft_bass_fp16weights.onnx',
      url: 'https://huggingface.co/StemSplitio/htdemucs-ft-onnx/resolve/main/htdemucs_ft_bass_fp16weights.onnx',
    },
    {
      key: 'other',
      filename: 'htdemucs_ft_other_fp16weights.onnx',
      url: 'https://huggingface.co/StemSplitio/htdemucs-ft-onnx/resolve/main/htdemucs_ft_other_fp16weights.onnx',
    },
    {
      key: 'vocals',
      filename: 'htdemucs_ft_vocals_fp16weights.onnx',
      url: 'https://huggingface.co/StemSplitio/htdemucs-ft-onnx/resolve/main/htdemucs_ft_vocals_fp16weights.onnx',
    },
  ],
};

export interface HardwareCapabilities {
  cpuCores: number;
  totalMemMb: number;
  freeMemMb: number;
  hasGpu: boolean;
  gpuName: string | null;
  executionProviders: string[];
  recommendedModel: DemucsModelVariant;
  cachedModels: string[];
}

export interface StemMetric {
  stem: StemName;
  peakLinear: number;
  peakDbfs: number;
  rms: number;
  clippedSamples: number;
  isSilent: boolean;
  phaseCorrelation: number;
}

export interface StemQualityReport {
  syncVerified: boolean;
  maxDriftSamples: number;
  sampleRate: number;
  lengthSamples: number;
  durationSec: number;
  clippingDetected: boolean;
  totalClippedSamples: number;
  missingAudioDetected: boolean;
  phaseIssueDetected: boolean;
  reconstructionSnrDb: number;
  maxResidualError: number;
  reconstructedPeakLinear: number;
  reconstructedPhaseCorrelation: number;
  stems: Record<StemName, StemMetric>;
  warnings: string[];
  passed: boolean;
}

export interface DemucsJobState {
  jobId: string;
  cacheKey: string;
  audioHash: string;
  modelPreference: DemucsModelPreference;
  resolvedModel: DemucsModelVariant;
  providerUsed: string;
  sampleRate: number;
  channels: number;
  lengthSamples: number;
  totalBytesExpected: number;
  bytesReceived: number;
  status: 'uploading' | 'queued' | 'downloading_model' | 'separating' | 'verifying' | 'completed' | 'error';
  progressPct: number;
  stage: string;
  error: string | null;
  createdAt: number;
  updatedAt: number;
  qc: StemQualityReport | null;
  fromCache: boolean;
}

const jobs = new Map<string, DemucsJobState>();
let detectedCapsCache: HardwareCapabilities | null = null;
let workerInstance: Worker | null = null;
let workerQueue: Promise<void> = Promise.resolve();

function getDemucsWorker(): Worker {
  if (!workerInstance) {
    const workerPath = path.resolve(process.cwd(), 'server/demucsWorker.mjs');
    workerInstance = new Worker(workerPath);
    workerInstance.on('exit', () => {
      workerInstance = null;
    });
  }
  return workerInstance;
}

let lastCleanupAt = 0;

async function ensureDirs(): Promise<void> {
  await fsp.mkdir(MODELS_DIR, { recursive: true });
  await fsp.mkdir(STEMS_DIR, { recursive: true });
  await fsp.mkdir(JOBS_DIR, { recursive: true });

  const legacyPath = '/tmp/htdemucs_fp16weights.onnx';
  const targetPath = path.join(MODELS_DIR, 'htdemucs_fp16weights.onnx');
  if (fs.existsSync(legacyPath) && !fs.existsSync(targetPath)) {
    try {
      await fsp.rename(legacyPath, targetPath);
    } catch {
      // Ignore
    }
  }

  const now = Date.now();
  if (now - lastCleanupAt > 5 * 60 * 1000) {
    lastCleanupAt = now;
    try {
      const entries = await fsp.readdir(JOBS_DIR, { withFileTypes: true });
      for (const entry of entries) {
        if (!entry.isDirectory()) continue;
        const jobPath = path.join(JOBS_DIR, entry.name);
        const st = await fsp.stat(jobPath).catch(() => null);
        if (st && now - st.mtimeMs > 20 * 60 * 1000 && !jobs.has(entry.name)) {
          await fsp.rm(jobPath, { recursive: true, force: true }).catch(() => {});
        }
      }
    } catch {
      // Ignore cleanup failures
    }
  }
}

export async function detectHardwareCapabilities(): Promise<HardwareCapabilities> {
  await ensureDirs();

  if (detectedCapsCache) {
    const cachedFiles = fs.existsSync(MODELS_DIR) ? fs.readdirSync(MODELS_DIR) : [];
    return {
      ...detectedCapsCache,
      freeMemMb: Math.round(os.freemem() / (1024 * 1024)),
      cachedModels: cachedFiles.filter((f) => f.endsWith('.onnx')),
    };
  }

  const cpuCores = Math.max(1, os.cpus().length);
  const totalMemMb = Math.round(os.totalmem() / (1024 * 1024));
  const freeMemMb = Math.round(os.freemem() / (1024 * 1024));

  let hasGpu = false;
  let gpuName: string | null = null;
  let cudaAvailable = false;
  try {
    const backends = ort.listSupportedBackends();
    cudaAvailable = Array.isArray(backends) && backends.some((b) => b.name === 'cuda' && b.bundled);
  } catch {
    cudaAvailable = false;
  }

  if (cudaAvailable) {
    try {
      const out = execSync('nvidia-smi --query-gpu=name --format=csv,noheader', {
        timeout: 1500,
        stdio: ['ignore', 'pipe', 'ignore'],
      })
        .toString()
        .trim();
      if (out) {
        hasGpu = true;
        gpuName = out.split('\n')[0].trim();
      }
    } catch {
      hasGpu = false;
    }
  }

  const executionProviders = hasGpu ? ['cuda', 'cpu'] : ['cpu'];
  const recommendedModel: DemucsModelVariant =
    hasGpu || (cpuCores >= 8 && totalMemMb >= 12000) ? 'htdemucs_ft' : 'htdemucs';

  const cachedFiles = fs.existsSync(MODELS_DIR) ? fs.readdirSync(MODELS_DIR) : [];

  detectedCapsCache = {
    cpuCores,
    totalMemMb,
    freeMemMb,
    hasGpu,
    gpuName,
    executionProviders,
    recommendedModel,
    cachedModels: cachedFiles.filter((f) => f.endsWith('.onnx')),
  };

  return detectedCapsCache;
}

export async function resolveModelVariant(
  pref: DemucsModelPreference
): Promise<{ model: DemucsModelVariant; caps: HardwareCapabilities }> {
  const caps = await detectHardwareCapabilities();
  const model = pref === 'auto' ? caps.recommendedModel : pref;
  return { model, caps };
}

export function makeCacheKey(audioHash: string, model: DemucsModelVariant): string {
  const safeHash = audioHash.replace(/[^a-fA-F0-9]/g, '').slice(0, 64);
  return `${safeHash}_${model}`;
}

async function ensureModelDownloaded(
  filename: string,
  url: string,
  label: string,
  onProgress: (pct: number, stage: string) => void
): Promise<string> {
  await ensureDirs();
  const destPath = path.join(MODELS_DIR, filename);

  if (fs.existsSync(destPath)) {
    const stat = await fsp.stat(destPath);
    if (stat.size > 50 * 1024 * 1024) {
      return destPath;
    }
  }

  const tmpPath = `${destPath}.download.${Date.now()}.tmp`;
  onProgress(2, `Downloading ${label} ONNX weights...`);

  const response = await fetch(url, { redirect: 'follow' });
  if (!response.ok || !response.body) {
    throw new Error(`Failed to download Demucs model ${filename} (HTTP ${response.status})`);
  }

  const totalBytes = Number(response.headers.get('content-length') || '0');
  const reader = response.body.getReader();
  const fileStream = fs.createWriteStream(tmpPath);

  let received = 0;
  let lastReportedPct = -1;

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!fileStream.write(value)) {
        await new Promise<void>((resolve) => fileStream.once('drain', resolve));
      }
      received += value.byteLength;
      if (totalBytes > 0) {
        const pct = Math.min(99, Math.round((received / totalBytes) * 100));
        if (pct !== lastReportedPct && pct % 4 === 0) {
          lastReportedPct = pct;
          onProgress(
            Math.max(2, Math.round(pct * 0.2)),
            `Downloading ${label} (${pct}%)...`
          );
        }
      }
    }
    await new Promise<void>((resolve, reject) => {
      fileStream.end(() => resolve());
      fileStream.on('error', reject);
    });
    await fsp.rename(tmpPath, destPath);
  } catch (err) {
    fileStream.destroy();
    await fsp.unlink(tmpPath).catch(() => {});
    throw err;
  }

  return destPath;
}

export async function checkStemCache(
  audioHash: string,
  pref: DemucsModelPreference
): Promise<{
  cached: boolean;
  cacheKey: string;
  resolvedModel: DemucsModelVariant;
  meta: {
    sampleRate: number;
    lengthSamples: number;
    modelUsed: DemucsModelVariant;
    providerUsed: string;
    qc: StemQualityReport;
  } | null;
}> {
  await ensureDirs();
  const { model } = await resolveModelVariant(pref);
  const cacheKey = makeCacheKey(audioHash, model);
  const dir = path.join(STEMS_DIR, cacheKey);
  const metaPath = path.join(dir, 'meta.json');

  if (!fs.existsSync(metaPath)) {
    return { cached: false, cacheKey, resolvedModel: model, meta: null };
  }

  const allExist = STEM_NAMES.every((s) => fs.existsSync(path.join(dir, `${s}.f32`)));
  if (!allExist) {
    return { cached: false, cacheKey, resolvedModel: model, meta: null };
  }

  try {
    const raw = await fsp.readFile(metaPath, 'utf-8');
    const meta = JSON.parse(raw);
    return { cached: true, cacheKey, resolvedModel: model, meta };
  } catch {
    return { cached: false, cacheKey, resolvedModel: model, meta: null };
  }
}

export async function createDemucsJob(params: {
  audioHash: string;
  modelPreference: DemucsModelPreference;
  sampleRate: number;
  channels: number;
  lengthSamples: number;
}): Promise<DemucsJobState> {
  await ensureDirs();
  const { model, caps } = await resolveModelVariant(params.modelPreference);
  const cacheKey = makeCacheKey(params.audioHash, model);
  const jobId = crypto.randomUUID();
  const totalBytesExpected = params.lengthSamples * 2 * 4;

  const cacheHit = await checkStemCache(params.audioHash, params.modelPreference);
  if (cacheHit.cached && cacheHit.meta) {
    const state: DemucsJobState = {
      jobId,
      cacheKey,
      audioHash: params.audioHash,
      modelPreference: params.modelPreference,
      resolvedModel: model,
      providerUsed: cacheHit.meta.providerUsed,
      sampleRate: cacheHit.meta.sampleRate,
      channels: 2,
      lengthSamples: cacheHit.meta.lengthSamples,
      totalBytesExpected,
      bytesReceived: totalBytesExpected,
      status: 'completed',
      progressPct: 100,
      stage: `Loaded cached ${model} 4-stem separation`,
      error: null,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      qc: cacheHit.meta.qc,
      fromCache: true,
    };
    jobs.set(jobId, state);
    return state;
  }

  const jobDir = path.join(JOBS_DIR, jobId);
  await fsp.mkdir(jobDir, { recursive: true });
  const uploadFile = path.join(jobDir, 'input.f32');
  const fh = await fsp.open(uploadFile, 'w');
  await fh.truncate(totalBytesExpected);
  await fh.close();

  const state: DemucsJobState = {
    jobId,
    cacheKey,
    audioHash: params.audioHash,
    modelPreference: params.modelPreference,
    resolvedModel: model,
    providerUsed: caps.hasGpu ? 'CUDA GPU' : `CPU (${caps.cpuCores} threads)`,
    sampleRate: params.sampleRate,
    channels: params.channels,
    lengthSamples: params.lengthSamples,
    totalBytesExpected,
    bytesReceived: 0,
    status: 'uploading',
    progressPct: 0,
    stage: 'Uploading audio for Demucs separation...',
    error: null,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    qc: null,
    fromCache: false,
  };
  jobs.set(jobId, state);
  return state;
}

export async function appendJobChunk(
  jobId: string,
  offset: number,
  chunk: Buffer
): Promise<DemucsJobState> {
  const job = jobs.get(jobId);
  if (!job) throw new Error('Demucs job not found');
  if (offset < 0 || offset + chunk.byteLength > job.totalBytesExpected) {
    throw new Error('Upload chunk offset out of bounds');
  }
  const uploadFile = path.join(JOBS_DIR, jobId, 'input.f32');
  const fh = await fsp.open(uploadFile, 'r+');
  try {
    await fh.write(chunk, 0, chunk.byteLength, offset);
  } finally {
    await fh.close();
  }
  job.bytesReceived = Math.min(job.totalBytesExpected, job.bytesReceived + chunk.byteLength);
  job.updatedAt = Date.now();
  return job;
}

export function getDemucsJob(jobId: string): DemucsJobState | null {
  return jobs.get(jobId) ?? null;
}

export async function cancelDemucsJob(jobId: string): Promise<void> {
  const job = jobs.get(jobId);
  if (job && job.status === 'uploading') {
    jobs.delete(jobId);
    const jobDir = path.join(JOBS_DIR, jobId);
    await fsp.rm(jobDir, { recursive: true, force: true }).catch(() => {});
  }
}

export function getStemFilePath(cacheKey: string, stem: StemName): string {
  return path.join(STEMS_DIR, cacheKey, `${stem}.f32`);
}

function runWorkerTask(
  job: DemucsJobState,
  uploadFile: string,
  cacheDir: string,
  modelPaths: Record<string, string>,
  caps: HardwareCapabilities
): Promise<{ providerUsed: string; qc: StemQualityReport }> {
  return new Promise((resolve, reject) => {
    const worker = getDemucsWorker();

    const cleanup = () => {
      worker.off('message', onMsg);
      worker.off('error', onErr);
    };

    const onMsg = (msg: {
      type: string;
      jobId: string;
      status?: DemucsJobState['status'];
      pct?: number;
      stage?: string;
      providerUsed?: string;
      qc?: StemQualityReport;
      error?: string;
    }) => {
      if (msg.jobId !== job.jobId) return;
      if (msg.type === 'progress') {
        if (msg.status) job.status = msg.status;
        if (msg.pct !== undefined) job.progressPct = msg.pct;
        if (msg.stage) job.stage = msg.stage;
        job.updatedAt = Date.now();
      } else if (msg.type === 'done') {
        cleanup();
        resolve({ providerUsed: msg.providerUsed!, qc: msg.qc! });
      } else if (msg.type === 'error') {
        cleanup();
        reject(new Error(msg.error || 'Demucs worker failed.'));
      }
    };

    const onErr = (err: Error) => {
      cleanup();
      reject(err);
    };

    worker.on('message', onMsg);
    worker.on('error', onErr);
    worker.postMessage({
      jobId: job.jobId,
      uploadFile,
      cacheDir,
      sampleRate: job.sampleRate,
      lengthSamples: job.lengthSamples,
      resolvedModel: job.resolvedModel,
      modelPaths,
      caps,
    });
  });
}

export function startDemucsJob(jobId: string): DemucsJobState {
  const job = jobs.get(jobId);
  if (!job) throw new Error('Demucs job not found');
  if (job.status !== 'uploading' && job.status !== 'queued') {
    return job;
  }

  job.status = 'queued';
  job.progressPct = 1;
  job.stage = `Queued for ${job.resolvedModel} 4-stem separation...`;
  job.updatedAt = Date.now();

  workerQueue = workerQueue.then(async () => {
    const jobDir = path.join(JOBS_DIR, jobId);
    const uploadFile = path.join(jobDir, 'input.f32');
    try {
      const caps = await detectHardwareCapabilities();

      job.status = 'downloading_model';
      const specs = MODEL_SOURCES[job.resolvedModel];
      const modelPaths: Record<string, string> = {};

      for (let i = 0; i < specs.length; i++) {
        const spec = specs[i];
        modelPaths[spec.key] = await ensureModelDownloaded(
          spec.filename,
          spec.url,
          `${job.resolvedModel} (${spec.key})`,
          (pct, stage) => {
            job.progressPct = Math.min(20, Math.round(((i + pct / 20) / specs.length) * 20));
            job.stage = stage;
            job.updatedAt = Date.now();
          }
        );
      }

      job.status = 'separating';
      job.progressPct = 22;
      job.stage = `Running ${job.resolvedModel} 4-stem separation...`;
      job.updatedAt = Date.now();

      const cacheDir = path.join(STEMS_DIR, job.cacheKey);
      const { providerUsed, qc } = await runWorkerTask(
        job,
        uploadFile,
        cacheDir,
        modelPaths,
        caps
      );

      job.providerUsed = providerUsed;
      job.qc = qc;
      job.status = 'completed';
      job.progressPct = 100;
      job.stage = `${job.resolvedModel} 4-stem separation complete (SNR ${qc.reconstructionSnrDb.toFixed(1)} dB)`;
      job.updatedAt = Date.now();
    } catch (err) {
      job.status = 'error';
      job.error =
        err instanceof Error ? err.message : 'Demucs stem separation failed unexpectedly.';
      job.stage = `Demucs error: ${job.error}`;
      job.updatedAt = Date.now();
    } finally {
      await fsp.rm(jobDir, { recursive: true, force: true }).catch(() => {});
    }
  });

  return job;
}
