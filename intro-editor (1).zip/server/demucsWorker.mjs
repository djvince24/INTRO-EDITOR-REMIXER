import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { parentPort } from 'node:worker_threads';
import * as ort from 'onnxruntime-node';

const STEM_NAMES = ['drums', 'bass', 'other', 'vocals'];
const DEMUCS_SAMPLE_RATE = 44100;
const DEMUCS_SEGMENT_SAMPLES = 343980;
const DEMUCS_OVERLAP_SAMPLES = Math.floor(DEMUCS_SEGMENT_SAMPLES / 4);
const DEMUCS_STRIDE_SAMPLES = DEMUCS_SEGMENT_SAMPLES - DEMUCS_OVERLAP_SAMPLES;

let cachedHtdemucsSession = null;
let cachedHtdemucsProvider = 'CPUExecutionProvider';

function postProgress(jobId, status, pct, stage) {
  parentPort?.postMessage({ type: 'progress', jobId, status, pct, stage });
}

function makeDemucsTransitionWindow(length, overlap) {
  const win = new Float32Array(length);
  win.fill(1);
  const safeOverlap = Math.min(overlap, Math.floor(length / 2));
  for (let i = 0; i < safeOverlap; i++) {
    const fade = safeOverlap > 1 ? i / (safeOverlap - 1) : 1;
    win[i] = fade;
    win[length - 1 - i] = fade;
  }
  return win;
}

function sinc(x) {
  if (Math.abs(x) < 1e-8) return 1;
  const px = Math.PI * x;
  return Math.sin(px) / px;
}

function lanczosKernel(x, a = 3) {
  const ax = Math.abs(x);
  if (ax >= a) return 0;
  return sinc(x) * sinc(x / a);
}

function resampleChannelLanczos(input, srcRate, dstRate, exactDstLen) {
  if (srcRate === dstRate && input.length === exactDstLen) {
    return new Float32Array(input);
  }
  const out = new Float32Array(exactDstLen);
  const ratio = srcRate / dstRate;
  const a = 3;
  const scale = ratio > 1 ? 1 / ratio : 1;
  const support = ratio > 1 ? a * ratio : a;
  const srcLen = input.length;

  for (let i = 0; i < exactDstLen; i++) {
    const center = i * ratio;
    const left = Math.max(0, Math.floor(center - support));
    const right = Math.min(srcLen - 1, Math.ceil(center + support));
    let sum = 0;
    let wSum = 0;
    for (let j = left; j <= right; j++) {
      const w = lanczosKernel((j - center) * scale, a);
      sum += input[j] * w;
      wSum += w;
    }
    out[i] = wSum > 1e-8 ? sum / wSum : 0;
  }
  return out;
}

async function createOrtSessionWithFallback(modelPath, caps) {
  // Reserve 1 core for Express/Vite HTTP serving so API polling & capabilities never stall
  const workerThreads = Math.max(1, Math.min(3, caps.cpuCores > 2 ? caps.cpuCores - 1 : caps.cpuCores));
  const baseOptions = {
    graphOptimizationLevel: 'all',
    intraOpNumThreads: workerThreads,
    interOpNumThreads: 1,
    enableCpuMemArena: false,
    enableMemPattern: false,
  };

  if (caps.hasGpu) {
    try {
      const session = await ort.InferenceSession.create(modelPath, {
        ...baseOptions,
        executionProviders: ['cuda', 'cpu'],
      });
      return { session, provider: 'CUDA GPU (with CPU fallback)' };
    } catch {
      // Fall back to CPU
    }
  }

  const session = await ort.InferenceSession.create(modelPath, {
    ...baseOptions,
    executionProviders: ['cpu'],
  });
  return { session, provider: `CPU (${workerThreads} threads)` };
}

function computeQualityControl(origL, origR, stems, sampleRate) {
  const length = origL.length;
  const durationSec = length / sampleRate;
  const warnings = [];

  let syncVerified = true;
  let maxDriftSamples = 0;
  for (const name of STEM_NAMES) {
    const st = stems[name];
    if (st.L.length !== length || st.R.length !== length) {
      syncVerified = false;
      maxDriftSamples = Math.max(
        maxDriftSamples,
        Math.abs(st.L.length - length),
        Math.abs(st.R.length - length)
      );
    }
  }
  if (!syncVerified) {
    warnings.push(`Stem length drift detected (${maxDriftSamples} samples).`);
  }

  let totalClippedSamples = 0;
  let missingAudioDetected = false;
  let phaseIssueDetected = false;
  const stemMetrics = {};

  let origSq = 0;
  for (let i = 0; i < length; i++) {
    origSq += origL[i] * origL[i] + origR[i] * origR[i];
  }
  const origRms = Math.sqrt(origSq / Math.max(1, length * 2));

  for (const name of STEM_NAMES) {
    const { L, R } = stems[name];
    let peak = 0;
    let sq = 0;
    let clipped = 0;
    let dotLR = 0;
    let sqL = 0;
    let sqR = 0;
    let hasNan = false;

    for (let i = 0; i < length; i++) {
      const l = L[i];
      const r = R[i];
      if (!Number.isFinite(l) || !Number.isFinite(r)) {
        hasNan = true;
        continue;
      }
      const absMax = Math.max(Math.abs(l), Math.abs(r));
      if (absMax > peak) peak = absMax;
      if (absMax > 0.999) clipped++;
      sq += l * l + r * r;
      dotLR += l * r;
      sqL += l * l;
      sqR += r * r;
    }

    const rms = Math.sqrt(sq / Math.max(1, length * 2));
    const peakDbfs = peak > 1e-9 ? 20 * Math.log10(peak) : -120;
    const denom = Math.sqrt(sqL * sqR);
    const phaseCorr = denom > 1e-9 ? dotLR / denom : 1;
    const isSilent = rms < 1e-6 || hasNan;

    if (clipped > 0) {
      totalClippedSamples += clipped;
      warnings.push(`Stem "${name}" has ${clipped} clipped samples (> -0.01 dBFS).`);
    }
    if (hasNan) {
      missingAudioDetected = true;
      warnings.push(`Stem "${name}" contains non-finite audio samples.`);
    }
    if (origRms > 0.005 && isSilent && name !== 'vocals') {
      warnings.push(`Stem "${name}" energy is near silence (RMS ${rms.toExponential(2)}).`);
    }
    if (phaseCorr < -0.35 && rms > 0.01) {
      phaseIssueDetected = true;
      warnings.push(`Stem "${name}" shows negative stereo phase correlation (${phaseCorr.toFixed(2)}).`);
    }

    stemMetrics[name] = {
      stem: name,
      peakLinear: peak,
      peakDbfs,
      rms,
      clippedSamples: clipped,
      isSilent,
      phaseCorrelation: phaseCorr,
    };
  }

  let errSq = 0;
  let maxResidualError = 0;
  let reconPeak = 0;
  let reconDot = 0;
  let reconSqL = 0;
  let reconSqR = 0;

  for (let i = 0; i < length; i++) {
    const sumL =
      stems.drums.L[i] + stems.bass.L[i] + stems.other.L[i] + stems.vocals.L[i];
    const sumR =
      stems.drums.R[i] + stems.bass.R[i] + stems.other.R[i] + stems.vocals.R[i];
    const dL = origL[i] - sumL;
    const dR = origR[i] - sumR;
    errSq += dL * dL + dR * dR;
    const resMax = Math.max(Math.abs(dL), Math.abs(dR));
    if (resMax > maxResidualError) maxResidualError = resMax;
    const p = Math.max(Math.abs(sumL), Math.abs(sumR));
    if (p > reconPeak) reconPeak = p;
    reconDot += sumL * sumR;
    reconSqL += sumL * sumL;
    reconSqR += sumR * sumR;
  }

  const reconstructionSnrDb =
    errSq > 1e-12 ? 10 * Math.log10((origSq + 1e-12) / errSq) : 80;
  const reconDenom = Math.sqrt(reconSqL * reconSqR);
  const reconstructedPhaseCorrelation = reconDenom > 1e-9 ? reconDot / reconDenom : 1;

  if (reconstructionSnrDb < 14 && origRms > 0.005) {
    warnings.push(
      `Low stem reconstruction SNR (${reconstructionSnrDb.toFixed(1)} dB) against original mix.`
    );
  }
  if (reconPeak > 0.999) {
    warnings.push(
      `Combined stem sum peaks at ${(20 * Math.log10(reconPeak)).toFixed(2)} dBFS.`
    );
  }

  const allSilent = STEM_NAMES.every((n) => stemMetrics[n].isSilent);
  if (allSilent && origRms > 0.002) {
    missingAudioDetected = true;
    warnings.push('All separated stems are silent despite non-silent input audio.');
  }

  const clippingDetected = totalClippedSamples > 0 || reconPeak > 0.999;
  const passed = syncVerified && !missingAudioDetected && !phaseIssueDetected;

  return {
    syncVerified,
    maxDriftSamples,
    sampleRate,
    lengthSamples: length,
    durationSec,
    clippingDetected,
    totalClippedSamples,
    missingAudioDetected,
    phaseIssueDetected,
    reconstructionSnrDb,
    maxResidualError,
    reconstructedPeakLinear: reconPeak,
    reconstructedPhaseCorrelation,
    stems: stemMetrics,
    warnings,
    passed,
  };
}

async function runSingleModelSeparation(mix44L, mix44R, modelPath, caps, jobId) {
  let session;
  let provider;

  const isBaseHtdemucs = modelPath.endsWith('htdemucs_fp16weights.onnx');
  if (isBaseHtdemucs && cachedHtdemucsSession) {
    session = cachedHtdemucsSession;
    provider = cachedHtdemucsProvider;
  } else {
    postProgress(jobId, 'separating', 24, `Loading htdemucs ONNX model (${caps.hasGpu ? 'GPU/CPU' : 'CPU'})...`);
    const created = await createOrtSessionWithFallback(modelPath, caps);
    session = created.session;
    provider = created.provider;
    if (isBaseHtdemucs) {
      cachedHtdemucsSession = session;
      cachedHtdemucsProvider = provider;
    }
  }

  const totalLen = mix44L.length;
  const nChunks = Math.max(
    1,
    Math.ceil(Math.max(0, totalLen - DEMUCS_OVERLAP_SAMPLES) / DEMUCS_STRIDE_SAMPLES)
  );
  const window = makeDemucsTransitionWindow(DEMUCS_SEGMENT_SAMPLES, DEMUCS_OVERLAP_SAMPLES);

  const out = {
    drums: { L: new Float32Array(totalLen), R: new Float32Array(totalLen) },
    bass: { L: new Float32Array(totalLen), R: new Float32Array(totalLen) },
    other: { L: new Float32Array(totalLen), R: new Float32Array(totalLen) },
    vocals: { L: new Float32Array(totalLen), R: new Float32Array(totalLen) },
  };
  const weight = new Float32Array(totalLen);
  const inputBuf = new Float32Array(2 * DEMUCS_SEGMENT_SAMPLES);

  const inputName = session.inputNames[0] || 'mix';
  const outputName = session.outputNames[0] || 'stems';

  for (let c = 0; c < nChunks; c++) {
    const start = c * DEMUCS_STRIDE_SAMPLES;
    const end = Math.min(start + DEMUCS_SEGMENT_SAMPLES, totalLen);
    const clen = end - start;

    inputBuf.fill(0);
    inputBuf.set(mix44L.subarray(start, end), 0);
    inputBuf.set(mix44R.subarray(start, end), DEMUCS_SEGMENT_SAMPLES);

    const inputTensor = new ort.Tensor('float32', inputBuf, [1, 2, DEMUCS_SEGMENT_SAMPLES]);
    const resMap = await session.run({ [inputName]: inputTensor });
    const outTensor = resMap[outputName];
    try {
      const stemData = outTensor.data;

      for (let sIdx = 0; sIdx < STEM_NAMES.length; sIdx++) {
        const sName = STEM_NAMES[sIdx];
        const baseL = sIdx * 2 * DEMUCS_SEGMENT_SAMPLES;
        const baseR = baseL + DEMUCS_SEGMENT_SAMPLES;
        const dstL = out[sName].L;
        const dstR = out[sName].R;

        for (let i = 0; i < clen; i++) {
          const w = window[i];
          dstL[start + i] += stemData[baseL + i] * w;
          dstR[start + i] += stemData[baseR + i] * w;
        }
      }
    } finally {
      if (typeof inputTensor.dispose === 'function') inputTensor.dispose();
      if (outTensor && typeof outTensor.dispose === 'function') outTensor.dispose();
    }

    for (let i = 0; i < clen; i++) {
      weight[start + i] += window[i];
    }

    const pct = 25 + Math.round(((c + 1) / nChunks) * 67);
    postProgress(
      jobId,
      'separating',
      pct,
      `htdemucs · separating 4 stems (segment ${c + 1}/${nChunks}) on ${provider}...`
    );
  }

  for (let i = 0; i < totalLen; i++) {
    const w = Math.max(1e-8, weight[i]);
    for (const sName of STEM_NAMES) {
      out[sName].L[i] /= w;
      out[sName].R[i] /= w;
    }
  }

  return { provider, stems: out };
}

async function runFtEnsembleSeparation(mix44L, mix44R, modelPaths, caps, jobId) {
  const totalLen = mix44L.length;
  const nChunks = Math.max(
    1,
    Math.ceil(Math.max(0, totalLen - DEMUCS_OVERLAP_SAMPLES) / DEMUCS_STRIDE_SAMPLES)
  );
  const window = makeDemucsTransitionWindow(DEMUCS_SEGMENT_SAMPLES, DEMUCS_OVERLAP_SAMPLES);
  const inputBuf = new Float32Array(2 * DEMUCS_SEGMENT_SAMPLES);

  const out = {
    drums: { L: new Float32Array(totalLen), R: new Float32Array(totalLen) },
    bass: { L: new Float32Array(totalLen), R: new Float32Array(totalLen) },
    other: { L: new Float32Array(totalLen), R: new Float32Array(totalLen) },
    vocals: { L: new Float32Array(totalLen), R: new Float32Array(totalLen) },
  };

  let providerUsed = 'CPU';
  const totalSteps = STEM_NAMES.length * nChunks;
  let completedSteps = 0;

  for (let sIdx = 0; sIdx < STEM_NAMES.length; sIdx++) {
    const stemName = STEM_NAMES[sIdx];
    postProgress(
      jobId,
      'separating',
      22 + Math.round((completedSteps / totalSteps) * 70),
      `Loading htdemucs_ft ${stemName} specialist model...`
    );
    const { session, provider } = await createOrtSessionWithFallback(modelPaths[stemName], caps);
    providerUsed = provider;

    const inputName = session.inputNames[0] || 'mix';
    const outputName = session.outputNames[0] || 'stems';
    const weight = new Float32Array(totalLen);
    const dstL = out[stemName].L;
    const dstR = out[stemName].R;

    const baseL = sIdx * 2 * DEMUCS_SEGMENT_SAMPLES;
    const baseR = baseL + DEMUCS_SEGMENT_SAMPLES;

    for (let c = 0; c < nChunks; c++) {
      const start = c * DEMUCS_STRIDE_SAMPLES;
      const end = Math.min(start + DEMUCS_SEGMENT_SAMPLES, totalLen);
      const clen = end - start;

      inputBuf.fill(0);
      inputBuf.set(mix44L.subarray(start, end), 0);
      inputBuf.set(mix44R.subarray(start, end), DEMUCS_SEGMENT_SAMPLES);

      const inputTensor = new ort.Tensor('float32', inputBuf, [1, 2, DEMUCS_SEGMENT_SAMPLES]);
      const resMap = await session.run({ [inputName]: inputTensor });
      const outTensor = resMap[outputName];
      try {
        const stemData = outTensor.data;

        for (let i = 0; i < clen; i++) {
          const w = window[i];
          dstL[start + i] += stemData[baseL + i] * w;
          dstR[start + i] += stemData[baseR + i] * w;
          weight[start + i] += w;
        }
      } finally {
        if (typeof inputTensor.dispose === 'function') inputTensor.dispose();
        if (outTensor && typeof outTensor.dispose === 'function') outTensor.dispose();
      }

      completedSteps++;
      const pct = 22 + Math.round((completedSteps / totalSteps) * 70);
      postProgress(
        jobId,
        'separating',
        pct,
        `htdemucs_ft · separating ${stemName} (${c + 1}/${nChunks}) on ${provider}...`
      );
    }

    for (let i = 0; i < totalLen; i++) {
      const w = Math.max(1e-8, weight[i]);
      dstL[i] /= w;
      dstR[i] /= w;
    }

    await session.release().catch(() => {});
  }

  return { provider: providerUsed, stems: out };
}

parentPort?.on('message', async (task) => {
  const {
    jobId,
    uploadFile,
    cacheDir,
    sampleRate,
    lengthSamples,
    resolvedModel,
    modelPaths,
    caps,
  } = task;

  try {
    const rawBuf = await fsp.readFile(uploadFile);
    const floatView = new Float32Array(
      rawBuf.buffer,
      rawBuf.byteOffset,
      rawBuf.byteLength / 4
    );
    const origL = new Float32Array(floatView.subarray(0, lengthSamples));
    const origR = new Float32Array(floatView.subarray(lengthSamples, lengthSamples * 2));

    let mix44L;
    let mix44R;
    if (sampleRate === DEMUCS_SAMPLE_RATE) {
      mix44L = origL;
      mix44R = origR;
    } else {
      postProgress(jobId, 'separating', 21, `Resampling ${sampleRate} Hz → 44100 Hz (Lanczos-3)...`);
      const target44Len = Math.max(
        1,
        Math.round((lengthSamples * DEMUCS_SAMPLE_RATE) / sampleRate)
      );
      mix44L = resampleChannelLanczos(origL, sampleRate, DEMUCS_SAMPLE_RATE, target44Len);
      mix44R = resampleChannelLanczos(origR, sampleRate, DEMUCS_SAMPLE_RATE, target44Len);
    }

    const sepResult =
      resolvedModel === 'htdemucs'
        ? await runSingleModelSeparation(mix44L, mix44R, modelPaths.htdemucs, caps, jobId)
        : await runFtEnsembleSeparation(mix44L, mix44R, modelPaths, caps, jobId);

    let finalStems = sepResult.stems;
    if (sampleRate !== DEMUCS_SAMPLE_RATE) {
      postProgress(jobId, 'verifying', 93, `Restoring exact ${sampleRate} Hz sample alignment...`);
      const restored = {};
      for (const sName of STEM_NAMES) {
        restored[sName] = {
          L: resampleChannelLanczos(sepResult.stems[sName].L, DEMUCS_SAMPLE_RATE, sampleRate, lengthSamples),
          R: resampleChannelLanczos(sepResult.stems[sName].R, DEMUCS_SAMPLE_RATE, sampleRate, lengthSamples),
        };
      }
      finalStems = restored;
    }

    postProgress(jobId, 'verifying', 96, 'Running stem synchronization, phase, and reconstruction QC...');
    const qc = computeQualityControl(origL, origR, finalStems, sampleRate);

    const tmpCacheDir = `${cacheDir}.tmp.${Date.now()}`;
    await fsp.mkdir(tmpCacheDir, { recursive: true });
    for (const sName of STEM_NAMES) {
      const planar = new Float32Array(lengthSamples * 2);
      planar.set(finalStems[sName].L, 0);
      planar.set(finalStems[sName].R, lengthSamples);
      const buf = Buffer.from(planar.buffer, planar.byteOffset, planar.byteLength);
      await fsp.writeFile(path.join(tmpCacheDir, `${sName}.f32`), buf);
    }

    await fsp.writeFile(
      path.join(tmpCacheDir, 'meta.json'),
      JSON.stringify({
        sampleRate,
        lengthSamples,
        modelUsed: resolvedModel,
        providerUsed: sepResult.provider,
        qc,
        createdAt: Date.now(),
      })
    );

    if (fs.existsSync(cacheDir)) {
      await fsp.rm(cacheDir, { recursive: true, force: true });
    }
    await fsp.rename(tmpCacheDir, cacheDir);

    parentPort?.postMessage({
      type: 'done',
      jobId,
      providerUsed: sepResult.provider,
      qc,
    });
  } catch (err) {
    parentPort?.postMessage({
      type: 'error',
      jobId,
      error: err instanceof Error ? err.message : 'Demucs worker separation failed.',
    });
  }
});
