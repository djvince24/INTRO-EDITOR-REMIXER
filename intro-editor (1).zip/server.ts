import express from 'express';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import {
  appendJobChunk,
  cancelDemucsJob,
  checkStemCache,
  createDemucsJob,
  DemucsModelPreference,
  detectHardwareCapabilities,
  getDemucsJob,
  getStemFilePath,
  STEM_NAMES,
  StemName,
  startDemucsJob,
} from './server/demucsEngine';

const PORT = Number(process.env.PORT || 3000);

function parseModelPref(val: unknown): DemucsModelPreference {
  if (val === 'htdemucs' || val === 'htdemucs_ft' || val === 'auto') {
    return val;
  }
  return 'auto';
}

async function startServer() {
  const app = express();

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.get('/api/demucs/capabilities', async (_req, res) => {
    try {
      const caps = await detectHardwareCapabilities();
      res.setHeader('Cache-Control', 'no-store');
      res.json(caps);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to inspect Demucs capabilities.',
      });
    }
  });

  app.post('/api/demucs/check-cache', express.json({ limit: '1mb' }), async (req, res) => {
    try {
      const audioHash = String(req.body?.audioHash || '');
      if (!/^[a-fA-F0-9]{16,128}$/.test(audioHash)) {
        res.status(400).json({ error: 'Invalid audioHash' });
        return;
      }
      const modelPreference = parseModelPref(req.body?.modelPreference);
      const hit = await checkStemCache(audioHash, modelPreference);
      res.json(hit);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Cache lookup failed.',
      });
    }
  });

  app.post('/api/demucs/jobs', express.json({ limit: '1mb' }), async (req, res) => {
    try {
      const audioHash = String(req.body?.audioHash || '');
      const sampleRate = Number(req.body?.sampleRate || 0);
      const channels = Number(req.body?.channels || 2);
      const lengthSamples = Number(req.body?.lengthSamples || 0);
      const modelPreference = parseModelPref(req.body?.modelPreference);

      if (!/^[a-fA-F0-9]{16,128}$/.test(audioHash)) {
        res.status(400).json({ error: 'Invalid audioHash' });
        return;
      }
      if (!Number.isInteger(sampleRate) || sampleRate < 8000 || sampleRate > 192000) {
        res.status(400).json({ error: 'Invalid sampleRate' });
        return;
      }
      if (!Number.isInteger(lengthSamples) || lengthSamples <= 0 || lengthSamples > 44100 * 60 * 30) {
        res.status(400).json({ error: 'Invalid track lengthSamples' });
        return;
      }

      const job = await createDemucsJob({
        audioHash,
        modelPreference,
        sampleRate,
        channels: Math.min(2, Math.max(1, channels)),
        lengthSamples,
      });
      res.json(job);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Failed to create Demucs job.',
      });
    }
  });

  app.post(
    '/api/demucs/jobs/:jobId/chunk',
    express.raw({ type: 'application/octet-stream', limit: '16mb' }),
    async (req, res) => {
      try {
        const { jobId } = req.params;
        const offset = Number(req.query.offset ?? -1);
        if (!Number.isInteger(offset) || offset < 0) {
          res.status(400).json({ error: 'Invalid chunk offset' });
          return;
        }
        if (!Buffer.isBuffer(req.body) || req.body.byteLength === 0) {
          res.status(400).json({ error: 'Empty binary chunk' });
          return;
        }
        const job = await appendJobChunk(jobId, offset, req.body);
        res.json({ bytesReceived: job.bytesReceived, totalBytesExpected: job.totalBytesExpected });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'Failed to append upload chunk.',
        });
      }
    }
  );

  app.post('/api/demucs/jobs/:jobId/start', (req, res) => {
    try {
      const job = startDemucsJob(req.params.jobId);
      res.json(job);
    } catch (err) {
      res.status(404).json({
        error: err instanceof Error ? err.message : 'Demucs job not found.',
      });
    }
  });

  app.get('/api/demucs/jobs/:jobId', (req, res) => {
    const job = getDemucsJob(req.params.jobId);
    if (!job) {
      res.status(404).json({ error: 'Demucs job not found.' });
      return;
    }
    res.json(job);
  });

  app.delete('/api/demucs/jobs/:jobId', async (req, res) => {
    await cancelDemucsJob(req.params.jobId);
    res.json({ ok: true });
  });

  // Chunked byte-range download of separated Float32 planar stereo stem files
  // Keeps every HTTP response well below Cloud Run's 32 MiB cap.
  app.get('/api/demucs/jobs/:jobId/stem/:stem', async (req, res) => {
    try {
      const job = getDemucsJob(req.params.jobId);
      if (!job || job.status !== 'completed') {
        res.status(404).json({ error: 'Completed Demucs job not found.' });
        return;
      }

      const stem = req.params.stem as StemName;
      if (!STEM_NAMES.includes(stem)) {
        res.status(400).json({ error: 'Invalid stem name.' });
        return;
      }

      const filePath = getStemFilePath(job.cacheKey, stem);
      if (!fs.existsSync(filePath)) {
        res.status(404).json({ error: `Stem file missing for ${stem}.` });
        return;
      }

      const stat = await fsp.stat(filePath);
      const totalSize = stat.size;
      const startParam = req.query.start !== undefined ? Number(req.query.start) : 0;
      const endParam =
        req.query.end !== undefined ? Number(req.query.end) : Math.min(totalSize - 1, startParam + 4 * 1024 * 1024 - 1);

      if (
        !Number.isInteger(startParam) ||
        !Number.isInteger(endParam) ||
        startParam < 0 ||
        endParam < startParam ||
        startParam >= totalSize
      ) {
        res.status(400).json({ error: 'Invalid byte range' });
        return;
      }

      const clampedEnd = Math.min(totalSize - 1, endParam);
      const chunkLen = clampedEnd - startParam + 1;

      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('Content-Length', String(chunkLen));
      res.setHeader('X-Total-Bytes', String(totalSize));
      res.setHeader('Cache-Control', 'no-store');

      const stream = fs.createReadStream(filePath, { start: startParam, end: clampedEnd });
      stream.on('error', (err) => {
        if (!res.headersSent) {
          res.status(500).json({ error: err.message });
        } else {
          res.destroy(err);
        }
      });
      stream.pipe(res);
    } catch (err) {
      if (!res.headersSent) {
        res.status(500).json({
          error: err instanceof Error ? err.message : 'Failed to stream Demucs stem.',
        });
      }
    }
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  void detectHardwareCapabilities().catch(() => {});

  const httpServer = app.listen(PORT, '0.0.0.0', () => {
    console.log(`CueGrid Demucs Studio server listening on http://0.0.0.0:${PORT}`);
  });
  httpServer.keepAliveTimeout = 65000;
  httpServer.headersTimeout = 66000;
}

void startServer();
