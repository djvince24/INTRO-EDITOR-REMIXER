import React, { useEffect, useRef } from 'react';
import { Play, Square, CheckCircle2, AlertTriangle } from 'lucide-react';
import {
  DemucsStemSet,
  IntroEditConfig,
  PlaybackDeck,
  RenderedIntroEdit,
  StemName,
  TrackAnalysis,
} from '../types/audio';

interface TransitionCheckViewProps {
  analysis: TrackAnalysis;
  config: IntroEditConfig;
  rendered: RenderedIntroEdit;
  stemSet: DemucsStemSet | null;
  isPlaying: boolean;
  activeDeck: PlaybackDeck;
  currentTimeSec: number;
  onPlaySeamWindow: () => void;
  onStop: () => void;
}

const STEM_ORDER: StemName[] = ['vocals', 'drums', 'bass', 'other'];

export const TransitionCheckView: React.FC<TransitionCheckViewProps> = ({
  analysis,
  config,
  rendered,
  stemSet,
  isPlaying,
  activeDeck,
  currentTimeSec,
  onPlaySeamWindow,
  onStop,
}) => {
  const zoomCanvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = zoomCanvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    canvas.width = Math.floor(rect.width * dpr);
    canvas.height = Math.floor(rect.height * dpr);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.scale(dpr, dpr);
    const w = rect.width;
    const h = rect.height;

    const startSec = Math.max(0, rendered.introDurationSec - rendered.barSec * 2);
    const endSec = Math.min(rendered.totalDurationSec, rendered.introDurationSec + rendered.barSec * 2);
    const spanSec = Math.max(0.1, endSec - startSec);

    const sr = rendered.buffer.sampleRate;
    const ch0 = rendered.buffer.getChannelData(0);
    const ch1 = rendered.buffer.numberOfChannels > 1 ? rendered.buffer.getChannelData(1) : ch0;

    ctx.clearRect(0, 0, w, h);

    const seamX = ((rendered.introDurationSec - startSec) / spanSec) * w;
    ctx.fillStyle = 'rgba(16, 185, 129, 0.08)';
    ctx.fillRect(0, 0, seamX, h);
    ctx.fillStyle = 'rgba(245, 158, 11, 0.07)';
    ctx.fillRect(seamX, 0, Math.max(0, w - seamX), h);

    const startBar = 6;
    for (let beatIdx = 0; beatIdx <= 16; beatIdx++) {
      const t = startBar * rendered.barSec + beatIdx * rendered.beatSec;
      const x = ((t - startSec) / spanSec) * w;
      const isBar = beatIdx % 4 === 0;
      const barNum = startBar + Math.floor(beatIdx / 4) + 1;

      ctx.strokeStyle =
        barNum === 9 && isBar
          ? '#F59E0B'
          : isBar
            ? 'rgba(255,255,255,0.22)'
            : 'rgba(255,255,255,0.06)';
      ctx.lineWidth = barNum === 9 && isBar ? 2 : 1;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();

      if (isBar && beatIdx < 16) {
        ctx.fillStyle = barNum >= 9 ? '#F59E0B' : '#10B981';
        ctx.font = '600 11px "JetBrains Mono", monospace';
        ctx.fillText(
          barNum === 9 ? 'BAR 9 · CUE 1 VERSE' : `BAR ${barNum}`,
          x + 8,
          18
        );
      }
    }

    const midY = h * 0.52;
    const cols = Math.floor(w);
    for (let px = 0; px < cols; px++) {
      const t0 = startSec + (px / cols) * spanSec;
      const t1 = startSec + ((px + 1) / cols) * spanSec;
      const s0 = Math.max(0, Math.floor(t0 * sr));
      const s1 = Math.min(ch0.length, Math.max(s0 + 1, Math.floor(t1 * sr)));

      let maxAmp = 0;
      const stride = Math.max(1, Math.floor((s1 - s0) / 32));
      for (let i = s0; i < s1; i += stride) {
        const m = Math.max(Math.abs(ch0[i]), Math.abs(ch1[i]));
        if (m > maxAmp) maxAmp = m;
      }

      const ampPx = Math.min(1, maxAmp) * (h * 0.38);
      ctx.fillStyle = t0 < rendered.introDurationSec ? '#10B981' : '#F59E0B';
      ctx.fillRect(px, midY - ampPx, 1, ampPx * 2);
    }

    if (activeDeck === 'edit' && currentTimeSec >= startSec && currentTimeSec <= endSec) {
      const px = ((currentTimeSec - startSec) / spanSec) * w;
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(px, 0);
      ctx.lineTo(px, h);
      ctx.stroke();
    }
  }, [rendered, activeDeck, currentTimeSec]);

  const donorBars = config.loopStructure === '4-bar-x2' ? 4 : 8;

  const rows = Array.from({ length: 10 }, (_, idx) => {
    const isIntro = idx < 8;
    const sourceBarIdx = isIntro
      ? config.donorStartBar + (idx % donorBars)
      : config.cue1Bar + (idx - 8);
    const barMetric = analysis.bars[sourceBarIdx];
    const startSec = idx * rendered.barSec;

    let introRole = 'Awaiting Demucs Separation';
    if (rendered.usingDemucsStems) {
      if (config.introArrangement === 'progressive-build') {
        if (idx < 2) introRole = 'Demucs Drums Lead';
        else if (idx < 4) introRole = 'Drums + Bass Entry';
        else introRole = 'Full Instrumental Build';
      } else {
        introRole = `${rendered.demucsModelUsed ?? 'htdemucs'} Instrumental`;
      }
    }

    return {
      editBar: idx + 1,
      role: isIntro
        ? introRole
        : idx === 8
          ? 'Cue 1 · First Verse'
          : 'Verse Continuation',
      sourceBar: sourceBarIdx + 1,
      startSec,
      drumEnergy: barMetric ? Math.round(barMetric.drumTransientScore * 100) : 0,
      vocalScore: isIntro
        ? rendered.usingDemucsStems
          ? Math.round(config.stems.vocals.introLevel * 100)
          : Math.round((barMetric?.vocalPresenceScore ?? 0) * 100)
        : Math.round((barMetric?.vocalPresenceScore ?? 0) * 100),
      melodySpread: barMetric ? Math.round(barMetric.melodyRichnessScore * 100) : 0,
    };
  });

  const qc = rendered.qc;

  return (
    <div className="space-y-6">
      {/* Quality Control Audit Section */}
      <section className="bg-[#12161F] border border-white/[0.08] rounded-lg p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-slate-100">
              Pre-Export Demucs Quality Control
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Verifies stem synchronization, clipping headroom, missing audio, stereo phase, and original mix reconstruction fidelity.
            </p>
          </div>
          <span
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono font-semibold rounded-md border ${
              qc.passed
                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
            }`}
          >
            {qc.passed ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>QC PASSED · READY TO EXPORT</span>
              </>
            ) : (
              <>
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>QC ATTENTION REQUIRED</span>
              </>
            )}
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          <div className="bg-[#0B0D11] border border-white/[0.07] rounded-md p-3">
            <div className="text-[11px] text-slate-400">Stem Sync</div>
            <div className="text-sm font-mono font-semibold text-slate-100 mt-0.5">
              {qc.stemSyncVerified ? '0 Samples Drift' : 'Not Synced'}
            </div>
            <div className="text-[11px] font-mono text-emerald-400">
              {stemSet ? `${stemSet.sampleRate} Hz Locked` : 'Pending'}
            </div>
          </div>

          <div className="bg-[#0B0D11] border border-white/[0.07] rounded-md p-3">
            <div className="text-[11px] text-slate-400">Output Headroom</div>
            <div className="text-sm font-mono font-semibold text-slate-100 mt-0.5">
              {qc.outputPeakDbfs.toFixed(2)} dBFS
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              {qc.clippedSamples} Pre-Limiter Clips
            </div>
          </div>

          <div className="bg-[#0B0D11] border border-white/[0.07] rounded-md p-3">
            <div className="text-[11px] text-slate-400">Reconstruction SNR</div>
            <div className="text-sm font-mono font-semibold text-slate-100 mt-0.5">
              {qc.reconstructionSnrDb != null ? `${qc.reconstructionSnrDb.toFixed(1)} dB` : '—'}
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              {stemSet ? `Max Err ${stemSet.qc.maxResidualError.toFixed(4)}` : '4-Stem Sum vs Mix'}
            </div>
          </div>

          <div className="bg-[#0B0D11] border border-white/[0.07] rounded-md p-3">
            <div className="text-[11px] text-slate-400">Seam Phase & Energy</div>
            <div className="text-sm font-mono font-semibold text-slate-100 mt-0.5">
              {Math.round(qc.seamPeakContinuity * 100)}% Continuity
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              Phase {qc.phaseCorrelationSeam.toFixed(2)}
            </div>
          </div>

          <div className="bg-[#0B0D11] border border-white/[0.07] rounded-md p-3">
            <div className="text-[11px] text-slate-400">Missing Audio Check</div>
            <div className="text-sm font-mono font-semibold text-slate-100 mt-0.5">
              {!qc.hasSilentIntro && !qc.hasSilentCue1 ? 'All Sections Active' : 'Silence Detected'}
            </div>
            <div className="text-[11px] font-mono text-slate-400">
              {stemSet ? `${stemSet.modelUsed}` : 'Pending Demucs'}
            </div>
          </div>
        </div>

        {stemSet && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-1">
            {STEM_ORDER.map((sName) => {
              const m = stemSet.qc.stems[sName];
              return (
                <div
                  key={sName}
                  className="bg-[#0B0D11] border border-white/[0.06] rounded px-3 py-2 flex items-center justify-between text-xs font-mono"
                >
                  <span className="uppercase text-slate-300 font-semibold">{sName}</span>
                  <span className="text-slate-400">
                    {m.isSilent ? 'SILENT' : `${m.peakDbfs.toFixed(1)} dB · Φ ${m.phaseCorrelation.toFixed(2)}`}
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {qc.issues.length > 0 && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-md px-3.5 py-2.5 text-xs text-amber-200 space-y-1">
            {qc.issues.map((issue, i) => (
              <div key={i}>• {issue}</div>
            ))}
          </div>
        )}
      </section>

      <section className="bg-[#12161F] border border-white/[0.08] rounded-lg p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-base font-semibold text-slate-100">
              Zoomed Seam Inspection (Bars 7–10)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Verifies sample-accurate downbeat alignment and continuous groove energy across the Bar 8 → Bar 9 transition.
            </p>
          </div>
          <div className="flex items-center gap-2">
            {isPlaying && activeDeck === 'edit' ? (
              <button
                type="button"
                onClick={onStop}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-100 bg-[#1B212E] border border-white/[0.1] rounded-md hover:bg-[#232B3B] transition-colors cursor-pointer"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Stop Audition</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={onPlaySeamWindow}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#0B0D11] bg-amber-500 rounded-md hover:bg-amber-400 transition-colors cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Audition Bars 7–10 Seam</span>
              </button>
            )}
          </div>
        </div>

        <div className="bg-[#0B0D11] border border-white/[0.07] rounded-md overflow-hidden">
          <canvas ref={zoomCanvasRef} className="w-full h-44 block" />
        </div>
      </section>

      <section className="bg-[#12161F] border border-white/[0.08] rounded-lg overflow-hidden">
        <div className="px-5 py-3.5 border-b border-white/[0.08] flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-100">
            Bar-by-Bar Intro & First Verse Verification
          </h3>
          <span className="text-xs font-mono text-slate-400">
            Tempo Locked {rendered.bpm.toFixed(2)} BPM · Bar {rendered.barSec.toFixed(3)}s
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/[0.06] text-xs text-slate-400 bg-[#0E1117]">
                <th className="py-2.5 px-5 font-medium">Edit Bar</th>
                <th className="py-2.5 px-4 font-medium">Section Role</th>
                <th className="py-2.5 px-4 font-medium text-right">Source Bar</th>
                <th className="py-2.5 px-4 font-medium text-right">Timestamp</th>
                <th className="py-2.5 px-4 font-medium text-right">Drum Groove</th>
                <th className="py-2.5 px-4 font-medium text-right">Stereo Melody</th>
                <th className="py-2.5 px-5 font-medium text-right">Vocals</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05] text-xs">
              {rows.map((r) => (
                <tr
                  key={r.editBar}
                  className={
                    r.editBar === 9
                      ? 'bg-amber-500/[0.08] text-slate-100'
                      : 'hover:bg-white/[0.02] text-slate-300'
                  }
                >
                  <td className="py-2.5 px-5 font-mono font-semibold">Bar {r.editBar}</td>
                  <td className="py-2.5 px-4">
                    <span className={r.editBar >= 9 ? 'text-amber-400 font-medium' : 'text-emerald-400'}>
                      {r.role}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 font-mono text-right text-slate-400">
                    Src {r.sourceBar}
                  </td>
                  <td className="py-2.5 px-4 font-mono text-right">{r.startSec.toFixed(2)}s</td>
                  <td className="py-2.5 px-4 font-mono text-right">{r.drumEnergy}%</td>
                  <td className="py-2.5 px-4 font-mono text-right">{r.melodySpread}%</td>
                  <td className="py-2.5 px-5 font-mono text-right">
                    {r.editBar <= 8
                      ? rendered.usingDemucsStems
                        ? config.introArrangement === 'custom-automation' && config.stems.vocals.introLevel > 0
                          ? `${Math.round(config.stems.vocals.introLevel * 100)}% (Custom)`
                          : '0% (Demucs Vocals Out)'
                        : 'Pending Demucs'
                      : `${r.vocalScore}% (Active)`}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
