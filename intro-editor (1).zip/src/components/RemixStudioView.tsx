import React, { useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  Upload,
  Sparkles,
  Download,
  RefreshCw,
  RotateCcw,
  Music,
  Mic,
  Sliders,
  CheckCircle2,
} from 'lucide-react';
import { DEMO_TRACKS } from '../audio/demoTracks';
import {
  DemucsStemSet,
  RemixConfig,
  RemixVocalTone,
  RenderedRemix,
  TrackAnalysis,
} from '../types/audio';

function formatClock(sec: number): string {
  const s = Math.max(0, sec);
  const mins = Math.floor(s / 60);
  const rem = s - mins * 60;
  return `${String(mins).padStart(2, '0')}:${rem.toFixed(2).padStart(5, '0')}`;
}

interface RemixStudioViewProps {
  // Deck A: Instrumental Bed (reuses primary Studio track & its Demucs stems)
  instTrackId: string;
  instTrackName: string;
  instAnalysis: TrackAnalysis;
  instBpm: number;
  instFirstDownbeatSec: number;
  instStems: DemucsStemSet | null;
  instIsSeparating: boolean;
  instProgress: { pct: number; stage: string } | null;
  instError: string | null;
  onUploadInstFile: (file: File) => void;
  onSelectInstDemo: (demoId: string) => void;
  onRetryInstDemucs: () => void;

  // Deck B: Vocal Track
  vocalTrackId: string;
  vocalTrackName: string;
  vocalAnalysis: TrackAnalysis | null;
  vocalStems: DemucsStemSet | null;
  vocalIsSeparating: boolean;
  vocalProgress: { pct: number; stage: string } | null;
  vocalError: string | null;
  onUploadVocalFile: (file: File) => void;
  onSelectVocalDemo: (demoId: string) => void;
  onRetryVocalDemucs: () => void;

  // Remix state & playback
  remixConfig: RemixConfig;
  renderedRemix: RenderedRemix | null;
  activeDeck: string;
  currentTimeSec: number;
  isPlaying: boolean;
  isExporting: boolean;
  beatClickEnabled: boolean;
  onToggleBeatClick: () => void;
  onAutoSyncRemix: () => void;
  onChangeConfig: (updater: (prev: RemixConfig) => RemixConfig) => void;
  onSeekRemix: (
    mode: 'remix' | 'remix-vocals' | 'remix-inst',
    timeSec: number,
    autoPlay?: boolean
  ) => void;
  onStopPlayback: () => void;
  onExportRemixWav: () => void;
}

export const RemixStudioView: React.FC<RemixStudioViewProps> = ({
  instTrackId,
  instTrackName,
  instAnalysis,
  instBpm,
  instStems,
  instIsSeparating,
  instProgress,
  instError,
  onUploadInstFile,
  onSelectInstDemo,
  onRetryInstDemucs,
  vocalTrackId,
  vocalTrackName,
  vocalAnalysis,
  vocalStems,
  vocalIsSeparating,
  vocalProgress,
  vocalError,
  onUploadVocalFile,
  onSelectVocalDemo,
  onRetryVocalDemucs,
  remixConfig,
  renderedRemix,
  activeDeck,
  currentTimeSec,
  isPlaying,
  isExporting,
  beatClickEnabled,
  onToggleBeatClick,
  onAutoSyncRemix,
  onChangeConfig,
  onSeekRemix,
  onStopPlayback,
  onExportRemixWav,
}) => {
  const instFileRef = useRef<HTMLInputElement | null>(null);
  const vocalFileRef = useRef<HTMLInputElement | null>(null);
  const vocalSourceCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const remixCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const isRemixPlaying =
    isPlaying &&
    (activeDeck === 'remix' || activeDeck === 'remix-vocals' || activeDeck === 'remix-inst');

  const effectiveVocalBpm =
    remixConfig.halfDoubleTime === '0.5x'
      ? remixConfig.vocalBpm * 0.5
      : remixConfig.halfDoubleTime === '2x'
        ? remixConfig.vocalBpm * 2
        : remixConfig.vocalBpm;

  const stretchFactor = remixConfig.autoBeatmatch
    ? Math.max(0.55, Math.min(1.85, effectiveVocalBpm / Math.max(60, instBpm)))
    : 1.0;

  // Draw Deck B Vocal Source waveform with Cue Bar + Beat Grid + Beat Shift highlighted
  useEffect(() => {
    const canvas = vocalSourceCanvasRef.current;
    if (!canvas || !vocalAnalysis) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    canvas.width = Math.floor(rect.width * dpr);
    canvas.height = Math.floor(rect.height * dpr);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.scale(dpr, dpr);
    const w = rect.width;
    const h = rect.height;
    ctx.clearRect(0, 0, w, h);

    const dur = Math.max(0.1, vocalAnalysis.durationSec);
    const vocBeatSec = 60 / Math.max(50, effectiveVocalBpm);
    const vocBarSec = vocBeatSec * 4;
    const cueSec = Math.max(
      0,
      Math.min(
        dur - 0.05,
        remixConfig.vocalFirstDownbeatSec +
          remixConfig.vocalCueBar * vocBarSec +
          remixConfig.vocalBeatShift * vocBeatSec
      )
    );
    const cueX = Math.max(0, Math.min(w, (cueSec / dur) * w));

    ctx.fillStyle = 'rgba(245, 158, 11, 0.08)';
    ctx.fillRect(cueX, 0, Math.max(0, w - cueX), h);

    // Draw bar lines & 4-bar phrase markers on Deck B
    const totalVocBars = Math.ceil(dur / vocBarSec);
    ctx.lineWidth = 1;
    for (let b = 0; b <= totalVocBars; b++) {
      const x = Math.round(((remixConfig.vocalFirstDownbeatSec + b * vocBarSec) / dur) * w) + 0.5;
      if (x < 0 || x > w) continue;
      const isPhrase = b % 4 === 0;
      ctx.strokeStyle = isPhrase ? 'rgba(255,255,255,0.16)' : 'rgba(255,255,255,0.045)';
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }

    const midY = h * 0.5;
    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx.beginPath();
    ctx.moveTo(0, midY);
    ctx.lineTo(w, midY);
    ctx.stroke();

    const peaks = vocalStems ? vocalStems.peaks.vocals : vocalAnalysis.originalPeaks;
    const barW = Math.max(1, w / peaks.length);
    for (let i = 0; i < peaks.length; i++) {
      const x = (i / peaks.length) * w;
      const t = (i / peaks.length) * dur;
      const amp = Math.min(1, peaks[i]) * (h * 0.42);
      ctx.fillStyle =
        t >= cueSec
          ? vocalStems
            ? 'rgba(245, 158, 11, 0.92)'
            : 'rgba(203, 213, 225, 0.65)'
          : 'rgba(100, 116, 139, 0.42)';
      ctx.fillRect(x, midY - amp, Math.max(1, barW - 0.3), amp * 2);
    }

    ctx.strokeStyle = '#F59E0B';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cueX, 0);
    ctx.lineTo(cueX, h);
    ctx.stroke();

    const shiftLabel =
      remixConfig.vocalBeatShift !== 0
        ? ` ${remixConfig.vocalBeatShift > 0 ? '+' : ''}${remixConfig.vocalBeatShift}B`
        : '';
    const tagText = `VOCAL BAR ${remixConfig.vocalCueBar + 1}${shiftLabel}`;
    const tagW = Math.max(90, tagText.length * 6.5 + 12);
    const tagX = Math.min(w - tagW - 2, Math.max(2, cueX + 2));
    ctx.fillStyle = '#F59E0B';
    ctx.fillRect(tagX, 0, tagW, 16);
    ctx.fillStyle = '#0B0D11';
    ctx.font = '600 9px "JetBrains Mono", monospace';
    ctx.fillText(tagText, tagX + 5, 11);
  }, [
    vocalAnalysis,
    vocalStems,
    effectiveVocalBpm,
    remixConfig.vocalCueBar,
    remixConfig.vocalBeatShift,
    remixConfig.vocalFirstDownbeatSec,
  ]);

  // Draw Combined Dual-Layer Beatmatched Remix Waveform
  useEffect(() => {
    const canvas = remixCanvasRef.current;
    if (!canvas || !renderedRemix) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    canvas.width = Math.floor(rect.width * dpr);
    canvas.height = Math.floor(rect.height * dpr);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.scale(dpr, dpr);
    const w = rect.width;
    const h = rect.height;
    const dur = Math.max(0.1, renderedRemix.totalDurationSec);

    ctx.clearRect(0, 0, w, h);

    const dropX = Math.max(0, Math.min(w, (renderedRemix.vocalDropSec / dur) * w));
    ctx.fillStyle = 'rgba(16, 185, 129, 0.06)';
    ctx.fillRect(0, 0, dropX, h);
    ctx.fillStyle = 'rgba(245, 158, 11, 0.05)';
    ctx.fillRect(dropX, 0, Math.max(0, w - dropX), h);

    // Draw Bar gridlines
    const totalBars = Math.ceil(dur / renderedRemix.barSec);
    ctx.lineWidth = 1;
    for (let b = 0; b <= totalBars; b++) {
      const x = Math.round(((b * renderedRemix.barSec) / dur) * w) + 0.5;
      const isPhrase = b % 4 === 0;
      ctx.strokeStyle = isPhrase ? 'rgba(255,255,255,0.16)' : 'rgba(255,255,255,0.04)';
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();

      if (isPhrase && b < totalBars) {
        ctx.fillStyle = 'rgba(148, 163, 184, 0.65)';
        ctx.font = '500 9px "JetBrains Mono", monospace';
        ctx.fillText(String(b + 1), x + 3, h - 6);
      }
    }

    const midY = h * 0.5;
    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx.beginPath();
    ctx.moveTo(0, midY);
    ctx.lineTo(w, midY);
    ctx.stroke();

    // Layer 1: Instrumental Bed (Emerald)
    const instPeaks = renderedRemix.instPeaks;
    const vocPeaks = renderedRemix.vocalPeaks;
    const barW = Math.max(1, w / instPeaks.length);

    for (let i = 0; i < instPeaks.length; i++) {
      const x = (i / instPeaks.length) * w;
      const iAmp = Math.min(1, instPeaks[i]) * (h * 0.42);
      ctx.fillStyle =
        activeDeck === 'remix-vocals' ? 'rgba(16, 185, 129, 0.16)' : 'rgba(16, 185, 129, 0.72)';
      ctx.fillRect(x, midY - iAmp, Math.max(1, barW - 0.3), iAmp * 2);

      const vAmp = Math.min(1, vocPeaks[i] ?? 0) * (h * 0.38);
      if (vAmp > 0.5) {
        ctx.fillStyle =
          activeDeck === 'remix-inst' ? 'rgba(245, 158, 11, 0.14)' : 'rgba(245, 158, 11, 0.88)';
        ctx.fillRect(x, midY - vAmp, Math.max(1, barW - 0.3), vAmp * 2);
      }
    }

    // Vocal Drop Marker
    ctx.strokeStyle = '#F59E0B';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(dropX, 0);
    ctx.lineTo(dropX, h);
    ctx.stroke();

    const dropTagX = Math.min(w - 130, Math.max(2, dropX + 2));
    ctx.fillStyle = '#F59E0B';
    ctx.fillRect(dropTagX, 0, 128, 17);
    ctx.fillStyle = '#0B0D11';
    ctx.font = '600 9.5px "JetBrains Mono", monospace';
    ctx.fillText(`VOCAL DROP · BAR ${remixConfig.vocalTargetDropBar + 1}`, dropTagX + 5, 12);

    // Live Playhead
    if (activeDeck === 'remix' || activeDeck === 'remix-vocals' || activeDeck === 'remix-inst') {
      const px = Math.min(w, Math.max(0, (currentTimeSec / dur) * w));
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(px, 0);
      ctx.lineTo(px, h);
      ctx.stroke();
    }
  }, [renderedRemix, activeDeck, currentTimeSec, remixConfig.vocalTargetDropBar]);

  const handleClickVocalSource = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!vocalAnalysis) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    const clickSec = ratio * vocalAnalysis.durationSec;
    const vocBarSec = 240 / Math.max(50, effectiveVocalBpm);
    const barIdx = Math.max(
      0,
      Math.min(
        Math.max(0, Math.floor((vocalAnalysis.durationSec - remixConfig.vocalFirstDownbeatSec) / vocBarSec) - 1),
        Math.round((clickSec - remixConfig.vocalFirstDownbeatSec) / vocBarSec)
      )
    );
    onChangeConfig((p) => ({ ...p, vocalCueBar: barIdx }));
  };

  const handleClickRemixCanvas = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!renderedRemix) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    const mode =
      activeDeck === 'remix-vocals' || activeDeck === 'remix-inst' ? activeDeck : 'remix';
    onSeekRemix(mode, ratio * renderedRemix.totalDurationSec, true);
  };

  const readyToRender = Boolean(instStems && vocalStems && renderedRemix);

  return (
    <div className="space-y-6">
      {/* Intro Banner */}
      <section className="bg-[#12161F] border border-white/[0.08] rounded-lg px-5 py-4 flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <h2 className="text-sm font-semibold text-slate-100">
              Demucs 4-Stem Vocal Mashup & Beatmatch Remix Studio
            </h2>
          </div>
          <p className="text-xs text-slate-400">
            Zero-drift Phase Vocoder with transient phase reset & downbeat phrasing locks Deck B
            Demucs vocals cleanly onto Deck A&apos;s kick & snare grid.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-1 bg-[#0B0D11] border border-white/[0.08] rounded text-slate-200 tabular-nums">
            Target Grid: {instBpm.toFixed(2)} BPM
          </span>
          <span
            className={`px-2.5 py-1 rounded border tabular-nums ${
              Math.abs(stretchFactor - 1) > 0.16
                ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                : 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
            }`}
          >
            {remixConfig.autoBeatmatch
              ? `Vocal Sync: ${effectiveVocalBpm.toFixed(1)} → ${instBpm.toFixed(1)} BPM (${stretchFactor.toFixed(3)}×)`
              : 'Free Tempo (1.000×)'}
          </span>
          {renderedRemix && (
            <span
              className={`px-2.5 py-1 rounded border tabular-nums ${
                renderedRemix.beatSyncTightnessPct >= 85
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                  : 'bg-amber-500/15 text-amber-300 border-amber-500/30'
              }`}
            >
              Grid Sync: {renderedRemix.beatSyncTightnessPct}% ({renderedRemix.avgBeatErrorMs.toFixed(1)} ms
              {renderedRemix.beatWarpActive ? ' · Warped' : ''})
            </span>
          )}
        </div>
      </section>

      {/* Dual Decks: Deck A (Instrumental) & Deck B (Vocals) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* DECK A: INSTRUMENTAL BED */}
        <section className="bg-[#12161F] border border-emerald-500/25 rounded-lg p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <Music className="w-4 h-4 text-emerald-400 shrink-0" />
              <div className="min-w-0">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-emerald-400">
                  Deck A · Instrumental Bed
                </div>
                <div className="text-sm font-semibold text-slate-100 truncate">
                  {instTrackName}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                ref={instFileRef}
                type="file"
                accept="audio/*,.mp3,.wav,.flac,.m4a,.aac,.ogg"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) onUploadInstFile(file);
                  e.target.value = '';
                }}
              />
              <button
                type="button"
                onClick={() => instFileRef.current?.click()}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-200 bg-[#1B212E] border border-white/[0.1] rounded hover:bg-[#232B3B] cursor-pointer"
              >
                <Upload className="w-3 h-3" />
                <span>Load Inst</span>
              </button>
              <select
                aria-label="Instrumental Demo Track"
                value={DEMO_TRACKS.some((d) => d.id === instTrackId) ? instTrackId : ''}
                onChange={(e) => {
                  if (e.target.value) onSelectInstDemo(e.target.value);
                }}
                className="px-2 py-1 text-xs text-slate-200 bg-[#0B0D11] border border-white/[0.1] rounded focus:outline-none focus:border-emerald-400 cursor-pointer"
              >
                {!DEMO_TRACKS.some((d) => d.id === instTrackId) && (
                  <option value="">Uploaded File</option>
                )}
                {DEMO_TRACKS.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.title} ({d.bpm} BPM)
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Deck A Demucs Status */}
          <div className="bg-[#0B0D11] border border-white/[0.06] rounded-md px-3 py-2 space-y-1.5">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-slate-400">
                BPM: <strong className="text-slate-100">{instBpm.toFixed(2)}</strong> ·{' '}
                {instAnalysis.totalBars} Bars
              </span>
              {instStems ? (
                <span className="text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {instStems.modelUsed} Stems Ready
                </span>
              ) : instIsSeparating ? (
                <span className="text-amber-300">
                  {instProgress?.pct ?? 0}% Separating...
                </span>
              ) : (
                <button
                  type="button"
                  onClick={onRetryInstDemucs}
                  className="inline-flex items-center gap-1 text-amber-300 hover:text-amber-200 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Run Demucs</span>
                </button>
              )}
            </div>
            {instIsSeparating && instProgress && (
              <div className="space-y-1">
                <progress
                  value={Math.max(4, instProgress.pct)}
                  max={100}
                  className="w-full h-1.5 rounded overflow-hidden accent-emerald-400 bg-slate-800 block"
                />
                <div className="text-[11px] text-slate-400">{instProgress.stage}</div>
              </div>
            )}
            {instError && <div className="text-xs text-red-400">{instError}</div>}
          </div>

          {/* Deck A Controls: Inst Start Bar & 3-Stem Balance */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="text-slate-300 font-medium">Instrumental Start Bar</span>
              <div className="flex items-center gap-1.5 font-mono">
                <button
                  type="button"
                  onClick={() =>
                    onChangeConfig((p) => ({
                      ...p,
                      instStartBar: Math.max(0, p.instStartBar - 1),
                    }))
                  }
                  className="px-2 py-0.5 bg-[#1B212E] border border-white/[0.08] rounded text-slate-200 hover:bg-[#232B3B] cursor-pointer"
                >
                  -1B
                </button>
                <span className="px-2.5 py-0.5 bg-[#0B0D11] border border-white/[0.08] rounded text-emerald-300 font-semibold tabular-nums">
                  Bar {remixConfig.instStartBar + 1}
                </span>
                <button
                  type="button"
                  onClick={() =>
                    onChangeConfig((p) => ({
                      ...p,
                      instStartBar: Math.min(
                        Math.max(0, instAnalysis.totalBars - 4),
                        p.instStartBar + 1
                      ),
                    }))
                  }
                  className="px-2 py-0.5 bg-[#1B212E] border border-white/[0.08] rounded text-slate-200 hover:bg-[#232B3B] cursor-pointer"
                >
                  +1B
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
              <label className="space-y-1 block">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-slate-400">Drums</span>
                  <span className="text-emerald-300">
                    {Math.round(remixConfig.instDrumsLevel * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1.4}
                  step={0.02}
                  value={remixConfig.instDrumsLevel}
                  onChange={(e) =>
                    onChangeConfig((p) => ({ ...p, instDrumsLevel: Number(e.target.value) }))
                  }
                  className="w-full accent-emerald-400 cursor-pointer"
                />
              </label>

              <label className="space-y-1 block">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-slate-400">Bass</span>
                  <span className="text-emerald-300">
                    {Math.round(remixConfig.instBassLevel * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1.4}
                  step={0.02}
                  value={remixConfig.instBassLevel}
                  onChange={(e) =>
                    onChangeConfig((p) => ({ ...p, instBassLevel: Number(e.target.value) }))
                  }
                  className="w-full accent-emerald-400 cursor-pointer"
                />
              </label>

              <label className="space-y-1 block">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-slate-400">Other</span>
                  <span className="text-emerald-300">
                    {Math.round(remixConfig.instOtherLevel * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1.4}
                  step={0.02}
                  value={remixConfig.instOtherLevel}
                  onChange={(e) =>
                    onChangeConfig((p) => ({ ...p, instOtherLevel: Number(e.target.value) }))
                  }
                  className="w-full accent-emerald-400 cursor-pointer"
                />
              </label>

              <label className="space-y-1 block">
                <div className="flex justify-between text-[11px] font-mono">
                  <span className="text-slate-400">Bed Gain</span>
                  <span className="text-slate-200">
                    {Math.round(remixConfig.instBedLevel * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={1.3}
                  step={0.02}
                  value={remixConfig.instBedLevel}
                  onChange={(e) =>
                    onChangeConfig((p) => ({ ...p, instBedLevel: Number(e.target.value) }))
                  }
                  className="w-full accent-emerald-400 cursor-pointer"
                />
              </label>
            </div>
          </div>
        </section>

        {/* DECK B: ACAPELLA VOCAL TRACK */}
        <section className="bg-[#12161F] border border-amber-500/25 rounded-lg p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <Mic className="w-4 h-4 text-amber-400 shrink-0" />
              <div className="min-w-0">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-amber-400">
                  Deck B · Vocal Track (Demucs Isolated)
                </div>
                <div className="text-sm font-semibold text-slate-100 truncate">
                  {vocalTrackName}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                ref={vocalFileRef}
                type="file"
                accept="audio/*,.mp3,.wav,.flac,.m4a,.aac,.ogg"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) onUploadVocalFile(file);
                  e.target.value = '';
                }}
              />
              <button
                type="button"
                onClick={() => vocalFileRef.current?.click()}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-[#0B0D11] bg-amber-500 rounded hover:bg-amber-400 cursor-pointer"
              >
                <Upload className="w-3 h-3" />
                <span>Load Vocal Song</span>
              </button>
              <select
                aria-label="Vocal Demo Track"
                value={DEMO_TRACKS.some((d) => d.id === vocalTrackId) ? vocalTrackId : ''}
                onChange={(e) => {
                  if (e.target.value) onSelectVocalDemo(e.target.value);
                }}
                className="px-2 py-1 text-xs text-slate-200 bg-[#0B0D11] border border-white/[0.1] rounded focus:outline-none focus:border-amber-400 cursor-pointer"
              >
                {!DEMO_TRACKS.some((d) => d.id === vocalTrackId) && (
                  <option value="">Uploaded Vocal Track</option>
                )}
                {DEMO_TRACKS.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.title} ({d.bpm} BPM)
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Deck B Demucs Status & Vocal BPM Controls */}
          <div className="bg-[#0B0D11] border border-white/[0.06] rounded-md px-3 py-2 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400">Vocal BPM:</span>
                <input
                  type="number"
                  step={0.1}
                  min={50}
                  max={210}
                  value={Number(remixConfig.vocalBpm.toFixed(2))}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    if (Number.isFinite(val) && val >= 50 && val <= 210) {
                      onChangeConfig((p) => ({ ...p, vocalBpm: val }));
                    }
                  }}
                  aria-label="Vocal Track BPM"
                  className="w-16 px-1.5 py-0.5 bg-[#12161F] border border-white/[0.12] rounded text-amber-300 text-xs tabular-nums focus:outline-none focus:border-amber-400"
                />
                <div className="inline-flex rounded border border-white/[0.08] overflow-hidden">
                  {(['0.5x', '1x', '2x'] as const).map((m) => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => onChangeConfig((p) => ({ ...p, halfDoubleTime: m }))}
                      title="Half-time or Double-time BPM interpret"
                      className={`px-1.5 py-0.5 text-[10px] cursor-pointer ${
                        remixConfig.halfDoubleTime === m
                          ? 'bg-amber-500 text-[#0B0D11] font-semibold'
                          : 'bg-[#12161F] text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              {vocalStems ? (
                <span className="text-amber-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {vocalStems.modelUsed} Vocals Isolated
                </span>
              ) : vocalIsSeparating ? (
                <span className="text-amber-300">
                  {vocalProgress?.pct ?? 0}% Isolating Vocals...
                </span>
              ) : (
                <button
                  type="button"
                  onClick={onRetryVocalDemucs}
                  className="inline-flex items-center gap-1 text-amber-300 hover:text-amber-200 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Extract Vocals</span>
                </button>
              )}
            </div>

            {vocalIsSeparating && vocalProgress && (
              <div className="space-y-1">
                <progress
                  value={Math.max(4, vocalProgress.pct)}
                  max={100}
                  className="w-full h-1.5 rounded overflow-hidden accent-amber-400 bg-slate-800 block"
                />
                <div className="text-[11px] text-slate-400">{vocalProgress.stage}</div>
              </div>
            )}
            {vocalError && <div className="text-xs text-red-400">{vocalError}</div>}
          </div>

          {/* Interactive Vocal Cue Selector Waveform */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">
                Click vocal waveform to pick starting verse/hook bar:
              </span>
              <div className="flex items-center gap-1.5 font-mono">
                <button
                  type="button"
                  onClick={() =>
                    onChangeConfig((p) => ({
                      ...p,
                      vocalCueBar: Math.max(0, p.vocalCueBar - 1),
                    }))
                  }
                  className="px-2 py-0.5 bg-[#1B212E] border border-white/[0.08] rounded text-slate-200 hover:bg-[#232B3B] cursor-pointer"
                >
                  -1B
                </button>
                <span className="px-2 py-0.5 bg-[#0B0D11] border border-white/[0.08] rounded text-amber-300 font-semibold tabular-nums">
                  Bar {remixConfig.vocalCueBar + 1}
                </span>
                <button
                  type="button"
                  onClick={() =>
                    onChangeConfig((p) => ({
                      ...p,
                      vocalCueBar: Math.min(
                        Math.max(0, (vocalAnalysis?.totalBars ?? 16) - 1),
                        p.vocalCueBar + 1
                      ),
                    }))
                  }
                  className="px-2 py-0.5 bg-[#1B212E] border border-white/[0.08] rounded text-slate-200 hover:bg-[#232B3B] cursor-pointer"
                >
                  +1B
                </button>
              </div>
            </div>

            <div className="bg-[#0B0D11] border border-white/[0.07] rounded-md overflow-hidden">
              <canvas
                ref={vocalSourceCanvasRef}
                onClick={handleClickVocalSource}
                className="w-full h-16 block cursor-crosshair"
              />
            </div>
          </div>
        </section>
      </div>

      {/* Beatmatch, Key & Mix Pocket Console */}
      <section className="bg-[#12161F] border border-white/[0.08] rounded-lg p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm font-semibold text-slate-100">
              Beatmatch, Downbeat Phase & Phrasing Console
            </h3>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={!instStems || !vocalStems}
              onClick={onAutoSyncRemix}
              title="Lock half/double-time BPM, downbeat phase rotation, vocal beat pickup, and 4-bar phrasing automatically using Demucs stems"
              className="px-3 py-1 text-xs font-semibold rounded border bg-sky-500/15 text-sky-300 border-sky-500/40 hover:bg-sky-500/25 disabled:opacity-40 transition-colors cursor-pointer"
            >
              Auto-Sync Beats & Phrase
            </button>

            <button
              type="button"
              onClick={() =>
                onChangeConfig((p) => ({ ...p, phraseLockEnabled: !p.phraseLockEnabled }))
              }
              title="Quantize song length and vocal phrase endings cleanly onto bar boundaries"
              className={`px-3 py-1 text-xs font-semibold rounded border transition-colors cursor-pointer ${
                remixConfig.phraseLockEnabled
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-[#0B0D11] text-slate-400 border-white/[0.08]'
              }`}
            >
              {remixConfig.phraseLockEnabled ? 'Phrase Lock: ON' : 'Phrase Lock: OFF'}
            </button>

            <button
              type="button"
              onClick={() =>
                onChangeConfig((p) => ({ ...p, autoBeatmatch: !p.autoBeatmatch }))
              }
              className={`px-3 py-1 text-xs font-semibold rounded border transition-colors cursor-pointer ${
                remixConfig.autoBeatmatch
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-[#0B0D11] text-slate-400 border-white/[0.08]'
              }`}
            >
              {remixConfig.autoBeatmatch ? 'Auto Beatmatch: ON' : 'Auto Beatmatch: OFF'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Vocal Drop Placement, Beat Shift & Timing Slip */}
          <div className="bg-[#0B0D11] border border-white/[0.06] rounded-md p-3 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">Vocal Entry Bar</span>
              <span className="font-mono text-amber-400 font-semibold">
                Drop @ Bar {remixConfig.vocalTargetDropBar + 1}
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {[0, 2, 4, 8].map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() =>
                    onChangeConfig((p) => ({ ...p, vocalTargetDropBar: b }))
                  }
                  className={`px-2 py-1 text-xs font-mono rounded border cursor-pointer ${
                    remixConfig.vocalTargetDropBar === b
                      ? 'bg-amber-500 text-[#0B0D11] border-amber-400 font-semibold'
                      : 'bg-[#12161F] text-slate-300 border-white/[0.08] hover:bg-[#1B212E]'
                  }`}
                >
                  Bar {b + 1}
                </button>
              ))}
              <button
                type="button"
                onClick={() =>
                  onChangeConfig((p) => ({
                    ...p,
                    vocalTargetDropBar: Math.max(0, p.vocalTargetDropBar - 1),
                  }))
                }
                className="px-2 py-1 text-xs font-mono bg-[#12161F] text-slate-300 border border-white/[0.08] rounded hover:bg-[#1B212E] cursor-pointer"
              >
                -1
              </button>
              <button
                type="button"
                onClick={() =>
                  onChangeConfig((p) => ({
                    ...p,
                    vocalTargetDropBar: p.vocalTargetDropBar + 1,
                  }))
                }
                className="px-2 py-1 text-xs font-mono bg-[#12161F] text-slate-300 border border-white/[0.08] rounded hover:bg-[#1B212E] cursor-pointer"
              >
                +1
              </button>
            </div>

            <div className="pt-1 border-t border-white/[0.06] space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-slate-400">Beat Phase Shift</span>
                <span className="text-sky-300 font-semibold">
                  {remixConfig.vocalBeatShift > 0 ? '+' : ''}
                  {remixConfig.vocalBeatShift} Beat{Math.abs(remixConfig.vocalBeatShift) === 1 ? '' : 's'}
                </span>
              </div>
              <div className="flex items-center gap-1">
                {([-1, -0.5, 0.5, 1] as const).map((delta) => (
                  <button
                    key={delta}
                    type="button"
                    onClick={() =>
                      onChangeConfig((p) => ({
                        ...p,
                        vocalBeatShift: Math.max(-3.5, Math.min(3.5, p.vocalBeatShift + delta)),
                      }))
                    }
                    className="flex-1 py-0.5 text-[10px] font-mono bg-[#12161F] border border-white/[0.08] rounded text-slate-300 hover:bg-[#1B212E] cursor-pointer"
                  >
                    {delta > 0 ? `+${delta}B` : `${delta}B`}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => onChangeConfig((p) => ({ ...p, vocalBeatShift: 0 }))}
                  title="Reset beat shift to 0"
                  className="p-1 bg-[#12161F] border border-white/[0.08] rounded text-slate-400 hover:text-slate-100 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                </button>
              </div>
            </div>

            <div className="pt-1 border-t border-white/[0.06] space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-slate-400">Pocket Slip (ms)</span>
                <span className="text-slate-200">
                  {remixConfig.vocalFineOffsetMs >= 0 ? '+' : ''}
                  {remixConfig.vocalFineOffsetMs} ms
                </span>
              </div>
              <div className="flex items-center gap-1">
                {[-30, -10, 10, 30].map((delta) => (
                  <button
                    key={delta}
                    type="button"
                    onClick={() =>
                      onChangeConfig((p) => ({
                        ...p,
                        vocalFineOffsetMs: Math.max(
                          -500,
                          Math.min(500, p.vocalFineOffsetMs + delta)
                        ),
                      }))
                    }
                    className="flex-1 py-0.5 text-[10px] font-mono bg-[#12161F] border border-white/[0.08] rounded text-slate-300 hover:bg-[#1B212E] cursor-pointer"
                  >
                    {delta > 0 ? `+${delta}` : delta}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => onChangeConfig((p) => ({ ...p, vocalFineOffsetMs: 0 }))}
                  title="Reset fine offset to 0 ms"
                  className="p-1 bg-[#12161F] border border-white/[0.08] rounded text-slate-400 hover:text-slate-100 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                </button>
              </div>
            </div>
          </div>

          {/* Harmonic Pitch / Key Shift */}
          <div className="bg-[#0B0D11] border border-white/[0.06] rounded-md p-3 space-y-2.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-medium">Key Match (Pitch Shift)</span>
              <span
                className={`font-mono font-semibold ${
                  remixConfig.pitchSemitones === 0 ? 'text-slate-300' : 'text-sky-400'
                }`}
              >
                {remixConfig.pitchSemitones > 0 ? '+' : ''}
                {remixConfig.pitchSemitones} st
              </span>
            </div>
            <input
              type="range"
              aria-label="Vocal Pitch Semitones"
              min={-6}
              max={6}
              step={1}
              value={remixConfig.pitchSemitones}
              onDoubleClick={() =>
                onChangeConfig((p) => ({ ...p, pitchSemitones: 0 }))
              }
              onChange={(e) =>
                onChangeConfig((p) => ({ ...p, pitchSemitones: Number(e.target.value) }))
              }
              className="w-full accent-sky-400 cursor-pointer"
            />
            <div className="flex items-center justify-between gap-1 text-[11px] font-mono">
              <button
                type="button"
                onClick={() =>
                  onChangeConfig((p) => ({
                    ...p,
                    pitchSemitones: Math.max(-6, p.pitchSemitones - 1),
                  }))
                }
                className="px-2 py-0.5 bg-[#12161F] border border-white/[0.08] rounded text-slate-300 hover:bg-[#1B212E] cursor-pointer"
              >
                -1 st
              </button>
              <button
                type="button"
                onClick={() => onChangeConfig((p) => ({ ...p, pitchSemitones: 0 }))}
                className="px-2 py-0.5 bg-[#12161F] border border-white/[0.08] rounded text-slate-300 hover:bg-[#1B212E] cursor-pointer"
              >
                Original Key
              </button>
              <button
                type="button"
                onClick={() =>
                  onChangeConfig((p) => ({
                    ...p,
                    pitchSemitones: Math.min(6, p.pitchSemitones + 1),
                  }))
                }
                className="px-2 py-0.5 bg-[#12161F] border border-white/[0.08] rounded text-slate-300 hover:bg-[#1B212E] cursor-pointer"
              >
                +1 st
              </button>
            </div>
            <div className="text-[11px] text-slate-500">
              Shifts vocal musical key without changing beatmatched tempo.
            </div>
          </div>

          {/* Vocal Level & Melodic Pocket Carve */}
          <div className="bg-[#0B0D11] border border-white/[0.06] rounded-md p-3 space-y-3">
            <label className="space-y-1 block">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Vocal Level</span>
                <span className="font-mono text-amber-400">
                  {Math.round(remixConfig.vocalLevel * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={1.5}
                step={0.02}
                value={remixConfig.vocalLevel}
                onChange={(e) =>
                  onChangeConfig((p) => ({ ...p, vocalLevel: Number(e.target.value) }))
                }
                className="w-full accent-amber-500 cursor-pointer"
              />
            </label>

            <label className="space-y-1 block">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">Melodic Pocket Carve</span>
                <span className="font-mono text-emerald-400">
                  {Math.round(remixConfig.pocketCarveAmount * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={remixConfig.pocketCarveAmount}
                onChange={(e) =>
                  onChangeConfig((p) => ({
                    ...p,
                    pocketCarveAmount: Number(e.target.value),
                  }))
                }
                className="w-full accent-emerald-400 cursor-pointer"
              />
              <div className="text-[10px] text-slate-500">
                Ducks Instrumental melodies when vocals sing while keeping Drums & Bass punchy.
              </div>
            </label>
          </div>

          {/* Studio Space & Vocal Mix Tone */}
          <div className="bg-[#0B0D11] border border-white/[0.06] rounded-md p-3 space-y-3">
            <label className="space-y-1 block">
              <div className="flex justify-between text-xs">
                <span className="text-slate-300 font-medium">BPM Vocal Space Glue</span>
                <span className="font-mono text-sky-400">
                  {Math.round((remixConfig.vocalSpaceAmount / 0.45) * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={0.45}
                step={0.01}
                value={remixConfig.vocalSpaceAmount}
                onChange={(e) =>
                  onChangeConfig((p) => ({
                    ...p,
                    vocalSpaceAmount: Number(e.target.value),
                  }))
                }
                className="w-full accent-sky-400 cursor-pointer"
              />
            </label>

            <div className="space-y-1">
              <span className="text-xs text-slate-300 font-medium block">Vocal Mix Tone</span>
              <div className="grid grid-cols-3 gap-1">
                {(
                  [
                    { id: 'natural', label: 'Natural' },
                    { id: 'pop-clarity', label: 'Clarity' },
                    { id: 'warm-club', label: 'Warm' },
                  ] as { id: RemixVocalTone; label: string }[]
                ).map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => onChangeConfig((p) => ({ ...p, vocalTone: t.id }))}
                    className={`py-1 text-[11px] font-medium rounded border cursor-pointer ${
                      remixConfig.vocalTone === t.id
                        ? 'bg-sky-500 text-[#0B0D11] border-sky-400 font-semibold'
                        : 'bg-[#12161F] text-slate-300 border-white/[0.08] hover:bg-[#1B212E]'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Master Beatmatched Remix Timeline & Audition Transport */}
      <section className="bg-[#12161F] border border-white/[0.08] rounded-lg p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <h3 className="text-sm font-semibold text-slate-100">
              Combined Beatmatched Remix Output
            </h3>
            {renderedRemix ? (
              <span className="text-xs font-mono tabular-nums text-slate-400">
                {formatClock(renderedRemix.totalDurationSec)} · Peak{' '}
                {renderedRemix.outputPeakDbfs.toFixed(1)} dBFS ·{' '}
                <span className={renderedRemix.passed ? 'text-emerald-400' : 'text-amber-300'}>
                  {renderedRemix.clippedSamples === 0 ? '0 Clips' : `${renderedRemix.clippedSamples} Clips`}
                </span>
              </span>
            ) : (
              <span className="text-xs text-amber-300">
                Waiting for Demucs separation on both Deck A (Instrumental) & Deck B (Vocals)...
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={!readyToRender}
              onClick={() => {
                if (isPlaying && activeDeck === 'remix') {
                  onStopPlayback();
                } else {
                  onSeekRemix('remix', activeDeck === 'remix' ? currentTimeSec : 0, true);
                }
              }}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border transition-colors cursor-pointer disabled:opacity-40 ${
                isPlaying && activeDeck === 'remix'
                  ? 'bg-emerald-500 text-[#0B0D11] border-emerald-400'
                  : 'bg-[#1B212E] text-slate-100 border-white/[0.12] hover:bg-[#232B3B]'
              }`}
            >
              {isPlaying && activeDeck === 'remix' ? (
                <>
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  <span>Pause Remix</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Play Remix</span>
                </>
              )}
            </button>

            <button
              type="button"
              disabled={!readyToRender}
              onClick={() => {
                if (isPlaying && activeDeck === 'remix-vocals') {
                  onStopPlayback();
                } else {
                  onSeekRemix(
                    'remix-vocals',
                    renderedRemix?.vocalDropSec ?? 0,
                    true
                  );
                }
              }}
              className={`px-2.5 py-1.5 text-xs font-medium rounded-md border transition-colors cursor-pointer disabled:opacity-40 ${
                isPlaying && activeDeck === 'remix-vocals'
                  ? 'bg-amber-500 text-[#0B0D11] border-amber-400 font-semibold'
                  : 'bg-amber-500/10 text-amber-300 border-amber-500/30 hover:bg-amber-500/20'
              }`}
            >
              {isPlaying && activeDeck === 'remix-vocals' ? 'Pause Synced Vocals' : 'Solo Synced Vocals'}
            </button>

            <button
              type="button"
              disabled={!readyToRender}
              onClick={() => {
                if (isPlaying && activeDeck === 'remix-inst') {
                  onStopPlayback();
                } else {
                  onSeekRemix(
                    'remix-inst',
                    renderedRemix?.vocalDropSec ?? 0,
                    true
                  );
                }
              }}
              className={`px-2.5 py-1.5 text-xs font-medium rounded-md border transition-colors cursor-pointer disabled:opacity-40 ${
                isPlaying && activeDeck === 'remix-inst'
                  ? 'bg-emerald-500 text-[#0B0D11] border-emerald-400 font-semibold'
                  : 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20'
              }`}
            >
              {isPlaying && activeDeck === 'remix-inst' ? 'Pause Inst Bed' : 'Solo Inst Bed'}
            </button>

            <button
              type="button"
              onClick={onToggleBeatClick}
              title="Audition beat-grid click (Preview only — never included in exported WAV)"
              className={`px-2.5 py-1.5 text-xs font-medium rounded-md border transition-colors cursor-pointer ${
                beatClickEnabled
                  ? 'bg-sky-500 text-[#0B0D11] border-sky-400 font-semibold'
                  : 'bg-[#1B212E] text-slate-300 border-white/[0.08] hover:bg-[#232B3B]'
              }`}
            >
              {beatClickEnabled ? 'Beat Click: ON' : 'Beat Click'}
            </button>

            <button
              type="button"
              disabled={!readyToRender}
              onClick={() => {
                if (!renderedRemix) return;
                onSeekRemix('remix', renderedRemix.vocalDropSec, true);
              }}
              className="px-2.5 py-1.5 text-xs font-medium text-slate-200 bg-[#1B212E] border border-white/[0.08] rounded-md hover:bg-[#232B3B] disabled:opacity-40 cursor-pointer"
            >
              Jump to Drop (Bar {remixConfig.vocalTargetDropBar + 1})
            </button>

            <button
              type="button"
              disabled={!readyToRender || isExporting}
              onClick={onExportRemixWav}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-[#0B0D11] bg-amber-500 rounded-md hover:bg-amber-400 disabled:opacity-40 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isExporting ? 'Exporting...' : 'Export Remix WAV'}</span>
            </button>
          </div>
        </div>

        <div className="relative bg-[#0B0D11] border border-white/[0.07] rounded-md overflow-hidden">
          {renderedRemix ? (
            <canvas
              ref={remixCanvasRef}
              onClick={handleClickRemixCanvas}
              className="w-full h-36 block cursor-pointer"
            />
          ) : (
            <div className="h-36 flex items-center justify-center text-xs text-slate-400">
              {isRemixPlaying ? 'Preparing...' : 'Click Play Remix once both tracks finish Demucs 4-stem separation.'}
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
          <div className="flex items-center gap-4">
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-emerald-400 inline-block" />
              Deck A Instrumental Bed (Drums + Bass + Other)
            </span>
            <span className="inline-flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-xs bg-amber-400 inline-block" />
              Deck B Beatmatched Demucs Vocals
            </span>
          </div>
          <span>Click anywhere on waveform to audition from that beat</span>
        </div>
      </section>
    </div>
  );
};
