import React from 'react';
import { RotateCcw } from 'lucide-react';
import {
  DemucsStemSet,
  IntroArrangementMode,
  IntroEditConfig,
  IntroLoopStructure,
  TrackAnalysis,
  TransitionBlendMode,
} from '../types/audio';

interface EditControlsPanelProps {
  analysis: TrackAnalysis;
  config: IntroEditConfig;
  stemSet: DemucsStemSet | null;
  onChangeConfig: (updater: (prev: IntroEditConfig) => IntroEditConfig) => void;
  onResetAuto: () => void;
  onReanalyzeWithBpm: (bpm: number, downbeatSec: number) => void;
}

export const EditControlsPanel: React.FC<EditControlsPanelProps> = ({
  analysis,
  config,
  stemSet,
  onChangeConfig,
  onResetAuto,
  onReanalyzeWithBpm,
}) => {
  const beatSec = 60 / config.bpm;
  const phraseBars = config.loopStructure === '4-bar-x2' ? 4 : 8;

  return (
    <section className="grid grid-cols-1 lg:grid-cols-3 gap-5">
      {/* Column 1: Tempo & Beat-Grid Lock */}
      <div className="bg-[#12161F] border border-white/[0.08] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-100">Tempo & Grid Lock</h3>
          <button
            type="button"
            onClick={onResetAuto}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-400 hover:text-slate-100 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Auto-Detect</span>
          </button>
        </div>

        <div className="flex items-baseline justify-between py-2 border-y border-white/[0.06]">
          <div>
            <div className="text-xs text-slate-400">Locked Tempo</div>
            <div className="text-2xl font-bold font-mono text-slate-100 tracking-tight">
              {config.bpm.toFixed(2)}{' '}
              <span className="text-xs font-normal text-slate-400">BPM</span>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                const next = Math.max(60, Math.round((config.bpm / 2) * 100) / 100);
                onReanalyzeWithBpm(next, config.firstDownbeatSec);
              }}
              className="px-2.5 py-1.5 text-xs font-mono text-slate-300 bg-[#1B212E] border border-white/[0.08] rounded hover:bg-[#232B3B] transition-colors cursor-pointer"
            >
              ÷2
            </button>
            <button
              type="button"
              onClick={() => {
                const next = Math.min(200, Math.round(config.bpm * 2 * 100) / 100);
                onReanalyzeWithBpm(next, config.firstDownbeatSec);
              }}
              className="px-2.5 py-1.5 text-xs font-mono text-slate-300 bg-[#1B212E] border border-white/[0.08] rounded hover:bg-[#232B3B] transition-colors cursor-pointer"
            >
              ×2
            </button>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-slate-400">Fine BPM Nudge</span>
            <div className="flex items-center gap-1">
              {[-0.5, -0.1, 0.1, 0.5].map((delta) => (
                <button
                  key={delta}
                  type="button"
                  onClick={() => {
                    const next = Math.round((config.bpm + delta) * 100) / 100;
                    onReanalyzeWithBpm(next, config.firstDownbeatSec);
                  }}
                  className="px-2 py-1 text-xs font-mono text-slate-300 bg-[#0B0D11] border border-white/[0.08] rounded hover:border-white/20 transition-colors cursor-pointer"
                >
                  {delta > 0 ? `+${delta}` : delta}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-slate-400">
              Downbeat Phase ({Math.round(config.firstDownbeatSec * 1000)} ms)
            </span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => {
                  const next = Math.max(0, config.firstDownbeatSec - beatSec);
                  onReanalyzeWithBpm(config.bpm, next);
                }}
                className="px-2 py-1 text-xs font-mono text-slate-300 bg-[#0B0D11] border border-white/[0.08] rounded hover:border-white/20 transition-colors cursor-pointer"
              >
                -1 Beat
              </button>
              <button
                type="button"
                onClick={() => {
                  const next = (config.firstDownbeatSec + beatSec) % analysis.barSec;
                  onReanalyzeWithBpm(config.bpm, next);
                }}
                className="px-2 py-1 text-xs font-mono text-slate-300 bg-[#0B0D11] border border-white/[0.08] rounded hover:border-white/20 transition-colors cursor-pointer"
              >
                +1 Beat
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
            <span>Cue 1 Target Bar</span>
            <div className="flex items-center gap-1.5 font-mono text-amber-400">
              <button
                type="button"
                onClick={() =>
                  onChangeConfig((p) => ({
                    ...p,
                    cue1Bar: Math.max(0, p.cue1Bar - 1),
                    cue1ExactSec: null,
                  }))
                }
                className="px-2 py-0.5 bg-[#0B0D11] border border-white/[0.08] rounded text-slate-300 hover:text-white cursor-pointer"
              >
                -
              </button>
              <span className="w-16 text-center tabular-nums">
                {config.cue1ExactSec != null
                  ? `${config.cue1ExactSec.toFixed(2)}s`
                  : `Bar ${config.cue1Bar + 1}`}
              </span>
              <button
                type="button"
                onClick={() =>
                  onChangeConfig((p) => ({
                    ...p,
                    cue1Bar: Math.min(analysis.totalBars - 1, p.cue1Bar + 1),
                    cue1ExactSec: null,
                  }))
                }
                className="px-2 py-0.5 bg-[#0B0D11] border border-white/[0.08] rounded text-slate-300 hover:text-white cursor-pointer"
              >
                +
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Column 2: Demucs DJ Intro Arrangement & Intelligent Stem Mixing */}
      <div className="bg-[#12161F] border border-white/[0.08] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-100">Demucs Intro Builder</h3>
          <span className="text-xs font-mono tabular-nums text-emerald-400">
            Bars {config.donorStartBar + 1}–{config.donorStartBar + phraseBars}
          </span>
        </div>

        <div className="space-y-2">
          <span className="text-xs text-slate-400 block">8-Bar Loop Structure</span>
          <div className="grid grid-cols-2 gap-1 p-1 bg-[#0B0D11] border border-white/[0.08] rounded-md">
            {(
              [
                { id: '8-bar-continuous', label: '8-Bar Phrase' },
                { id: '4-bar-x2', label: '4-Bar × 2 Loop' },
              ] as { id: IntroLoopStructure; label: string }[]
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => onChangeConfig((p) => ({ ...p, loopStructure: opt.id }))}
                className={`py-1.5 px-2 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  config.loopStructure === opt.id
                    ? 'bg-[#1D2432] text-slate-100'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <span className="text-xs text-slate-400 block">
            Stem Intro Arrangement (Vocals Excluded)
          </span>
          <div className="grid grid-cols-3 gap-1 p-1 bg-[#0B0D11] border border-white/[0.08] rounded-md">
            {(
              [
                { id: 'progressive-build', label: 'DJ Build' },
                { id: 'full-instrumental', label: 'Full Inst' },
                { id: 'custom-automation', label: 'Custom' },
              ] as { id: IntroArrangementMode; label: string }[]
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => onChangeConfig((p) => ({ ...p, introArrangement: opt.id }))}
                className={`py-1.5 px-2 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  config.introArrangement === opt.id
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    : 'text-slate-400 hover:text-slate-200 border border-transparent'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
          <p className="text-[11px] text-slate-400">
            {config.introArrangement === 'progressive-build'
              ? 'Bars 1–2 Drums → Bar 3 Bass → Bars 5–8 Melodies & Instruments → Bar 9 Cue 1 Vocals.'
              : config.introArrangement === 'full-instrumental'
                ? 'Full Demucs instrumental stems (Drums + Bass + Other) locked across Bars 1–8.'
                : 'Uses per-stem Intro Bar & Intro Level automation in the 4-Stem Editor above.'}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2 pt-1">
          {(
            [
              { key: 'bassSwapEnabled', label: 'Bass Swap' },
              { key: 'kickPreservationEnabled', label: 'Kick Preserve' },
              { key: 'phaseAwareMixing', label: 'Phase-Aware' },
              { key: 'phraseAwareTransition', label: 'Phrase-Lock' },
            ] as const
          ).map((toggle) => {
            const active = config[toggle.key];
            return (
              <button
                key={toggle.key}
                type="button"
                onClick={() =>
                  onChangeConfig((p) => ({ ...p, [toggle.key]: !p[toggle.key] }))
                }
                className={`px-2.5 py-1.5 text-xs font-medium rounded border text-left transition-colors cursor-pointer ${
                  active
                    ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                    : 'bg-[#0B0D11] text-slate-400 border-white/[0.08] hover:text-slate-200'
                }`}
              >
                {active ? '✓ ' : ''}
                {toggle.label}
              </button>
            );
          })}
        </div>

        {stemSet && (
          <div className="text-[11px] font-mono text-slate-400 pt-1 border-t border-white/[0.06] flex justify-between">
            <span>Model: {stemSet.modelUsed}</span>
            <span>Recon SNR: {stemSet.qc.reconstructionSnrDb.toFixed(1)} dB</span>
          </div>
        )}
      </div>

      {/* Column 3: Seamless Bar 8 -> Cue 1 Transition & Groove Energy */}
      <div className="bg-[#12161F] border border-white/[0.08] rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-100">
            Seamless Bar 8 → Cue 1 Mix
          </h3>
          <span className="text-xs font-mono text-amber-400">Zero Break</span>
        </div>

        <div className="space-y-2">
          <span className="text-xs text-slate-400 block">Seam Crossfade Behavior</span>
          <div className="grid grid-cols-3 gap-1 p-1 bg-[#0B0D11] border border-white/[0.08] rounded-md">
            {(
              [
                { id: 'tight-cut', label: 'Tight Cut' },
                { id: 'beat-blend', label: '1-Beat Blend' },
                { id: 'bar-overlap', label: '1-Bar Glide' },
              ] as { id: TransitionBlendMode; label: string }[]
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => onChangeConfig((p) => ({ ...p, transitionBlend: opt.id }))}
                className={`py-1.5 px-2 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  config.transitionBlend === opt.id
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'text-slate-400 hover:text-slate-200 border border-transparent'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Bar 7–8 Groove Energy Lift</span>
            <span className="font-mono text-slate-200">
              {Math.round(config.grooveLiftAmount * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={Math.round(config.grooveLiftAmount * 100)}
            onChange={(e) =>
              onChangeConfig((p) => ({
                ...p,
                grooveLiftAmount: Number(e.target.value) / 100,
              }))
            }
            className="w-full accent-amber-500 cursor-pointer"
          />
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Drum & Sub-Bass Punch</span>
            <span className="font-mono text-slate-200">
              {Math.round(config.drumPunchBoost * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={Math.round(config.drumPunchBoost * 100)}
            onChange={(e) =>
              onChangeConfig((p) => ({
                ...p,
                drumPunchBoost: Number(e.target.value) / 100,
              }))
            }
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>
      </div>
    </section>
  );
};
