import React, { useRef, useState } from 'react';
import { Upload, Disc3 } from 'lucide-react';
import { DEMO_TRACKS } from '../audio/demoTracks';

interface TrackSourceViewProps {
  currentTrackId: string;
  currentTrackName: string;
  onUploadFile: (file: File) => void;
  onSelectDemo: (demoId: string) => void;
}

export const TrackSourceView: React.FC<TrackSourceViewProps> = ({
  currentTrackId,
  currentTrackName,
  onUploadFile,
  onSelectDemo,
}) => {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      onUploadFile(file);
    }
  };

  return (
    <div className="space-y-6">
      <section
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`bg-[#12161F] border rounded-lg p-8 text-center transition-colors ${
          isDragging ? 'border-amber-500 bg-amber-500/[0.06]' : 'border-white/[0.1] border-dashed'
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept="audio/*,.mp3,.wav,.flac,.m4a,.aac,.ogg"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) onUploadFile(file);
            e.target.value = '';
          }}
        />
        <div className="max-w-md mx-auto space-y-3">
          <div className="w-11 h-11 rounded-lg bg-[#1B212E] border border-white/[0.08] flex items-center justify-center mx-auto text-amber-400">
            <Upload className="w-5 h-5" />
          </div>
          <h2 className="text-base font-semibold text-slate-100">
            Load Any Track for Automatic 8-Bar Demucs DJ Intro
          </h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            Drop an MP3, WAV, FLAC, M4A, or OGG file here. CueGrid locks the tempo grid, locates Cue 1 (First Verse), and separates the intro via HTDemucs 4-stem isolation (Drums + Bass + Melodies) with zero lead or background vocals.
          </p>
          <div className="pt-2">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              className="px-4 py-2 text-xs font-semibold text-[#0B0D11] bg-amber-500 rounded-md hover:bg-amber-400 transition-colors cursor-pointer"
            >
              Choose Audio File
            </button>
          </div>
        </div>
      </section>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-100">
            Studio Groove Reference Tracks
          </h3>
          <span className="text-xs text-slate-400">Active: {currentTrackName}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {DEMO_TRACKS.map((track) => {
            const active = currentTrackId === track.id;
            return (
              <button
                key={track.id}
                type="button"
                onClick={() => onSelectDemo(track.id)}
                className={`text-left p-5 rounded-lg border transition-colors cursor-pointer space-y-2.5 ${
                  active
                    ? 'bg-[#171D29] border-amber-500/60'
                    : 'bg-[#12161F] border-white/[0.08] hover:border-white/20'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-semibold text-slate-100 truncate">
                    {track.title}
                  </span>
                  <Disc3
                    className={`w-4 h-4 shrink-0 ${
                      active ? 'text-amber-400' : 'text-slate-500'
                    }`}
                  />
                </div>
                <div className="text-xs font-mono text-slate-400">
                  {track.bpm} BPM · {track.genre} · {track.key}
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{track.description}</p>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
};
