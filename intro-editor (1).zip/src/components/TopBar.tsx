import React from 'react';
import { Download } from 'lucide-react';

export type ActiveTab = 'studio' | 'remix' | 'transition' | 'library';

interface TopBarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onExportWav: () => void;
  canExport: boolean;
  isExporting: boolean;
  exportLabel?: string;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeTab,
  onSelectTab,
  onExportWav,
  canExport,
  isExporting,
  exportLabel = 'Export WAV',
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-6 h-14 border-b border-white/[0.08] bg-[#0E1117]">
      <button
        type="button"
        onClick={() => onSelectTab('studio')}
        className="text-lg font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded"
      >
        CueGrid
      </button>

      <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
        <button
          type="button"
          onClick={() => onSelectTab('studio')}
          className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
            activeTab === 'studio'
              ? 'text-slate-100 border-amber-500'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          Intro Studio
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('remix')}
          className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
            activeTab === 'remix'
              ? 'text-slate-100 border-emerald-400'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          Vocal Remix
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('transition')}
          className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
            activeTab === 'transition'
              ? 'text-slate-100 border-amber-500'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          Transition Check
        </button>
        <button
          type="button"
          onClick={() => onSelectTab('library')}
          className={`py-1 transition-colors whitespace-nowrap shrink-0 cursor-pointer border-b-2 ${
            activeTab === 'library'
              ? 'text-slate-100 border-amber-500'
              : 'text-slate-400 border-transparent hover:text-slate-200'
          }`}
        >
          Track Source
        </button>
      </nav>

      <div className="flex items-center shrink-0">
        <button
          type="button"
          onClick={onExportWav}
          disabled={!canExport || isExporting}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#0B0D11] bg-amber-500 rounded-md hover:bg-amber-400 disabled:opacity-40 disabled:cursor-not-allowed transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400"
        >
          <Download className="w-3.5 h-3.5" />
          <span>{isExporting ? 'Exporting...' : exportLabel}</span>
        </button>
      </div>
    </header>
  );
};
