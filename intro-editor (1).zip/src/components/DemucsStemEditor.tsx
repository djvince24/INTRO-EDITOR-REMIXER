import React, { useEffect, useRef, useState } from 'react';
import { Scissors, Play, Trash2, RefreshCw, CheckCircle2, AlertTriangle } from 'lucide-react';
import {
  DemucsHardwareCapabilities,
  DemucsStemSet,
  IntroEditConfig,
  PlaybackDeck,
  StemName,
  TrackAnalysis,
} from '../types/audio';

interface DemucsStemEditorProps {
  analysis: TrackAnalysis;
  config: IntroEditConfig;
  stemSet: DemucsStemSet | null;
  capabilities: DemucsHardwareCapabilities | null;
  isSeparating: boolean;
  progress: { pct: number; stage: string } | null;
  demucsError: string | null;
  activeDeck: PlaybackDeck;
  currentTimeSec: number;
  isPlaying: boolean;
  onChangeConfig: (updater: (prev: IntroEditConfig) => IntroEditConfig) => void;
  onRunDemucs: () => void;
  onSeek: (deck: 'edit' | 'original' | 'stems-mix', timeSec: number, autoPlay?: boolean) => void;
}

const STEM_META: Array<{
  id: StemName;
  label: string;
  color: string;
  fillRgba: string;
  badgeClass: string;
}> = [
  {
    id: 'vocals',
    label: 'VOCALS',
    color: '#F59E0B',
    fillRgba: 'rgba(245, 158, 11, 0.85)',
    badgeClass: 'text-amber-300 bg-amber-500/15 border-amber-500/30',
  },
  {
    id: 'drums',
    label: 'DRUMS',
    color: '#10B981',
    fillRgba: 'rgba(16, 185, 129, 0.85)',
    badgeClass: 'text-emerald-300 bg-emerald-500/15 border-emerald-500/30',
  },
  {
    id: 'bass',
    label: 'BASS',
    color: '#38BDF8',
    fillRgba: 'rgba(56, 189, 248, 0.85)',
    badgeClass: 'text-sky-300 bg-sky-500/15 border-sky-500/30',
  },
  {
    id: 'other',
    label: 'OTHER',
    color: '#A78BFA',
    fillRgba: 'rgba(167, 139, 250, 0.85)',
    badgeClass: 'text-violet-300 bg-violet-500/15 border-violet-500/30',
  },
];

function formatTime(sec: number): string {
  const s = Math.max(0, sec);
  const mins = Math.floor(s / 60);
  const rem = s - mins * 60;
  return `${String(mins).padStart(2, '0')}:${rem.toFixed(2).padStart(5, '0')}`;
}

export const DemucsStemEditor: React.FC<DemucsStemEditorProps> = ({
  analysis,
  config,
  stemSet,
  capabilities,
  isSeparating,
  progress,
  demucsError,
  activeDeck,
  currentTimeSec,
  isPlaying,
  onChangeConfig,
  onRunDemucs,
  onSeek,
}) => {
  const canvasRefs = useRef<Record<StemName, HTMLCanvasElement | null>>({
    vocals: null,
    drums: null,
    bass: null,
    other: null,
  });

  const [selection, setSelection] = useState<{
    stem: StemName;
    startSec: number;
    endSec: number;
  } | null>(null);
  const dragStateRef = useRef<{
    stem: StemName;
    anchorSec: number;
    moved: boolean;
  } | null>(null);

  const anySolo = STEM_META.some((s) => config.stems[s.id].solo);
  const dur = analysis.durationSec;

  // Draw all 4 Demucs stem waveforms with cuts, fade envelopes, Cue 1 / Donor markers & playhead
  useEffect(() => {
    for (const meta of STEM_META) {
      const canvas = canvasRefs.current[meta.id];
      if (!canvas) continue;
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) continue;

      canvas.width = Math.floor(rect.width * dpr);
      canvas.height = Math.floor(rect.height * dpr);
      const ctx = canvas.getContext('2d');
      if (!ctx) continue;

      ctx.scale(dpr, dpr);
      const w = rect.width;
      const h = rect.height;
      ctx.clearRect(0, 0, w, h);

      const st = config.stems[meta.id];
      const isMuted = anySolo ? !st.solo : st.mute;

      // Donor loop highlight & Cue 1 line
      const donorStartSec =
        config.donorStartExactSec != null
          ? config.donorStartExactSec
          : config.firstDownbeatSec + config.donorStartBar * analysis.barSec;
      const phraseBars = config.loopStructure === '4-bar-x2' ? 4 : 8;
      const donorEndSec = donorStartSec + phraseBars * analysis.barSec;
      const dx1 = (donorStartSec / dur) * w;
      const dx2 = (donorEndSec / dur) * w;
      ctx.fillStyle = 'rgba(16, 185, 129, 0.08)';
      ctx.fillRect(dx1, 0, Math.max(0, dx2 - dx1), h);

      const cue1Sec =
        config.cue1ExactSec != null
          ? config.cue1ExactSec
          : config.firstDownbeatSec + config.cue1Bar * analysis.barSec;
      const cx = (cue1Sec / dur) * w;
      ctx.strokeStyle = 'rgba(245, 158, 11, 0.55)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(cx, 0);
      ctx.lineTo(cx, h);
      ctx.stroke();

      // Center line
      const midY = h * 0.5;
      ctx.strokeStyle = 'rgba(255,255,255,0.06)';
      ctx.beginPath();
      ctx.moveTo(0, midY);
      ctx.lineTo(w, midY);
      ctx.stroke();

      if (stemSet) {
        const peaks = stemSet.peaks[meta.id];
        const barW = Math.max(1, w / peaks.length);
        ctx.fillStyle = isMuted ? 'rgba(100, 116, 139, 0.25)' : meta.fillRgba;
        const volScale = isMuted ? 0.35 : Math.min(1.25, Math.max(0.15, st.volume));

        for (let i = 0; i < peaks.length; i++) {
          const x = (i / peaks.length) * w;
          const amp = Math.min(1, peaks[i] * volScale) * (h * 0.44);
          ctx.fillRect(x, midY - amp, Math.max(1, barW - 0.3), Math.max(1, amp * 2));
        }
      }

      // Draw fade-in / fade-out shaded ramps
      if (st.fadeInSec > 0) {
        const fw = Math.min(w, (st.fadeInSec / dur) * w);
        ctx.fillStyle = 'rgba(11, 13, 17, 0.55)';
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(fw, 0);
        ctx.lineTo(0, h);
        ctx.closePath();
        ctx.fill();
      }
      if (st.fadeOutSec > 0) {
        const fw = Math.min(w, (st.fadeOutSec / dur) * w);
        ctx.fillStyle = 'rgba(11, 13, 17, 0.55)';
        ctx.beginPath();
        ctx.moveTo(w, 0);
        ctx.lineTo(w - fw, 0);
        ctx.lineTo(w, h);
        ctx.closePath();
        ctx.fill();
      }

      // Draw cut regions on this stem
      for (const cut of config.cuts) {
        if (cut.stem !== meta.id) continue;
        const x0 = (cut.startSec / dur) * w;
        const x1 = (cut.endSec / dur) * w;
        ctx.fillStyle = 'rgba(239, 68, 68, 0.28)';
        ctx.fillRect(x0, 0, Math.max(2, x1 - x0), h);
        ctx.strokeStyle = '#EF4444';
        ctx.lineWidth = 1;
        ctx.strokeRect(x0, 0.5, Math.max(2, x1 - x0), h - 1);
      }

      // Draw active drag selection
      if (selection && selection.stem === meta.id) {
        const sMin = Math.min(selection.startSec, selection.endSec);
        const sMax = Math.max(selection.startSec, selection.endSec);
        const x0 = (sMin / dur) * w;
        const x1 = (sMax / dur) * w;
        ctx.fillStyle = 'rgba(248, 250, 252, 0.16)';
        ctx.fillRect(x0, 0, Math.max(2, x1 - x0), h);
        ctx.strokeStyle = '#F8FAFC';
        ctx.lineWidth = 1;
        ctx.strokeRect(x0, 0.5, Math.max(2, x1 - x0), h - 1);
      }

      // Playhead when auditioning original or 4-stem mix
      if (activeDeck === 'stems-mix' || activeDeck === 'original') {
        const px = Math.min(w, Math.max(0, (currentTimeSec / dur) * w));
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(px, 0);
        ctx.lineTo(px, h);
        ctx.stroke();
      }
    }
  }, [stemSet, config, analysis, anySolo, dur, selection, activeDeck, currentTimeSec]);

  const timeFromPointer = (e: React.MouseEvent<HTMLCanvasElement>): number => {
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = rect.width > 0 ? Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width)) : 0;
    return ratio * dur;
  };

  const handleMouseDown = (stem: StemName, e: React.MouseEvent<HTMLCanvasElement>) => {
    const sec = timeFromPointer(e);
    dragStateRef.current = { stem, anchorSec: sec, moved: false };
    setSelection({ stem, startSec: sec, endSec: sec });
  };

  const handleMouseMove = (stem: StemName, e: React.MouseEvent<HTMLCanvasElement>) => {
    const drag = dragStateRef.current;
    if (!drag || drag.stem !== stem) return;
    const sec = timeFromPointer(e);
    if (Math.abs(sec - drag.anchorSec) > Math.max(0.15, dur * 0.005)) {
      drag.moved = true;
    }
    setSelection({
      stem,
      startSec: Math.min(drag.anchorSec, sec),
      endSec: Math.max(drag.anchorSec, sec),
    });
  };

  const handleMouseUp = (stem: StemName, e: React.MouseEvent<HTMLCanvasElement>) => {
    const drag = dragStateRef.current;
    dragStateRef.current = null;
    if (!drag || drag.stem !== stem) return;

    const sec = timeFromPointer(e);
    if (!drag.moved) {
      setSelection(null);
      onSeek('stems-mix', sec, true);
    }
  };

  const handleCutSelection = () => {
    if (!selection) return;
    const startSec = Math.min(selection.startSec, selection.endSec);
    const endSec = Math.max(selection.startSec, selection.endSec);
    if (endSec - startSec < 0.05) return;

    onChangeConfig((p) => ({
      ...p,
      cuts: [
        ...p.cuts,
        {
          id: `cut-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          stem: selection.stem,
          startSec,
          endSec,
        },
      ],
    }));
    setSelection(null);
  };

  const updateStem = (
    stem: StemName,
    patch: Partial<IntroEditConfig['stems'][StemName]>
  ) => {
    onChangeConfig((p) => ({
      ...p,
      stems: {
        ...p.stems,
        [stem]: {
          ...p.stems[stem],
          ...patch,
        },
      },
    }));
  };

  return (
    <section className="bg-[#12161F] border border-white/[0.08] rounded-lg p-5 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="space-y-0.5">
          <div className="flex flex-wrap items-center gap-2.5">
            <h2 className="text-sm font-semibold text-slate-100">
              Demucs 4-Stem Separation & Editor
            </h2>
            {stemSet ? (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[11px] font-mono rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                <CheckCircle2 className="w-3 h-3" />
                <span>
                  {stemSet.modelUsed} · {stemSet.providerUsed}
                  {stemSet.fromCache ? ' · Cached' : ''}
                </span>
              </span>
            ) : isSeparating ? (
              <span className="px-2 py-0.5 text-[11px] font-mono rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">
                Separating 4 Stems...
              </span>
            ) : null}
          </div>
          <p className="text-xs text-slate-400">
            Click any stem waveform to audition 4-stem mix, or drag across a stem to select & cut sections.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {capabilities && (
            <span className="text-[11px] font-mono text-slate-400 bg-[#0B0D11] border border-white/[0.07] px-2.5 py-1.5 rounded">
              {capabilities.hasGpu
                ? `GPU: ${capabilities.gpuName}`
                : `CPU: ${capabilities.cpuCores} Cores · ${Math.round(capabilities.totalMemMb / 1024)} GB`}
            </span>
          )}

          <select
            aria-label="Demucs Model"
            value={config.demucsModelPreference}
            onChange={(e) =>
              onChangeConfig((p) => ({
                ...p,
                demucsModelPreference: e.target.value as IntroEditConfig['demucsModelPreference'],
              }))
            }
            className="px-2.5 py-1.5 text-xs font-mono text-slate-200 bg-[#0B0D11] border border-white/[0.1] rounded focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="auto">
              Auto ({capabilities?.recommendedModel || 'htdemucs'})
            </option>
            <option value="htdemucs">htdemucs (Fast 4-Stem)</option>
            <option value="htdemucs_ft">htdemucs_ft (4-Model Ensemble)</option>
          </select>

          <button
            type="button"
            onClick={onRunDemucs}
            disabled={isSeparating}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded hover:bg-emerald-500/20 disabled:opacity-50 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSeparating ? 'animate-spin' : ''}`} />
            <span>{isSeparating ? `${progress?.pct ?? 0}%` : stemSet ? 'Re-Run Demucs' : 'Run Demucs'}</span>
          </button>

          <button
            type="button"
            onClick={() => onSeek('stems-mix', activeDeck === 'stems-mix' && isPlaying ? currentTimeSec : 0, true)}
            disabled={!stemSet}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded border transition-colors cursor-pointer disabled:opacity-40 ${
              activeDeck === 'stems-mix'
                ? 'bg-sky-500 text-[#0B0D11] border-sky-400'
                : 'bg-[#1B212E] text-slate-200 border-white/[0.1] hover:bg-[#232B3B]'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Preview 4-Stem Mix</span>
          </button>
        </div>
      </div>

      {isSeparating && (
        <div className="bg-[#0B0D11] border border-white/[0.08] rounded-md p-3 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-200 font-medium">
              {progress?.stage || 'Initializing Demucs neural network...'}
            </span>
            <span className="font-mono text-emerald-400 tabular-nums">
              {progress?.pct ?? 0}%
            </span>
          </div>
          <div className="w-full h-1.5 bg-[#161B26] rounded-full overflow-hidden">
            <div
              className="h-full bg-emerald-500 transition-all duration-150"
              style={{ width: `${Math.max(3, progress?.pct ?? 3)}%` }}
            />
          </div>
        </div>
      )}

      {demucsError && (
        <div className="flex items-center justify-between gap-3 bg-red-500/10 border border-red-500/30 text-red-200 text-xs px-3.5 py-2.5 rounded-md">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{demucsError}</span>
          </div>
          <button
            type="button"
            onClick={onRunDemucs}
            className="px-2.5 py-1 font-semibold bg-red-500/20 border border-red-400/40 rounded hover:bg-red-500/30 cursor-pointer shrink-0"
          >
            Retry
          </button>
        </div>
      )}

      {/* Active drag selection toolbar */}
      {selection && Math.abs(selection.endSec - selection.startSec) >= 0.05 && (
        <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0B0D11] border border-amber-500/35 rounded-md px-3.5 py-2 text-xs">
          <div className="font-mono text-slate-200">
            Selected <span className="uppercase text-amber-300 font-semibold">{selection.stem}</span>:{' '}
            {formatTime(selection.startSec)} – {formatTime(selection.endSec)} (
            {(selection.endSec - selection.startSec).toFixed(2)}s)
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onSeek('stems-mix', selection.startSec, true)}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-200 bg-[#1B212E] border border-white/[0.1] rounded hover:bg-[#232B3B] cursor-pointer"
            >
              <Play className="w-3 h-3" />
              <span>Audition</span>
            </button>
            <button
              type="button"
              onClick={handleCutSelection}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-[#0B0D11] bg-red-400 rounded hover:bg-red-300 cursor-pointer"
            >
              <Scissors className="w-3 h-3" />
              <span>Cut Section</span>
            </button>
            <button
              type="button"
              onClick={() => setSelection(null)}
              className="px-2 py-1 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* 4 Stacked Stem Rows */}
      <div className="space-y-2.5">
        {STEM_META.map((meta) => {
          const st = config.stems[meta.id];
          const isMuted = anySolo ? !st.solo : st.mute;
          const stemCuts = config.cuts.filter((c) => c.stem === meta.id);
          const metric = stemSet?.qc?.stems?.[meta.id];

          return (
            <div
              key={meta.id}
              className="bg-[#0B0D11] border border-white/[0.07] rounded-md p-2.5 grid grid-cols-1 lg:grid-cols-[270px_1fr] gap-3 items-center"
            >
              {/* Left Stem Channel Controls */}
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`px-2 py-0.5 text-[11px] font-mono font-semibold rounded border ${meta.badgeClass}`}
                    >
                      {meta.label}
                    </span>
                    {metric && (
                      <span className="text-[10px] font-mono text-slate-500">
                        {metric.peakDbfs > -100 ? `${metric.peakDbfs.toFixed(1)} dB` : '-inf'}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => updateStem(meta.id, { mute: !st.mute })}
                      title={`Mute ${meta.label}`}
                      className={`w-6 h-6 text-[11px] font-mono font-bold rounded border transition-colors cursor-pointer ${
                        st.mute
                          ? 'bg-red-500/25 text-red-300 border-red-500/40'
                          : 'bg-[#141923] text-slate-400 border-white/[0.08] hover:text-slate-100'
                      }`}
                    >
                      M
                    </button>
                    <button
                      type="button"
                      onClick={() => updateStem(meta.id, { solo: !st.solo })}
                      title={`Solo ${meta.label}`}
                      className={`w-6 h-6 text-[11px] font-mono font-bold rounded border transition-colors cursor-pointer ${
                        st.solo
                          ? 'bg-amber-500 text-[#0B0D11] border-amber-400'
                          : 'bg-[#141923] text-slate-400 border-white/[0.08] hover:text-slate-100'
                      }`}
                    >
                      S
                    </button>
                    {stemCuts.length > 0 && (
                      <button
                        type="button"
                        onClick={() =>
                          onChangeConfig((p) => ({
                            ...p,
                            cuts: p.cuts.filter((c) => c.stem !== meta.id),
                          }))
                        }
                        title={`Clear ${stemCuts.length} cut(s)`}
                        className="inline-flex items-center gap-0.5 px-1.5 h-6 text-[10px] font-mono text-red-300 bg-red-500/10 border border-red-500/30 rounded hover:bg-red-500/20 cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>{stemCuts.length}</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Volume + Fade In / Out */}
                <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-400">
                  <div>
                    <div className="flex justify-between font-mono">
                      <span>VOL</span>
                      <span className={isMuted ? 'text-slate-500' : 'text-slate-200'}>
                        {Math.round(st.volume * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      aria-label={`${meta.label} volume`}
                      min={0}
                      max={150}
                      value={Math.round(st.volume * 100)}
                      onChange={(e) =>
                        updateStem(meta.id, { volume: Number(e.target.value) / 100 })
                      }
                      className="w-full accent-emerald-500 cursor-pointer"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between font-mono">
                      <span>F.IN</span>
                      <span className="text-slate-300">{st.fadeInSec.toFixed(1)}s</span>
                    </div>
                    <input
                      type="range"
                      aria-label={`${meta.label} fade in`}
                      min={0}
                      max={40}
                      value={Math.round(st.fadeInSec * 10)}
                      onChange={(e) =>
                        updateStem(meta.id, { fadeInSec: Number(e.target.value) / 10 })
                      }
                      className="w-full accent-slate-300 cursor-pointer"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between font-mono">
                      <span>F.OUT</span>
                      <span className="text-slate-300">{st.fadeOutSec.toFixed(1)}s</span>
                    </div>
                    <input
                      type="range"
                      aria-label={`${meta.label} fade out`}
                      min={0}
                      max={40}
                      value={Math.round(st.fadeOutSec * 10)}
                      onChange={(e) =>
                        updateStem(meta.id, { fadeOutSec: Number(e.target.value) / 10 })
                      }
                      className="w-full accent-slate-300 cursor-pointer"
                    />
                  </div>
                </div>

                {/* Custom Automation Entry Bar & Level when Custom Mode active */}
                {config.introArrangement === 'custom-automation' && (
                  <div className="grid grid-cols-2 gap-2 pt-1 border-t border-white/[0.06] text-[10px] text-slate-400">
                    <label className="flex items-center justify-between gap-1 font-mono">
                      <span>Intro Bar</span>
                      <select
                        value={st.introEntryBar}
                        onChange={(e) =>
                          updateStem(meta.id, { introEntryBar: Number(e.target.value) })
                        }
                        className="bg-[#141923] text-slate-200 border border-white/[0.1] rounded px-1 py-0.5 cursor-pointer"
                      >
                        {Array.from({ length: 8 }, (_, b) => (
                          <option key={b} value={b}>
                            Bar {b + 1}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label className="flex items-center justify-between gap-1 font-mono">
                      <span>Intro Lvl</span>
                      <select
                        value={Math.round(st.introLevel * 100)}
                        onChange={(e) =>
                          updateStem(meta.id, { introLevel: Number(e.target.value) / 100 })
                        }
                        className="bg-[#141923] text-slate-200 border border-white/[0.1] rounded px-1 py-0.5 cursor-pointer"
                      >
                        {[0, 25, 50, 75, 100, 120].map((v) => (
                          <option key={v} value={v}>
                            {v}%
                          </option>
                        ))}
                      </select>
                    </label>
                  </div>
                )}
              </div>

              {/* Right Synchronized Stem Waveform Canvas */}
              <div className="relative bg-[#07090C] border border-white/[0.06] rounded overflow-hidden">
                <canvas
                  ref={(el) => {
                    canvasRefs.current[meta.id] = el;
                  }}
                  onMouseDown={(e) => handleMouseDown(meta.id, e)}
                  onMouseMove={(e) => handleMouseMove(meta.id, e)}
                  onMouseUp={(e) => handleMouseUp(meta.id, e)}
                  className="w-full h-16 block cursor-crosshair select-none"
                />
                {!stemSet && (
                  <div className="absolute inset-0 flex items-center justify-center text-[11px] font-mono text-slate-500 pointer-events-none">
                    {isSeparating ? 'Extracting real Demucs stem waveform...' : 'Awaiting Demucs stem separation'}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
