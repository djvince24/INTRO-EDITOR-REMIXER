import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Play,
  Pause,
  Crosshair,
  ZoomIn,
  ZoomOut,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import {
  DemucsStemSet,
  IntroEditConfig,
  PlaybackDeck,
  RenderedIntroEdit,
  TrackAnalysis,
} from '../types/audio';

export type SourceGridMode = 'scrub' | 'cue1' | 'donor';
export type OriginalMonitorMode = 'full' | 'vocals' | 'instrumental';
type SnapGranularity = 'exact' | 'beat' | 'bar';

interface WaveformTimelineProps {
  sourceBuffer: AudioBuffer | null;
  demucsStems: DemucsStemSet | null;
  isSeparatingDemucs: boolean;
  analysis: TrackAnalysis;
  config: IntroEditConfig;
  rendered: RenderedIntroEdit | null;
  activeDeck: PlaybackDeck;
  gridMode: SourceGridMode;
  currentTimeSec: number;
  isPlaying: boolean;
  onChangeGridMode: (mode: SourceGridMode) => void;
  onSeek: (
    deck: 'edit' | 'original' | 'stems-mix',
    timeSec: number,
    autoPlay?: boolean,
    monitorOverride?: OriginalMonitorMode
  ) => void;
  onToggleOriginalPlay: () => void;
  onUpdateCue1Bar: (barIndex: number, exactSec?: number | null) => void;
  onUpdateDonorStartBar: (barIndex: number, exactSec?: number | null) => void;
}

function formatTime(sec: number): string {
  const s = Math.max(0, sec);
  const mins = Math.floor(s / 60);
  const rem = s - mins * 60;
  return `${String(mins).padStart(2, '0')}:${rem.toFixed(2).padStart(5, '0')}`;
}

function formatPreciseTime(sec: number): string {
  const s = Math.max(0, sec);
  const mins = Math.floor(s / 60);
  const rem = s - mins * 60;
  return `${String(mins).padStart(2, '0')}:${rem.toFixed(3).padStart(6, '0')}`;
}

const ZOOM_LEVELS = [1, 2, 4, 8, 16, 32] as const;

export const WaveformTimeline: React.FC<WaveformTimelineProps> = ({
  sourceBuffer,
  demucsStems,
  isSeparatingDemucs,
  analysis,
  config,
  rendered,
  activeDeck,
  gridMode,
  currentTimeSec,
  isPlaying,
  onChangeGridMode,
  onSeek,
  onToggleOriginalPlay,
  onUpdateCue1Bar,
  onUpdateDonorStartBar,
}) => {
  const origCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const editCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const [snapMode, setSnapMode] = useState<SnapGranularity>('beat');
  const [playOnClick, setPlayOnClick] = useState<boolean>(true);
  const [zoom, setZoom] = useState<number>(1);
  const [viewStartSec, setViewStartSec] = useState<number>(0);
  const [hoverSec, setHoverSec] = useState<number | null>(null);

  const monitorForMode = (mode: SourceGridMode): OriginalMonitorMode =>
    mode === 'cue1' ? 'vocals' : mode === 'donor' ? 'instrumental' : 'full';

  const dur = analysis.durationSec;
  const viewSpanSec = dur / zoom;
  const maxViewStart = Math.max(0, dur - viewSpanSec);
  const clampedViewStart = Math.min(maxViewStart, Math.max(0, viewStartSec));
  const viewEndSec = clampedViewStart + viewSpanSec;

  const donorBarsCount = config.loopStructure === '4-bar-x2' ? 4 : 8;
  const maxDonorBar = Math.max(0, analysis.totalBars - donorBarsCount);

  const cue1ActualSec =
    config.cue1ExactSec != null
      ? config.cue1ExactSec
      : config.firstDownbeatSec + config.cue1Bar * analysis.barSec;

  const donorActualSec =
    config.donorStartExactSec != null
      ? config.donorStartExactSec
      : config.firstDownbeatSec + config.donorStartBar * analysis.barSec;

  const originalSec = activeDeck === 'original' ? currentTimeSec : cue1ActualSec;

  const snapTimestamp = useCallback(
    (rawSec: number, mode: SnapGranularity): { sec: number; barIdx: number } => {
      const clamped = Math.max(0, Math.min(dur - 0.02, rawSec));
      const beatSec = analysis.beatSec;
      const barSec = analysis.barSec;
      const rel = Math.max(0, clamped - config.firstDownbeatSec);

      if (mode === 'bar') {
        const barIdx = Math.max(
          0,
          Math.min(analysis.totalBars - 1, Math.round(rel / barSec))
        );
        return {
          sec: Math.max(0, Math.min(dur - 0.02, config.firstDownbeatSec + barIdx * barSec)),
          barIdx,
        };
      }

      if (mode === 'beat') {
        const beatIdx = Math.max(0, Math.round(rel / beatSec));
        const sec = Math.max(
          0,
          Math.min(dur - 0.02, config.firstDownbeatSec + beatIdx * beatSec)
        );
        const barIdx = Math.max(
          0,
          Math.min(analysis.totalBars - 1, Math.floor(beatIdx / 4))
        );
        return { sec, barIdx };
      }

      const barIdx = Math.max(
        0,
        Math.min(analysis.totalBars - 1, Math.floor(rel / barSec))
      );
      return { sec: clamped, barIdx };
    },
    [analysis.barSec, analysis.beatSec, analysis.totalBars, config.firstDownbeatSec, dur]
  );

  const setZoomCentered = useCallback(
    (nextZoom: number, anchorSec?: number) => {
      const clampedZoom = Math.min(32, Math.max(1, nextZoom));
      const newSpan = dur / clampedZoom;
      const anchor =
        anchorSec ??
        (activeDeck === 'original'
          ? currentTimeSec
          : clampedViewStart + viewSpanSec * 0.5);
      const fracInView =
        viewSpanSec > 0
          ? Math.min(1, Math.max(0, (anchor - clampedViewStart) / viewSpanSec))
          : 0.5;
      const nextStart = Math.max(
        0,
        Math.min(dur - newSpan, anchor - fracInView * newSpan)
      );
      setZoom(clampedZoom);
      setViewStartSec(nextStart);
    },
    [activeDeck, clampedViewStart, currentTimeSec, dur, viewSpanSec]
  );

  const focusWindowOn = useCallback(
    (targetSec: number) => {
      const nextStart = Math.max(0, Math.min(maxViewStart, targetSec - viewSpanSec * 0.35));
      setViewStartSec(nextStart);
    },
    [maxViewStart, viewSpanSec]
  );

  // Reset zoom window when a new track loads
  useEffect(() => {
    setZoom(1);
    setViewStartSec(0);
  }, [analysis.durationSec, analysis.sampleRate]);

  // Keep zoomed window following playhead while playing Original track
  useEffect(() => {
    if (!isPlaying || activeDeck !== 'original' || zoom <= 1) return;
    if (currentTimeSec < clampedViewStart || currentTimeSec > viewEndSec - viewSpanSec * 0.1) {
      const nextStart = Math.max(
        0,
        Math.min(maxViewStart, currentTimeSec - viewSpanSec * 0.2)
      );
      setViewStartSec(nextStart);
    }
  }, [
    isPlaying,
    activeDeck,
    zoom,
    currentTimeSec,
    clampedViewStart,
    viewEndSec,
    viewSpanSec,
    maxViewStart,
  ]);

  // Non-passive wheel listener for smooth cursor-centered zooming
  useEffect(() => {
    const canvas = origCanvasRef.current;
    if (!canvas) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = canvas.getBoundingClientRect();
      const ratio =
        rect.width > 0 ? Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width)) : 0.5;
      const cursorSec = clampedViewStart + ratio * viewSpanSec;
      const factor = e.deltaY < 0 ? 1.35 : 1 / 1.35;
      setZoomCentered(zoom * factor, cursorSec);
    };
    canvas.addEventListener('wheel', onWheel, { passive: false });
    return () => canvas.removeEventListener('wheel', onWheel);
  }, [clampedViewStart, viewSpanSec, zoom, setZoomCentered]);

  const isOriginalPlaying = isPlaying && activeDeck === 'original';

  // Render Original Source Grid waveform (high-res direct AudioBuffer sampling when zoomed)
  useEffect(() => {
    const canvas = origCanvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    canvas.width = Math.floor(rect.width * dpr);
    canvas.height = Math.floor(rect.height * dpr);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.scale(dpr, dpr);
    const w = rect.width;
    const h = rect.height;

    ctx.clearRect(0, 0, w, h);

    const toX = (t: number) => ((t - clampedViewStart) / viewSpanSec) * w;

    const donorStartSec = donorActualSec;
    const donorEndSec = donorStartSec + donorBarsCount * analysis.barSec;
    const dx1 = toX(donorStartSec);
    const dx2 = toX(donorEndSec);
    if (dx2 > 0 && dx1 < w) {
      ctx.fillStyle = 'rgba(16, 185, 129, 0.12)';
      ctx.fillRect(Math.max(0, dx1), 0, Math.min(w, dx2) - Math.max(0, dx1), h);
    }

    const cx = toX(cue1ActualSec);
    if (cx < w) {
      ctx.fillStyle = 'rgba(245, 158, 11, 0.06)';
      ctx.fillRect(Math.max(0, cx), 0, w - Math.max(0, cx), h);
    }

    // Draw Bar & Beat grid lines inside visible window
    const startBarIdx = Math.max(
      0,
      Math.floor((clampedViewStart - config.firstDownbeatSec) / analysis.barSec) - 1
    );
    const endBarIdx = Math.min(
      analysis.totalBars,
      Math.ceil((viewEndSec - config.firstDownbeatSec) / analysis.barSec) + 1
    );

    ctx.lineWidth = 1;
    const barPxWidth = (analysis.barSec / viewSpanSec) * w;
    for (let b = startBarIdx; b <= endBarIdx; b++) {
      const barTime = config.firstDownbeatSec + b * analysis.barSec;
      const bx = Math.round(toX(barTime)) + 0.5;
      const isPhrase = b % 4 === 0;

      if (bx >= 0 && bx <= w) {
        ctx.strokeStyle =
          barPxWidth > 36
            ? isPhrase
              ? 'rgba(255,255,255,0.2)'
              : 'rgba(255,255,255,0.1)'
            : isPhrase
              ? 'rgba(255,255,255,0.13)'
              : 'rgba(255,255,255,0.035)';
        ctx.beginPath();
        ctx.moveTo(bx, 0);
        ctx.lineTo(bx, h);
        ctx.stroke();

        if (b < analysis.totalBars && (barPxWidth > 26 || (isPhrase && barPxWidth * 4 > 26))) {
          ctx.fillStyle = isPhrase ? 'rgba(226, 232, 240, 0.7)' : 'rgba(148, 163, 184, 0.5)';
          ctx.font = '500 9px "JetBrains Mono", monospace';
          ctx.fillText(String(b + 1), bx + 3, 10);
        }
      }

      // Draw individual Beat ticks (1..4) when zoomed in enough
      if (barPxWidth > 52 && b < analysis.totalBars) {
        for (let beat = 1; beat < 4; beat++) {
          const beatTime = barTime + beat * analysis.beatSec;
          const btx = Math.round(toX(beatTime)) + 0.5;
          if (btx >= 0 && btx <= w) {
            ctx.strokeStyle = 'rgba(255,255,255,0.05)';
            ctx.beginPath();
            ctx.moveTo(btx, 12);
            ctx.lineTo(btx, h - 6);
            ctx.stroke();

            if (barPxWidth > 120) {
              ctx.fillStyle = 'rgba(148, 163, 184, 0.45)';
              ctx.font = '400 8px "JetBrains Mono", monospace';
              ctx.fillText(`${b + 1}.${beat + 1}`, btx + 2, 20);
            }
          }
        }
      }
    }

    const midY = h * 0.52;
    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx.beginPath();
    ctx.moveTo(0, midY);
    ctx.lineTo(w, midY);
    ctx.stroke();

    // High-resolution waveform rendering directly from AudioBuffer (and isolated Demucs stems when monitoring Vocals/Inst)
    const vocalMap = analysis.vocalHeatmap;
    const showVocalsHighlight = gridMode === 'cue1' && Boolean(demucsStems);
    const showInstHighlight = gridMode === 'donor' && Boolean(demucsStems);

    if (zoom > 1.2 && sourceBuffer) {
      const sr = sourceBuffer.sampleRate;
      const ch0 = sourceBuffer.getChannelData(0);
      const ch1 = sourceBuffer.numberOfChannels > 1 ? sourceBuffer.getChannelData(1) : ch0;
      const cols = Math.floor(w);

      for (let px = 0; px < cols; px++) {
        const t0 = clampedViewStart + (px / cols) * viewSpanSec;
        const t1 = clampedViewStart + ((px + 1) / cols) * viewSpanSec;
        const s0 = Math.max(0, Math.floor(t0 * sr));
        const s1 = Math.min(ch0.length, Math.max(s0 + 1, Math.floor(t1 * sr)));

        let maxAmp = 0;
        let focusAmp = 0;
        const stride = Math.max(1, Math.floor((s1 - s0) / 48));
        for (let s = s0; s < s1; s += stride) {
          const m = Math.max(Math.abs(ch0[s]), Math.abs(ch1[s]));
          if (m > maxAmp) maxAmp = m;

          if (demucsStems && s < demucsStems.length) {
            if (showVocalsHighlight) {
              const vm = Math.max(
                Math.abs(demucsStems.vocalsL[s]),
                Math.abs(demucsStems.vocalsR[s])
              );
              if (vm > focusAmp) focusAmp = vm;
            } else if (showInstHighlight) {
              const il =
                demucsStems.drumsL[s] + demucsStems.bassL[s] + demucsStems.otherL[s];
              const ir =
                demucsStems.drumsR[s] + demucsStems.bassR[s] + demucsStems.otherR[s];
              const im = Math.max(Math.abs(il), Math.abs(ir));
              if (im > focusAmp) focusAmp = im;
            }
          }
        }

        const amp = Math.min(1, maxAmp) * (h * 0.37);
        const inDonor = t0 >= donorStartSec && t0 <= donorEndSec;
        const afterCue = t0 >= cue1ActualSec;

        if (showVocalsHighlight || showInstHighlight) {
          ctx.fillStyle = 'rgba(100, 116, 139, 0.22)';
          ctx.fillRect(px, midY - amp, 1, Math.max(1, amp * 2));

          const fAmp = Math.min(1, focusAmp) * (h * 0.39);
          if (fAmp > 0.5) {
            ctx.fillStyle = showVocalsHighlight
              ? 'rgba(245, 158, 11, 0.92)'
              : inDonor
                ? 'rgba(16, 185, 129, 0.96)'
                : 'rgba(52, 211, 153, 0.78)';
            ctx.fillRect(px, midY - fAmp, 1, Math.max(1, fAmp * 2));
          }
        } else {
          if (inDonor) {
            ctx.fillStyle = 'rgba(16, 185, 129, 0.88)';
          } else if (afterCue) {
            ctx.fillStyle = 'rgba(203, 213, 225, 0.72)';
          } else {
            ctx.fillStyle = 'rgba(100, 116, 139, 0.48)';
          }
          ctx.fillRect(px, midY - amp, 1, Math.max(1, amp * 2));
        }

        const vocIdx = Math.min(
          vocalMap.length - 1,
          Math.max(0, Math.floor((t0 / dur) * vocalMap.length))
        );
        const voc = vocalMap[vocIdx] ?? 0;
        if (voc > 0.12) {
          ctx.fillStyle = `rgba(245, 158, 11, ${Math.min(0.9, voc * 0.9)})`;
          ctx.fillRect(px, h - 5, 1, 5);
        }
      }
    } else {
      const peaks = analysis.originalPeaks;
      const barW = Math.max(1, w / peaks.length);
      for (let i = 0; i < peaks.length; i++) {
        const t = (i / peaks.length) * dur;
        if (t < clampedViewStart || t > viewEndSec) continue;
        const x = toX(t);
        const amp = Math.min(1, peaks[i]) * (h * 0.37);
        const inDonor = t >= donorStartSec && t <= donorEndSec;
        const afterCue = t >= cue1ActualSec;

        if (showVocalsHighlight && demucsStems) {
          ctx.fillStyle = 'rgba(100, 116, 139, 0.22)';
          ctx.fillRect(x, midY - amp, Math.max(1, barW - 0.3), amp * 2);

          const vIdx = Math.min(
            demucsStems.peaks.vocals.length - 1,
            Math.floor((i / peaks.length) * demucsStems.peaks.vocals.length)
          );
          const vAmp = Math.min(1, demucsStems.peaks.vocals[vIdx] ?? 0) * (h * 0.39);
          ctx.fillStyle = 'rgba(245, 158, 11, 0.92)';
          ctx.fillRect(x, midY - vAmp, Math.max(1, barW - 0.3), Math.max(1, vAmp * 2));
        } else if (showInstHighlight && demucsStems) {
          ctx.fillStyle = 'rgba(100, 116, 139, 0.20)';
          ctx.fillRect(x, midY - amp, Math.max(1, barW - 0.3), amp * 2);

          const binLen = demucsStems.peaks.drums.length;
          const sIdx = Math.min(binLen - 1, Math.floor((i / peaks.length) * binLen));
          const instPeak = Math.min(
            1,
            Math.max(
              demucsStems.peaks.drums[sIdx] ?? 0,
              demucsStems.peaks.bass[sIdx] ?? 0,
              demucsStems.peaks.other[sIdx] ?? 0
            )
          );
          const iAmp = instPeak * (h * 0.39);
          ctx.fillStyle = inDonor ? 'rgba(16, 185, 129, 0.96)' : 'rgba(52, 211, 153, 0.72)';
          ctx.fillRect(x, midY - iAmp, Math.max(1, barW - 0.3), Math.max(1, iAmp * 2));
        } else {
          if (inDonor) {
            ctx.fillStyle = 'rgba(16, 185, 129, 0.85)';
          } else if (afterCue) {
            ctx.fillStyle = 'rgba(203, 213, 225, 0.65)';
          } else {
            ctx.fillStyle = 'rgba(100, 116, 139, 0.45)';
          }
          ctx.fillRect(x, midY - amp, Math.max(1, barW - 0.3), amp * 2);
        }

        const voc = vocalMap[i] ?? 0;
        if (voc > 0.12) {
          ctx.fillStyle = `rgba(245, 158, 11, ${Math.min(0.9, voc * 0.9)})`;
          ctx.fillRect(x, h - 5, Math.max(1, barW), 5);
        }
      }
    }

    // Hover snap preview
    if (hoverSec !== null) {
      const snapped = snapTimestamp(hoverSec, snapMode);
      const hx = toX(snapped.sec);
      if (hx >= 0 && hx <= w) {
        ctx.strokeStyle =
          gridMode === 'cue1'
            ? 'rgba(245, 158, 11, 0.85)'
            : gridMode === 'donor'
              ? 'rgba(16, 185, 129, 0.85)'
              : 'rgba(248, 250, 252, 0.65)';
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(hx, 0);
        ctx.lineTo(hx, h);
        ctx.stroke();
        ctx.setLineDash([]);

        const relBeat =
          Math.max(0, Math.round((snapped.sec - config.firstDownbeatSec) / analysis.beatSec)) %
          4;
        const label =
          snapMode === 'exact'
            ? `BAR ${snapped.barIdx + 1} · ${formatPreciseTime(snapped.sec)}`
            : `BAR ${snapped.barIdx + 1}.${relBeat + 1} · ${formatTime(snapped.sec)}`;
        const boxW = snapMode === 'exact' ? 124 : 114;
        const boxX = Math.min(w - boxW - 4, Math.max(4, hx + 4));
        ctx.fillStyle = 'rgba(11, 13, 17, 0.92)';
        ctx.fillRect(boxX, 18, boxW, 16);
        ctx.fillStyle = '#F8FAFC';
        ctx.font = '600 9px "JetBrains Mono", monospace';
        ctx.fillText(label, boxX + 5, 29);
      }
    }

    // Donor top bracket & bottom tag
    if (dx2 > 0 && dx1 < w) {
      ctx.strokeStyle = '#10B981';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(Math.max(0, dx1), 1);
      ctx.lineTo(Math.min(w, dx2), 1);
      ctx.stroke();

      const tagX = Math.min(w - 114, Math.max(0, dx1));
      ctx.fillStyle = '#10B981';
      ctx.fillRect(tagX, h - 22, 112, 16);
      ctx.fillStyle = '#0B0D11';
      ctx.font = '600 10px "JetBrains Mono", monospace';
      ctx.fillText(
        config.donorStartExactSec != null
          ? `INST · ${formatTime(config.donorStartExactSec)}`
          : `INST · BAR ${config.donorStartBar + 1}–${config.donorStartBar + donorBarsCount}`,
        tagX + 5,
        h - 11
      );
    }

    // Cue 1 vertical line & tag
    if (cx >= -2 && cx <= w + 2) {
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(cx, 0);
      ctx.lineTo(cx, h);
      ctx.stroke();

      const tagX = Math.min(w - 98, Math.max(0, cx));
      ctx.fillStyle = '#F59E0B';
      ctx.fillRect(tagX, 0, 96, 18);
      ctx.fillStyle = '#0B0D11';
      ctx.font = '600 10px "JetBrains Mono", monospace';
      ctx.fillText(
        config.cue1ExactSec != null
          ? `CUE 1 · ${formatTime(config.cue1ExactSec)}`
          : `CUE 1 · BAR ${config.cue1Bar + 1}`,
        tagX + 6,
        12
      );
    }

    // Original Playhead
    if (activeDeck === 'original') {
      const px = toX(currentTimeSec);
      if (px >= 0 && px <= w) {
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(px, 0);
        ctx.lineTo(px, h);
        ctx.stroke();

        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath();
        ctx.moveTo(px - 5, 0);
        ctx.lineTo(px + 5, 0);
        ctx.lineTo(px, 7);
        ctx.closePath();
        ctx.fill();
      }
    }
  }, [
    sourceBuffer,
    demucsStems,
    analysis,
    config,
    donorBarsCount,
    donorActualSec,
    cue1ActualSec,
    hoverSec,
    snapMode,
    gridMode,
    activeDeck,
    currentTimeSec,
    clampedViewStart,
    viewEndSec,
    viewSpanSec,
    zoom,
    dur,
    snapTimestamp,
  ]);

  // Render Rendered 8-Bar DJ Intro Edit canvas
  useEffect(() => {
    const canvas = editCanvasRef.current;
    if (!canvas || !rendered) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    canvas.width = Math.floor(rect.width * dpr);
    canvas.height = Math.floor(rect.height * dpr);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.scale(dpr, dpr);
    const w = rect.width;
    const h = rect.height;
    const editDur = rendered.totalDurationSec;

    ctx.clearRect(0, 0, w, h);

    const introEndX = (rendered.introDurationSec / editDur) * w;
    ctx.fillStyle = 'rgba(16, 185, 129, 0.10)';
    ctx.fillRect(0, 0, introEndX, h);

    ctx.fillStyle = 'rgba(245, 158, 11, 0.05)';
    ctx.fillRect(introEndX, 0, Math.max(0, w - introEndX), h);

    const totalEditBars = Math.ceil(editDur / rendered.barSec);
    ctx.lineWidth = 1;
    for (let b = 0; b <= totalEditBars; b++) {
      const t = b * rendered.barSec;
      const x = Math.round((t / editDur) * w) + 0.5;
      const isIntroBar = b <= 8;
      const isPhrase = b % 4 === 0;
      ctx.strokeStyle =
        b === 8
          ? '#F59E0B'
          : isPhrase
            ? isIntroBar
              ? 'rgba(16, 185, 129, 0.35)'
              : 'rgba(255,255,255,0.12)'
            : 'rgba(255,255,255,0.04)';
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();

      if (b >= 1 && b <= 8 && introEndX > 180) {
        const prevX = (((b - 1) * rendered.barSec) / editDur) * w;
        ctx.fillStyle = 'rgba(16, 185, 129, 0.75)';
        ctx.font = '500 10px "JetBrains Mono", monospace';
        ctx.fillText(String(b), prevX + 4, h - 7);
      }
    }

    const midY = h * 0.5;
    ctx.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx.beginPath();
    ctx.moveTo(0, midY);
    ctx.lineTo(w, midY);
    ctx.stroke();

    const peaks = rendered.peaks;
    const barW = Math.max(1, w / peaks.length);
    for (let i = 0; i < peaks.length; i++) {
      const x = (i / peaks.length) * w;
      const t = (i / peaks.length) * editDur;
      const amp = Math.min(1, peaks[i]) * (h * 0.41);
      ctx.fillStyle =
        t < rendered.introDurationSec ? 'rgba(16, 185, 129, 0.92)' : 'rgba(245, 158, 11, 0.78)';
      ctx.fillRect(x, midY - amp, Math.max(1, barW - 0.3), amp * 2);
    }

    ctx.strokeStyle = '#F59E0B';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(introEndX, 0);
    ctx.lineTo(introEndX, h);
    ctx.stroke();

    ctx.fillStyle = '#10B981';
    ctx.fillRect(0, 0, Math.min(introEndX, 178), 18);
    ctx.fillStyle = '#0B0D11';
    ctx.font = '600 10px "JetBrains Mono", monospace';
    ctx.fillText(
      rendered.usingDemucsStems ? '8-BAR CLEAN INST INTRO' : '8-BAR INST INTRO',
      6,
      12
    );

    ctx.fillStyle = '#F59E0B';
    ctx.fillRect(introEndX, 0, 122, 18);
    ctx.fillStyle = '#0B0D11';
    ctx.fillText('BAR 9 · CUE 1 VERSE', introEndX + 6, 12);

    if (activeDeck === 'edit') {
      const px = Math.min(w, Math.max(0, (currentTimeSec / editDur) * w));
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(px, 0);
      ctx.lineTo(px, h);
      ctx.stroke();
    }
  }, [rendered, activeDeck, currentTimeSec]);

  const handleOrigClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    const clickSec = clampedViewStart + ratio * viewSpanSec;
    const snapped = snapTimestamp(clickSec, snapMode);
    const shouldPlay = isOriginalPlaying || playOnClick;
    const monitor = monitorForMode(gridMode);

    if (gridMode === 'scrub' && !e.shiftKey) {
      onSeek('original', snapped.sec, shouldPlay, monitor);
      return;
    }

    if (gridMode === 'cue1') {
      onUpdateCue1Bar(snapped.barIdx, snapMode === 'bar' ? null : snapped.sec);
      onSeek('original', snapped.sec, shouldPlay, 'vocals');
    } else if (gridMode === 'donor') {
      const bar = Math.min(maxDonorBar, snapped.barIdx);
      onUpdateDonorStartBar(bar, snapMode === 'bar' ? null : snapped.sec);
      onSeek('original', snapped.sec, shouldPlay, 'instrumental');
    } else {
      onSeek('original', clickSec, true, monitor);
    }
  };

  const handleOrigMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    setHoverSec(clampedViewStart + ratio * viewSpanSec);
  };

  const handleEditClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!rendered) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
    onSeek('edit', ratio * rendered.totalDurationSec, true);
  };

  const nudgePlayhead = (deltaSec: number) => {
    const base = activeDeck === 'original' ? currentTimeSec : cue1ActualSec;
    const next = Math.max(0, Math.min(dur - 0.02, base + deltaSec));
    onSeek('original', next, isOriginalPlaying, monitorForMode(gridMode));
    if (zoom > 1) {
      if (next < clampedViewStart || next > viewEndSec) {
        focusWindowOn(next);
      }
    }
  };

  const captureCue1AtPlayhead = () => {
    const snapped = snapTimestamp(originalSec, snapMode);
    onUpdateCue1Bar(snapped.barIdx, snapMode === 'bar' ? null : snapped.sec);
  };

  const captureDonorAtPlayhead = () => {
    const snapped = snapTimestamp(originalSec, snapMode);
    const bar = Math.min(maxDonorBar, snapped.barIdx);
    onUpdateDonorStartBar(bar, snapMode === 'bar' ? null : snapped.sec);
  };

  const currentOrigSnapped = snapTimestamp(originalSec, snapMode);
  const currentEditBar =
    rendered && activeDeck === 'edit'
      ? Math.floor(currentTimeSec / rendered.barSec) + 1
      : 1;

  return (
    <section className="bg-[#12161F] border border-white/[0.08] rounded-lg p-5 space-y-5">
      <div className="space-y-3">
        {/* Top Row: Play/Pause Original + Click Mode + Snap Mode */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="text-sm font-semibold text-slate-100">Original Source Grid</h2>
            <span className="text-xs text-slate-400 font-mono tabular-nums">
              {analysis.totalBars} Bars · {formatTime(dur)}
            </span>
            <span
              className={`text-xs font-mono ${
                gridMode === 'cue1'
                  ? 'text-amber-400'
                  : gridMode === 'donor'
                    ? 'text-emerald-400'
                    : 'text-slate-400'
              }`}
            >
              {gridMode === 'cue1'
                ? demucsStems
                  ? '· Audition: Vocals Only'
                  : isSeparatingDemucs
                    ? '· Audition: Preparing Vocals Only...'
                    : '· Audition: Vocals Only (Pending Demucs)'
                : gridMode === 'donor'
                  ? demucsStems
                    ? '· Audition: Instrumental Only'
                    : isSeparatingDemucs
                      ? '· Audition: Preparing Inst Only...'
                      : '· Audition: Inst Only (Pending Demucs)'
                  : '· Audition: Full Mix'}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={onToggleOriginalPlay}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                isOriginalPlaying
                  ? gridMode === 'cue1' && demucsStems
                    ? 'bg-amber-500 text-[#0B0D11] border-amber-400'
                    : gridMode === 'donor' && demucsStems
                      ? 'bg-emerald-500 text-[#0B0D11] border-emerald-400'
                      : 'bg-slate-100 text-[#0B0D11] border-slate-100'
                  : 'bg-[#1B212E] text-slate-200 border-white/[0.1] hover:bg-[#232B3B]'
              }`}
            >
              {isOriginalPlaying ? (
                <>
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  <span>
                    {gridMode === 'cue1' && demucsStems
                      ? 'Pause Vocals'
                      : gridMode === 'donor' && demucsStems
                        ? 'Pause Inst'
                        : 'Pause'}
                  </span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>
                    {gridMode === 'cue1' && demucsStems
                      ? 'Play Vocals'
                      : gridMode === 'donor' && demucsStems
                        ? 'Play Inst Only'
                        : 'Play Original'}
                  </span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => setPlayOnClick((v) => !v)}
              title="Toggle whether clicking the waveform starts playback immediately or parks paused at the exact spot"
              className={`px-2.5 py-1.5 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                playOnClick
                  ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
                  : 'bg-[#0B0D11] text-slate-400 border-white/[0.08] hover:text-slate-200'
              }`}
            >
              {playOnClick ? 'Click: Auto-Play' : 'Click: Seek Only'}
            </button>

            <div className="inline-flex items-center p-0.5 bg-[#0B0D11] border border-white/[0.08] rounded-md">
              <button
                type="button"
                onClick={() => onChangeGridMode('scrub')}
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  gridMode === 'scrub'
                    ? 'bg-[#252D3D] text-slate-100 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Seek / Play
              </button>
              <button
                type="button"
                onClick={() => onChangeGridMode('cue1')}
                title="Audition isolated Demucs Vocals Only so you can pinpoint the exact starting verse for Cue 1"
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  gridMode === 'cue1'
                    ? 'bg-amber-500 text-[#0B0D11] font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Place Cue 1
              </button>
              <button
                type="button"
                onClick={() => onChangeGridMode('donor')}
                title="Audition Demucs Instrumental Only (no vocals) for the intro loop source"
                className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  gridMode === 'donor'
                    ? 'bg-emerald-500 text-[#0B0D11] font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Place Inst Loop
              </button>
            </div>
          </div>
        </div>

        {/* Second Row: Waveform Zoom + Snap Granularity + Fine Playhead Nudge */}
        <div className="flex flex-wrap items-center justify-between gap-2 bg-[#0B0D11] border border-white/[0.06] rounded-md px-3 py-1.5">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] text-slate-400 mr-1">Zoom:</span>
            <button
              type="button"
              onClick={() => setZoomCentered(zoom / 2)}
              disabled={zoom <= 1}
              aria-label="Zoom out waveform"
              className="p-1 text-slate-300 bg-[#141923] border border-white/[0.08] rounded hover:bg-[#1D2432] disabled:opacity-35 cursor-pointer"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            {ZOOM_LEVELS.map((z) => (
              <button
                key={z}
                type="button"
                onClick={() => setZoomCentered(z)}
                className={`px-2 py-0.5 text-[11px] font-mono rounded transition-colors cursor-pointer tabular-nums ${
                  Math.round(zoom) === z
                    ? 'bg-slate-200 text-[#0B0D11] font-semibold'
                    : 'text-slate-400 hover:text-slate-200 bg-[#141923]'
                }`}
              >
                {z}×
              </button>
            ))}
            <button
              type="button"
              onClick={() => setZoomCentered(zoom * 2)}
              disabled={zoom >= 32}
              aria-label="Zoom in waveform"
              className="p-1 text-slate-300 bg-[#141923] border border-white/[0.08] rounded hover:bg-[#1D2432] disabled:opacity-35 cursor-pointer"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>

            {zoom > 1 && (
              <>
                <button
                  type="button"
                  onClick={() => focusWindowOn(originalSec)}
                  className="ml-1 px-2 py-0.5 text-[11px] text-slate-300 bg-[#141923] border border-white/[0.08] rounded hover:bg-[#1D2432] cursor-pointer"
                >
                  Center Playhead
                </button>
                <button
                  type="button"
                  onClick={() => focusWindowOn(cue1ActualSec)}
                  className="px-2 py-0.5 text-[11px] text-amber-300 bg-amber-500/10 border border-amber-500/25 rounded hover:bg-amber-500/20 cursor-pointer"
                >
                  Center Cue 1
                </button>
              </>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1">
              <span className="text-[11px] text-slate-400">Snap:</span>
              {(['bar', 'beat', 'exact'] as SnapGranularity[]).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setSnapMode(m)}
                  className={`px-2 py-0.5 text-[11px] font-medium rounded capitalize transition-colors cursor-pointer ${
                    snapMode === m
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/35'
                      : 'text-slate-400 bg-[#141923] border border-transparent hover:text-slate-200'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1 border-l border-white/[0.08] pl-2">
              <span className="text-[11px] text-slate-400">Nudge:</span>
              <button
                type="button"
                onClick={() => nudgePlayhead(-analysis.beatSec)}
                className="px-1.5 py-0.5 text-[11px] font-mono text-slate-300 bg-[#141923] border border-white/[0.08] rounded hover:bg-[#1D2432] cursor-pointer"
              >
                -1B
              </button>
              <button
                type="button"
                onClick={() => nudgePlayhead(-0.025)}
                className="px-1.5 py-0.5 text-[11px] font-mono text-slate-300 bg-[#141923] border border-white/[0.08] rounded hover:bg-[#1D2432] cursor-pointer"
              >
                -25ms
              </button>
              <button
                type="button"
                onClick={() => nudgePlayhead(0.025)}
                className="px-1.5 py-0.5 text-[11px] font-mono text-slate-300 bg-[#141923] border border-white/[0.08] rounded hover:bg-[#1D2432] cursor-pointer"
              >
                +25ms
              </button>
              <button
                type="button"
                onClick={() => nudgePlayhead(analysis.beatSec)}
                className="px-1.5 py-0.5 text-[11px] font-mono text-slate-300 bg-[#141923] border border-white/[0.08] rounded hover:bg-[#1D2432] cursor-pointer"
              >
                +1B
              </button>
            </div>
          </div>
        </div>

        {/* Zoomed Waveform Canvas */}
        <div className="relative bg-[#0B0D11] border border-white/[0.07] rounded-md overflow-hidden">
          <canvas
            ref={origCanvasRef}
            onClick={handleOrigClick}
            onMouseMove={handleOrigMouseMove}
            onMouseLeave={() => setHoverSec(null)}
            className="w-full h-32 block cursor-crosshair"
          />
        </div>

        {/* Horizontal Pan Scroller when zoomed in */}
        {zoom > 1 && (
          <div className="flex items-center gap-2 px-1">
            <button
              type="button"
              onClick={() =>
                setViewStartSec(Math.max(0, clampedViewStart - viewSpanSec * 0.25))
              }
              aria-label="Pan waveform left"
              className="p-1 text-slate-400 hover:text-slate-100 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <input
              type="range"
              aria-label="Pan zoomed waveform"
              min={0}
              max={maxViewStart}
              step={Math.max(0.01, maxViewStart / 500)}
              value={clampedViewStart}
              onChange={(e) => setViewStartSec(Number(e.target.value))}
              className="flex-1 accent-slate-300 cursor-pointer"
            />
            <button
              type="button"
              onClick={() =>
                setViewStartSec(Math.min(maxViewStart, clampedViewStart + viewSpanSec * 0.25))
              }
              aria-label="Pan waveform right"
              className="p-1 text-slate-400 hover:text-slate-100 cursor-pointer"
            >
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono tabular-nums text-slate-400 whitespace-nowrap">
              {formatTime(clampedViewStart)} – {formatTime(viewEndSec)}
            </span>
          </div>
        )}

        {/* Playhead Capture Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0B0D11] border border-white/[0.06] rounded-md px-3 py-2">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="text-slate-400 font-mono tabular-nums">
              {activeDeck === 'original' ? (
                <>
                  Cursor:{' '}
                  <span className="font-semibold text-slate-100">
                    {formatPreciseTime(originalSec)}
                  </span>{' '}
                  (Bar {currentOrigSnapped.barIdx + 1})
                </>
              ) : (
                'Click waveform or press Play Original to position cursor:'
              )}
            </span>
            <button
              type="button"
              onClick={captureCue1AtPlayhead}
              disabled={activeDeck !== 'original'}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-[#0B0D11] bg-amber-500 rounded hover:bg-amber-400 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0 cursor-pointer tabular-nums"
            >
              <Crosshair className="w-3 h-3" />
              <span>
                Snap Cue 1 Here (
                {snapMode === 'exact'
                  ? formatTime(currentOrigSnapped.sec)
                  : `Bar ${currentOrigSnapped.barIdx + 1}`}
                )
              </span>
            </button>
            <button
              type="button"
              onClick={captureDonorAtPlayhead}
              disabled={activeDeck !== 'original'}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-[#0B0D11] bg-emerald-500 rounded hover:bg-emerald-400 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0 cursor-pointer tabular-nums"
            >
              <Crosshair className="w-3 h-3" />
              <span>
                Snap Inst Loop Here (
                {snapMode === 'exact'
                  ? formatTime(currentOrigSnapped.sec)
                  : `Bar ${Math.min(maxDonorBar, currentOrigSnapped.barIdx) + 1}`}
                )
              </span>
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                onChangeGridMode('donor');
                onSeek('original', donorActualSec, true, 'instrumental');
              }}
              title="Switch to Place Inst Loop mode and audition Instrumental Only"
              className="px-2.5 py-1 text-xs font-medium text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded hover:bg-emerald-500/20 transition-colors whitespace-nowrap shrink-0 cursor-pointer tabular-nums"
            >
              {demucsStems ? 'Play Inst Loop' : 'Play Loop'}
            </button>
            <button
              type="button"
              onClick={() => {
                onChangeGridMode('cue1');
                onSeek('original', cue1ActualSec, true, 'vocals');
              }}
              title="Switch to Place Cue 1 mode and audition Vocals Only at Cue 1"
              className="px-2.5 py-1 text-xs font-medium text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded hover:bg-amber-500/20 transition-colors whitespace-nowrap shrink-0 cursor-pointer tabular-nums"
            >
              {demucsStems ? 'Play Cue 1 Vocals' : 'Play Cue 1'}
            </button>
          </div>
        </div>
      </div>

      <div className="border-t border-white/[0.06]" />

      {/* Rendered 8-Bar DJ Intro Edit */}
      <div className="space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <h2 className="text-sm font-semibold text-slate-100">
              Rendered 8-Bar DJ Intro Edit
            </h2>
            {rendered && (
              <span className="text-xs font-mono tabular-nums text-slate-400">
                Intro {formatTime(rendered.introDurationSec)} · Seam{' '}
                {Math.round(rendered.seamPeakContinuity * 100)}% Continuous · Bar{' '}
                {currentEditBar}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onSeek('edit', 0, true)}
              disabled={!rendered}
              className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#1B212E] border border-white/[0.08] rounded-md hover:bg-[#232B3B] disabled:opacity-40 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Play Bar 1
            </button>
            <button
              type="button"
              onClick={() => {
                if (!rendered) return;
                const bar7Sec = Math.max(0, rendered.introDurationSec - rendered.barSec * 2);
                onSeek('edit', bar7Sec, true);
              }}
              disabled={!rendered}
              className="px-3 py-1.5 text-xs font-semibold text-amber-300 bg-amber-500/10 border border-amber-500/30 rounded-md hover:bg-amber-500/20 disabled:opacity-40 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Check Bar 7 → Bar 9 Seam
            </button>
            <button
              type="button"
              onClick={() => {
                if (!rendered) return;
                onSeek('edit', rendered.cue1OutputSec, true);
              }}
              disabled={!rendered}
              className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-[#1B212E] border border-white/[0.08] rounded-md hover:bg-[#232B3B] disabled:opacity-40 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Jump to Cue 1
            </button>
          </div>
        </div>

        <div className="relative bg-[#0B0D11] border border-white/[0.07] rounded-md overflow-hidden">
          <canvas
            ref={editCanvasRef}
            onClick={handleEditClick}
            className="w-full h-32 block cursor-pointer"
          />
        </div>
      </div>
    </section>
  );
};
