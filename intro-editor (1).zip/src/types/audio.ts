export type StemName = 'vocals' | 'drums' | 'bass' | 'other';

export type DemucsModelVariant = 'htdemucs' | 'htdemucs_ft';
export type DemucsModelPreference = 'auto' | DemucsModelVariant;

export type IntroArrangementMode =
  | 'progressive-build'
  | 'full-instrumental'
  | 'custom-automation';

export type TransitionBlendMode = 'tight-cut' | 'beat-blend' | 'bar-overlap';

export type IntroLoopStructure = '8-bar-continuous' | '4-bar-x2';

export interface BarMetrics {
  barIndex: number;
  startSec: number;
  endSec: number;
  rmsEnergy: number;
  drumTransientScore: number;
  vocalPresenceScore: number;
  melodyRichnessScore: number;
  isInstrumentalCandidate: boolean;
}

export interface TrackAnalysis {
  bpm: number;
  confidence: number;
  beatPhaseConfidence?: number;
  refinedByDemucs?: boolean;
  firstDownbeatSec: number;
  beatSec: number;
  barSec: number;
  totalBars: number;
  durationSec: number;
  sampleRate: number;
  bars: BarMetrics[];
  recommendedCue1Bar: number;
  recommendedDonorStartBar: number;
  donorHasVocals: boolean;
  originalPeaks: Float32Array;
  vocalHeatmap: Float32Array;
}

export interface StemQualityMetric {
  stem: StemName;
  peakLinear: number;
  peakDbfs: number;
  rms: number;
  clippedSamples: number;
  isSilent: boolean;
  phaseCorrelation: number;
}

export interface StemQualityReport {
  syncVerified: boolean;
  maxDriftSamples: number;
  sampleRate: number;
  lengthSamples: number;
  durationSec: number;
  clippingDetected: boolean;
  totalClippedSamples: number;
  missingAudioDetected: boolean;
  phaseIssueDetected: boolean;
  reconstructionSnrDb: number;
  maxResidualError: number;
  reconstructedPeakLinear: number;
  reconstructedPhaseCorrelation: number;
  stems: Record<StemName, StemQualityMetric>;
  warnings: string[];
  passed: boolean;
}

export interface DemucsHardwareCapabilities {
  cpuCores: number;
  totalMemMb: number;
  freeMemMb: number;
  hasGpu: boolean;
  gpuName: string | null;
  executionProviders: string[];
  recommendedModel: DemucsModelVariant;
  cachedModels: string[];
}

export interface DemucsStemSet {
  audioHash: string;
  modelUsed: DemucsModelVariant;
  providerUsed: string;
  fromCache: boolean;
  sampleRate: number;
  length: number;
  durationSec: number;
  vocalsL: Float32Array;
  vocalsR: Float32Array;
  drumsL: Float32Array;
  drumsR: Float32Array;
  bassL: Float32Array;
  bassR: Float32Array;
  otherL: Float32Array;
  otherR: Float32Array;
  peaks: Record<StemName, Float32Array>;
  qc: StemQualityReport;
  engineLabel: string;
}

export interface StemChannelSettings {
  volume: number; // 0..1.5
  mute: boolean;
  solo: boolean;
  fadeInSec: number; // 0..4s
  fadeOutSec: number; // 0..4s
  introEntryBar: number; // 0-indexed bar inside the 8-bar intro (0..7)
  introLevel: number; // 0..1.5 target level in intro
}

export interface StemCutRegion {
  id: string;
  stem: StemName;
  startSec: number; // timestamp in original track seconds
  endSec: number;
}

export interface IntroEditConfig {
  bpm: number;
  firstDownbeatSec: number;
  cue1Bar: number;
  cue1ExactSec?: number | null;
  donorStartBar: number;
  donorStartExactSec?: number | null;
  loopStructure: IntroLoopStructure;
  demucsModelPreference: DemucsModelPreference;
  introArrangement: IntroArrangementMode;
  grooveLiftAmount: number;
  transitionBlend: TransitionBlendMode;
  drumPunchBoost: number;
  // Intelligent DJ Stem Mixing options
  bassSwapEnabled: boolean;
  kickPreservationEnabled: boolean;
  phaseAwareMixing: boolean;
  phraseAwareTransition: boolean;
  // Per-stem mixer & automation state
  stems: Record<StemName, StemChannelSettings>;
  cuts: StemCutRegion[];
}

export interface RenderQualityControl {
  outputPeakLinear: number;
  outputPeakDbfs: number;
  clippedSamples: number;
  hasSilentIntro: boolean;
  hasSilentCue1: boolean;
  phaseCorrelationSeam: number;
  seamPeakContinuity: number;
  stemSyncVerified: boolean;
  reconstructionSnrDb: number | null;
  passed: boolean;
  issues: string[];
}

export interface RenderedIntroEdit {
  buffer: AudioBuffer;
  peaks: Float32Array;
  stemMixBuffer: AudioBuffer;
  stemMixPeaks: Float32Array;
  introDurationSec: number;
  cue1OutputSec: number;
  totalDurationSec: number;
  barSec: number;
  beatSec: number;
  bpm: number;
  usingDemucsStems: boolean;
  demucsModelUsed: DemucsModelVariant | null;
  seamPeakContinuity: number;
  qc: RenderQualityControl;
}

export interface DemoTrackSpec {
  id: string;
  title: string;
  artist: string;
  genre: string;
  bpm: number;
  key: string;
  description: string;
}

export type RemixVocalTone = 'natural' | 'pop-clarity' | 'warm-club';

export interface RemixConfig {
  instStartBar: number;
  instDrumsLevel: number; // 0..1.4
  instBassLevel: number; // 0..1.4
  instOtherLevel: number; // 0..1.4
  instBedLevel: number; // 0..1.3
  vocalBpm: number;
  vocalFirstDownbeatSec: number;
  vocalCueBar: number;
  vocalBeatShift: number; // -3.5..+3.5 beats (0.5 beat increments for beat/pickup phase sync)
  vocalTargetDropBar: number;
  vocalFineOffsetMs: number; // -500..+500 ms
  autoBeatmatch: boolean;
  halfDoubleTime: '1x' | '0.5x' | '2x';
  phraseLockEnabled: boolean;
  pitchSemitones: number; // -6..+6
  vocalLevel: number; // 0..1.5
  pocketCarveAmount: number; // 0..1 (ducks instrumental 'other' around vocals)
  vocalSpaceAmount: number; // 0..0.45 (tempo-synced stereo glue)
  vocalTone: RemixVocalTone;
}

export interface RenderedRemix {
  buffer: AudioBuffer;
  alignedVocalsBuffer: AudioBuffer;
  instBedBuffer: AudioBuffer;
  mixPeaks: Float32Array;
  instPeaks: Float32Array;
  vocalPeaks: Float32Array;
  totalDurationSec: number;
  targetBpm: number;
  effectiveVocalBpm: number;
  barSec: number;
  beatSec: number;
  timeStretchRatio: number;
  vocalCueSec: number;
  vocalDropSec: number;
  beatSyncTightnessPct: number;
  avgBeatErrorMs: number;
  beatWarpActive: boolean;
  outputPeakDbfs: number;
  clippedSamples: number;
  passed: boolean;
}

export type PlaybackDeck =
  | 'edit'
  | 'original'
  | 'stems-mix'
  | 'remix'
  | 'remix-vocals'
  | 'remix-inst';


