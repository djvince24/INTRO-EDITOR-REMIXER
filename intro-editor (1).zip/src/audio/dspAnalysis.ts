import { BarMetrics, DemucsStemSet, TrackAnalysis } from '../types/audio';

interface BiquadCoeffs {
  b0: number;
  b1: number;
  b2: number;
  a1: number;
  a2: number;
}

function makeBandpassCoeffs(sampleRate: number, centerHz: number, q: number): BiquadCoeffs {
  const w0 = (2 * Math.PI * centerHz) / sampleRate;
  const alpha = Math.sin(w0) / (2 * q);
  const cosW0 = Math.cos(w0);
  const a0 = 1 + alpha;
  return {
    b0: alpha / a0,
    b1: 0,
    b2: -alpha / a0,
    a1: (-2 * cosW0) / a0,
    a2: (1 - alpha) / a0,
  };
}

function makeLowpassCoeffs(sampleRate: number, cutoffHz: number, q = 0.707): BiquadCoeffs {
  const w0 = (2 * Math.PI * cutoffHz) / sampleRate;
  const alpha = Math.sin(w0) / (2 * q);
  const cosW0 = Math.cos(w0);
  const a0 = 1 + alpha;
  const b1 = 1 - cosW0;
  const b0 = b1 / 2;
  return {
    b0: b0 / a0,
    b1: b1 / a0,
    b2: b0 / a0,
    a1: (-2 * cosW0) / a0,
    a2: (1 - alpha) / a0,
  };
}

function makeHighpassCoeffs(sampleRate: number, cutoffHz: number, q = 0.707): BiquadCoeffs {
  const w0 = (2 * Math.PI * cutoffHz) / sampleRate;
  const alpha = Math.sin(w0) / (2 * q);
  const cosW0 = Math.cos(w0);
  const a0 = 1 + alpha;
  const b1 = -(1 + cosW0);
  const b0 = (1 + cosW0) / 2;
  return {
    b0: b0 / a0,
    b1: b1 / a0,
    b2: b0 / a0,
    a1: (-2 * cosW0) / a0,
    a2: (1 - alpha) / a0,
  };
}

function runBiquadEnergy(
  samples: Float32Array,
  start: number,
  end: number,
  c: BiquadCoeffs
): number {
  let x1 = 0, x2 = 0, y1 = 0, y2 = 0;
  let sumSq = 0;
  const len = Math.max(1, end - start);
  for (let i = start; i < end; i++) {
    const x0 = samples[i];
    const y0 = c.b0 * x0 + c.b1 * x1 + c.b2 * x2 - c.a1 * y1 - c.a2 * y2;
    x2 = x1;
    x1 = x0;
    y2 = y1;
    y1 = y0;
    sumSq += y0 * y0;
  }
  return Math.sqrt(sumSq / len);
}

interface MultiBandEnvelopes {
  combinedFlux: Float32Array;
  lowFlux: Float32Array;
  midHighFlux: Float32Array;
  lowEnergyEnv: Float32Array;
  harmonicDelta: Float32Array;
  frameRate: number;
  activeStartFrame: number;
}

function buildMultiBandEnvelopes(
  left: Float32Array,
  right: Float32Array,
  sr: number,
  harmonicLeft?: Float32Array,
  harmonicRight?: Float32Array,
  frameRate = 200
): MultiBandEnvelopes {
  const maxAnalyzeSamples = Math.min(left.length, Math.floor(sr * 150));
  const hop = Math.max(1, Math.floor(sr / frameRate));
  const effectiveFrameRate = sr / hop;
  const numFrames = Math.floor(maxAnalyzeSamples / hop);

  const combinedFlux = new Float32Array(numFrames);
  const lowFlux = new Float32Array(numFrames);
  const midHighFlux = new Float32Array(numFrames);
  const lowEnergyEnv = new Float32Array(numFrames);
  const harmonicDelta = new Float32Array(numFrames);

  const lp = makeLowpassCoeffs(sr, 145, 0.707);
  const hp = makeHighpassCoeffs(sr, 1100, 0.707);
  const harmBp = makeBandpassCoeffs(sr, 420, 0.7);

  let lx1 = 0, lx2 = 0, ly1 = 0, ly2 = 0;
  let hx1 = 0, hx2 = 0, hy1 = 0, hy2 = 0;
  let mx1 = 0, mx2 = 0, my1 = 0, my2 = 0;

  let prevTotal = 0;
  let prevLow = 0;
  let prevHigh = 0;
  let prevHarm = 0;
  let maxTotalRms = 0;
  const rmsPerFrame = new Float32Array(numFrames);

  for (let f = 0; f < numFrames; f++) {
    const start = f * hop;
    const end = Math.min(maxAnalyzeSamples, start + hop);
    const span = Math.max(1, end - start);

    let eTotal = 0;
    let eLow = 0;
    let eHigh = 0;
    let eHarm = 0;

    for (let i = start; i < end; i++) {
      const mono = 0.5 * (left[i] + right[i]);
      eTotal += mono * mono;

      const lowY = lp.b0 * mono + lp.b1 * lx1 + lp.b2 * lx2 - lp.a1 * ly1 - lp.a2 * ly2;
      lx2 = lx1;
      lx1 = mono;
      ly2 = ly1;
      ly1 = lowY;
      eLow += lowY * lowY;

      const highY = hp.b0 * mono + hp.b1 * hx1 + hp.b2 * hx2 - hp.a1 * hy1 - hp.a2 * hy2;
      hx2 = hx1;
      hx1 = mono;
      hy2 = hy1;
      hy1 = highY;
      eHigh += highY * highY;

      const hSrc =
        harmonicLeft && harmonicRight && i < harmonicLeft.length
          ? 0.5 * (harmonicLeft[i] + harmonicRight[i])
          : mono;
      const harmY =
        harmBp.b0 * hSrc + harmBp.b1 * mx1 + harmBp.b2 * mx2 - harmBp.a1 * my1 - harmBp.a2 * my2;
      mx2 = mx1;
      mx1 = hSrc;
      my2 = my1;
      my1 = harmY;
      eHarm += harmY * harmY;
    }

    const rmsTotal = Math.sqrt(eTotal / span);
    const rmsLow = Math.sqrt(eLow / span);
    const rmsHigh = Math.sqrt(eHigh / span);
    const rmsHarm = Math.sqrt(eHarm / span);

    rmsPerFrame[f] = rmsTotal;
    if (rmsTotal > maxTotalRms) maxTotalRms = rmsTotal;

    const fLow = Math.max(0, rmsLow - prevLow * 0.78);
    const fHigh = Math.max(0, rmsHigh - prevHigh * 0.8);
    const fTotal = Math.max(0, rmsTotal - prevTotal * 0.84);
    const dHarm = Math.abs(rmsHarm - prevHarm);

    lowFlux[f] = fLow;
    midHighFlux[f] = fHigh;
    lowEnergyEnv[f] = rmsLow;
    harmonicDelta[f] = dHarm;
    combinedFlux[f] = fLow * 1.45 + fHigh * 0.75 + fTotal * 0.5;

    prevTotal = rmsTotal;
    prevLow = rmsLow;
    prevHigh = rmsHigh;
    prevHarm = prevHarm * 0.7 + rmsHarm * 0.3;
  }

  let activeStartFrame = 0;
  const activeThresh = maxTotalRms * 0.12;
  for (let f = 0; f < numFrames; f++) {
    if (rmsPerFrame[f] >= activeThresh) {
      activeStartFrame = f;
      break;
    }
  }

  return {
    combinedFlux,
    lowFlux,
    midHighFlux,
    lowEnergyEnv,
    harmonicDelta,
    frameRate: effectiveFrameRate,
    activeStartFrame,
  };
}

function scoreBpmCandidate(
  normFlux: Float32Array,
  n: number,
  startFrame: number,
  frameRate: number,
  bpm: number,
  phaseSteps: number
): number {
  const beatFrames = (60 / bpm) * frameRate;
  let maxPhaseCorr = 0;

  for (let p = 0; p < phaseSteps; p++) {
    const offset = startFrame + (p / phaseSteps) * beatFrames;
    let corr = 0;
    let hits = 0;
    for (let pos = offset; pos < n - 1; pos += beatFrames) {
      const i0 = Math.floor(pos);
      const i1 = Math.min(n - 1, i0 + 1);
      const frac = pos - i0;
      corr += normFlux[i0] * (1 - frac) + normFlux[i1] * frac;
      hits++;
    }
    if (hits > 2) {
      const avg = corr / Math.sqrt(hits);
      if (avg > maxPhaseCorr) maxPhaseCorr = avg;
    }
  }

  return maxPhaseCorr;
}

/**
 * Computes how convincingly a track at `bpm` exhibits a 4/4 kick (beats 1 & 3)
 * alternating with snare/clap backbeat (beats 2 & 4). Distinguishes true BPM from
 * half-time or double-time octave multiples.
 */
function scoreBackbeatOctave(
  env: MultiBandEnvelopes,
  bpm: number,
  startFrame: number
): number {
  if (bpm < 62 || bpm > 184) return -1;
  const n = env.lowFlux.length;
  const beatFrames = (60 / bpm) * env.frameRate;

  let bestOffset = startFrame;
  let bestScore = -1;
  const phaseSteps = 24;
  for (let p = 0; p < phaseSteps; p++) {
    const offset = startFrame + (p / phaseSteps) * beatFrames;
    let s = 0;
    for (let pos = offset; pos < n - 1; pos += beatFrames) {
      const idx = Math.floor(pos);
      s += env.lowFlux[idx] * 1.1 + env.midHighFlux[idx] * 0.7;
    }
    if (s > bestScore) {
      bestScore = s;
      bestOffset = offset;
    }
  }

  let bestAlternation = 0;
  for (let rot = 0; rot < 2; rot++) {
    let kickOn13 = 0;
    let snareOn24 = 0;
    let snareOn13 = 0;
    let count = 0;
    for (let pos = bestOffset + rot * beatFrames; pos + beatFrames < n - 2; pos += beatFrames * 2) {
      const b1 = Math.floor(pos);
      const b2 = Math.floor(pos + beatFrames);
      kickOn13 += env.lowFlux[b1] + env.lowEnergyEnv[b1] * 0.25;
      snareOn24 += env.midHighFlux[b2];
      snareOn13 += env.midHighFlux[b1];
      count++;
    }
    if (count > 2) {
      const alt = (kickOn13 + Math.max(0, snareOn24 - snareOn13 * 0.55)) / count;
      if (alt > bestAlternation) bestAlternation = alt;
    }
  }

  const centerPrior =
    bpm >= 92 && bpm <= 138 ? 1.12 : bpm >= 80 && bpm <= 156 ? 1.0 : 0.86;
  return bestAlternation * centerPrior;
}

function detectBeatGridFromEnvelopes(
  env: MultiBandEnvelopes,
  overrideBpm?: number,
  overrideDownbeatSec?: number,
  fineBpmWindow?: { centerBpm: number; radiusBpm: number }
): {
  bpm: number;
  confidence: number;
  beatPhaseConfidence: number;
  firstDownbeatSec: number;
} {
  const n = env.combinedFlux.length;
  const frameRate = env.frameRate;
  if (n < frameRate * 3) {
    return {
      bpm: overrideBpm ?? 120,
      confidence: 0.4,
      beatPhaseConfidence: 0.5,
      firstDownbeatSec: overrideDownbeatSec ?? 0,
    };
  }

  let mean = 0;
  for (let i = 0; i < n; i++) mean += env.combinedFlux[i];
  mean /= n;
  const norm = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    norm[i] = Math.max(0, env.combinedFlux[i] - mean * 0.35);
  }

  // Lightly smoothed onset envelope (±10ms capture basin) prevents sharp peaks from aliasing between coarse BPM steps
  const smoothNorm = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const p2 = norm[Math.max(0, i - 2)];
    const p1 = norm[Math.max(0, i - 1)];
    const c0 = norm[i];
    const n1 = norm[Math.min(n - 1, i + 1)];
    const n2 = norm[Math.min(n - 1, i + 2)];
    smoothNorm[i] = p2 * 0.12 + p1 * 0.22 + c0 * 0.32 + n1 * 0.22 + n2 * 0.12;
  }

  let fineBpm = overrideBpm ?? 120;
  let confidence = 0.95;

  if (!overrideBpm || overrideBpm <= 40) {
    const startSearch = env.activeStartFrame;
    const minBpm = fineBpmWindow ? Math.max(62, fineBpmWindow.centerBpm - fineBpmWindow.radiusBpm) : 64;
    const maxBpm = fineBpmWindow ? Math.min(184, fineBpmWindow.centerBpm + fineBpmWindow.radiusBpm) : 182;
    const stepBpm = fineBpmWindow ? 0.08 : 0.2;

    let bestCoarseBpm = minBpm;
    let bestScore = -1;
    let secondBest = 0;

    for (let bpm = minBpm; bpm <= maxBpm + 1e-6; bpm += stepBpm) {
      const corr = scoreBpmCandidate(smoothNorm, n, startSearch, frameRate, bpm, 28);
      const prior =
        bpm >= 92 && bpm <= 140
          ? 1.06
          : bpm >= 78 && bpm <= 156
            ? 1.0
            : 0.92;
      const finalScore = corr * prior;
      if (finalScore > bestScore) {
        secondBest = bestScore;
        bestScore = finalScore;
        bestCoarseBpm = bpm;
      }
    }

    // Octave disambiguation (half-time vs normal vs double-time) unless locked in fine window
    let octaveAnchorBpm = bestCoarseBpm;
    if (!fineBpmWindow) {
      const candidates = [bestCoarseBpm * 0.5, bestCoarseBpm, bestCoarseBpm * 2].filter(
        (b) => b >= 64 && b <= 182
      );
      let bestOctaveScore = -1;
      for (const cand of candidates) {
        const sc = scoreBackbeatOctave(env, cand, startSearch);
        if (sc > bestOctaveScore) {
          bestOctaveScore = sc;
          octaveAnchorBpm = cand;
        }
      }
    }

    // Two-pass fine refinement + first-half vs second-half phase drift verification
    fineBpm = octaveAnchorBpm;
    let fineBestScore = -1;
    const midFrame = Math.floor((startSearch + n) * 0.5);
    const fineCandidates: Array<{ bpm: number; score: number }> = [];

    for (let b = octaveAnchorBpm - 0.85; b <= octaveAnchorBpm + 0.85; b += 0.005) {
      const s = scoreBpmCandidate(smoothNorm, n, startSearch, frameRate, b, 36);
      fineCandidates.push({ bpm: b, score: s });
      if (s > fineBestScore) {
        fineBestScore = s;
        fineBpm = b;
      }
    }

    // Among top 99% fine candidates, pick the one with zero phase-drift between first and second halves
    if (n - startSearch > frameRate * 16 && fineBestScore > 0) {
      const thresh = fineBestScore * 0.992;
      let bestDriftScore = -Infinity;
      for (const fc of fineCandidates) {
        if (fc.score < thresh) continue;
        const beatFrames = (60 / fc.bpm) * frameRate;
        const phaseSteps = 32;
        let maxHalf1 = -1;
        let p1Best = 0;
        let maxHalf2 = -1;
        let p2Best = 0;
        for (let p = 0; p < phaseSteps; p++) {
          const offset = startSearch + (p / phaseSteps) * beatFrames;
          let s1 = 0;
          let s2 = 0;
          for (let pos = offset; pos < midFrame - 1; pos += beatFrames) {
            s1 += smoothNorm[Math.floor(pos)];
          }
          const start2 =
            offset + Math.ceil(Math.max(0, midFrame - offset) / beatFrames) * beatFrames;
          for (let pos = start2; pos < n - 1; pos += beatFrames) {
            s2 += smoothNorm[Math.floor(pos)];
          }
          if (s1 > maxHalf1) {
            maxHalf1 = s1;
            p1Best = p / phaseSteps;
          }
          if (s2 > maxHalf2) {
            maxHalf2 = s2;
            p2Best = p / phaseSteps;
          }
        }
        const rawDiff = Math.abs(p1Best - p2Best);
        const circDiff = Math.min(rawDiff, 1 - rawDiff);
        const driftAdj = fc.score * (1 - circDiff * 0.08);
        if (driftAdj > bestDriftScore) {
          bestDriftScore = driftAdj;
          fineBpm = fc.bpm;
        }
      }
    }

    // Only snap to integer if genuinely studio-quantized (within ±0.015 BPM)
    const nearestInt = Math.round(fineBpm);
    if (Math.abs(fineBpm - nearestInt) <= 0.015) {
      fineBpm = nearestInt;
    } else {
      fineBpm = Math.round(fineBpm * 100) / 100;
    }

    confidence =
      bestScore > 0
        ? Math.min(0.99, Math.max(0.35, (bestScore - secondBest * 0.72) / bestScore + 0.35))
        : 0.5;
  }

  let firstDownbeatSec = overrideDownbeatSec ?? 0;
  let beatPhaseConfidence = 0.85;

  if (overrideDownbeatSec === undefined) {
    const beatFrames = (60 / fineBpm) * frameRate;
    const subSteps = 120; // ~2-4ms precision per beat
    let bestBeatOffsetFrames = 0;
    let bestBeatOffsetScore = -1;

    // Sample peak transient alignment strictly weighted to lowFlux kick attacks
    for (let s = 0; s < subSteps; s++) {
      const offset = (s / subSteps) * beatFrames;
      let sum = 0;
      for (let pos = offset; pos < n - 2; pos += beatFrames) {
        const i0 = Math.floor(pos);
        const iNext = Math.min(n - 1, i0 + 1);
        sum +=
          env.lowFlux[i0] * 1.45 +
          env.lowFlux[iNext] * 0.4 +
          env.midHighFlux[i0] * 0.5 +
          norm[i0] * 0.45;
      }
      if (sum > bestBeatOffsetScore) {
        bestBeatOffsetScore = sum;
        bestBeatOffsetFrames = offset;
      }
    }

    // Fine transient edge pull: nudge slightly left if kick attack rose 1 frame earlier
    const testAheadIdx = Math.min(n - 1, Math.floor(bestBeatOffsetFrames));
    if (testAheadIdx > 0 && env.lowFlux[testAheadIdx - 1] > env.lowFlux[testAheadIdx] * 1.15) {
      bestBeatOffsetFrames = Math.max(0, bestBeatOffsetFrames - 0.75);
    }

    // Discriminate Bar 1 vs Beats 2, 3, 4 using Kick-Snare alternation + Harmonic/Phrase change
    const rotScores = [0, 0, 0, 0];
    for (let rot = 0; rot < 4; rot++) {
      let barIdx = 0;
      let barCount = 0;
      let rotSum = 0;

      for (
        let pos = bestBeatOffsetFrames + rot * beatFrames;
        pos + beatFrames * 3 < n - 2;
        pos += beatFrames * 4
      ) {
        const f1 = Math.floor(pos);
        const f2 = Math.floor(pos + beatFrames);
        const f3 = Math.floor(pos + beatFrames * 2);
        const f4 = Math.floor(pos + beatFrames * 3);

        const beat1Kick =
          Math.max(env.lowFlux[f1], env.lowFlux[Math.min(n - 1, f1 + 1)]) +
          env.lowEnergyEnv[f1] * 0.35;
        const beat3Kick =
          Math.max(env.lowFlux[f3], env.lowFlux[Math.min(n - 1, f3 + 1)]) +
          env.lowEnergyEnv[f3] * 0.2;
        const backbeatSnare =
          env.midHighFlux[f2] +
          env.midHighFlux[f4] -
          (env.midHighFlux[f1] + env.midHighFlux[f3]) * 0.45;
        const harmChange =
          env.harmonicDelta[f1] + env.harmonicDelta[Math.min(n - 1, f1 + 1)];
        const phraseMult = barIdx % 4 === 0 ? 1.45 : barIdx % 2 === 0 ? 1.15 : 1.0;

        rotSum +=
          (beat1Kick * 1.25 + beat3Kick * 0.6 + Math.max(0, backbeatSnare) * 0.9 + harmChange * 1.35) *
          phraseMult;
        barIdx++;
        barCount++;
      }
      rotScores[rot] = barCount > 0 ? rotSum / barCount : 0;
    }

    let bestBarRotation = 0;
    let bestRotVal = rotScores[0];
    let secondRotVal = 0;
    for (let rot = 1; rot < 4; rot++) {
      if (rotScores[rot] > bestRotVal) {
        secondRotVal = bestRotVal;
        bestRotVal = rotScores[rot];
        bestBarRotation = rot;
      } else if (rotScores[rot] > secondRotVal) {
        secondRotVal = rotScores[rot];
      }
    }

    if (bestRotVal > 1e-6) {
      beatPhaseConfidence = Math.min(
        0.99,
        Math.max(0.45, 0.5 + (bestRotVal - secondRotVal) / (bestRotVal * 0.9))
      );
    }

    const barSec = (60 / fineBpm) * 4;
    firstDownbeatSec =
      ((bestBeatOffsetFrames + bestBarRotation * beatFrames) / frameRate) % barSec;

    if (firstDownbeatSec < 0.008 || barSec - firstDownbeatSec < 0.008) {
      firstDownbeatSec = 0;
    }
  }

  return {
    bpm: fineBpm,
    confidence,
    beatPhaseConfidence,
    firstDownbeatSec,
  };
}

function buildWaveformAndVocalMap(
  buffer: AudioBuffer,
  bins = 900
): { originalPeaks: Float32Array; vocalHeatmap: Float32Array } {
  const sr = buffer.sampleRate;
  const left = buffer.getChannelData(0);
  const right = buffer.numberOfChannels > 1 ? buffer.getChannelData(1) : left;
  const len = buffer.length;
  const originalPeaks = new Float32Array(bins);
  const vocalHeatmap = new Float32Array(bins);

  const vocalMidBand = makeBandpassCoeffs(sr, 1100, 0.9);
  const subBand = makeLowpassCoeffs(sr, 160, 0.707);

  const step = Math.max(1, Math.floor(len / bins));
  const midScratch = new Float32Array(Math.min(step, 2048));
  const sideScratch = new Float32Array(Math.min(step, 2048));

  for (let b = 0; b < bins; b++) {
    const start = Math.floor((b / bins) * len);
    const end = Math.min(len, Math.floor(((b + 1) / bins) * len));
    let peak = 0;
    const sampleCount = Math.min(end - start, midScratch.length);
    const stride = Math.max(1, Math.floor((end - start) / sampleCount));

    let idx = 0;
    for (let i = start; i < end; i++) {
      const m = Math.max(Math.abs(left[i]), Math.abs(right[i]));
      if (m > peak) peak = m;
      if (idx < sampleCount && (i - start) % stride === 0) {
        midScratch[idx] = 0.5 * (left[i] + right[i]);
        sideScratch[idx] = 0.5 * (left[i] - right[i]);
        idx++;
      }
    }

    originalPeaks[b] = peak;

    if (idx > 16) {
      const midVoc = runBiquadEnergy(midScratch, 0, idx, vocalMidBand);
      const sideVoc = runBiquadEnergy(sideScratch, 0, idx, vocalMidBand);
      const subE = runBiquadEnergy(midScratch, 0, idx, subBand);
      const centerExcess = Math.max(0, midVoc - sideVoc * 0.85);
      const rawScore = centerExcess / (subE * 0.55 + sideVoc * 0.6 + 0.015);
      vocalHeatmap[b] = Math.min(1, rawScore * 0.65);
    }
  }

  return { originalPeaks, vocalHeatmap };
}

function selectCue1AndDonorBars(bars: BarMetrics[]): {
  recommendedCue1Bar: number;
  recommendedDonorStartBar: number;
  donorHasVocals: boolean;
} {
  let recommendedCue1Bar = 0;
  const searchLimit = Math.min(bars.length - 2, Math.max(8, Math.floor(bars.length * 0.68)));

  if (bars.length >= 4 && bars[0].vocalPresenceScore > 0.52 && bars[1].vocalPresenceScore > 0.48) {
    recommendedCue1Bar = 0;
  } else {
    let bestTransitionScore = -1;
    for (let b = 2; b < searchLimit; b++) {
      const prev2Voc =
        (bars[b - 1].vocalPresenceScore + bars[b - 2].vocalPresenceScore) * 0.5;
      const next2Voc =
        (bars[b].vocalPresenceScore + bars[Math.min(bars.length - 1, b + 1)].vocalPresenceScore) *
        0.5;
      if (bars[b].rmsEnergy <= 0.035) continue;

      const stepUp = next2Voc - prev2Voc;
      const phraseBonus = b % 4 === 0 ? 0.24 : b % 2 === 0 ? 0.08 : -0.06;
      const score = stepUp + next2Voc * 0.45 + phraseBonus;

      if (next2Voc > 0.42 && stepUp > 0.1 && score > bestTransitionScore) {
        bestTransitionScore = score;
        recommendedCue1Bar = b;
      }
    }

    if (bestTransitionScore < 0) {
      for (let b = 0; b < searchLimit; b++) {
        if (bars[b].vocalPresenceScore > 0.45 && bars[b].rmsEnergy > 0.03) {
          recommendedCue1Bar = b;
          break;
        }
      }
    }
  }

  const windowLen = bars.length >= 8 ? 8 : Math.min(4, bars.length);
  let bestDonorStart = 0;
  let bestDonorScore = -999;
  let bestWindowVocalAvg = 1;

  for (let start = 0; start <= Math.max(0, bars.length - windowLen); start++) {
    let sumDrum = 0;
    let sumRms = 0;
    let sumVoc = 0;
    let sumMel = 0;

    for (let i = 0; i < windowLen; i++) {
      const bar = bars[start + i];
      sumDrum += bar.drumTransientScore;
      sumRms += bar.rmsEnergy;
      sumVoc += bar.vocalPresenceScore;
      sumMel += bar.melodyRichnessScore;
    }

    const avgDrum = sumDrum / windowLen;
    const avgRms = sumRms / windowLen;
    const avgVoc = sumVoc / windowLen;
    const avgMel = sumMel / windowLen;

    const phraseBonus = start % 4 === 0 ? 0.18 : start % 2 === 0 ? 0.06 : 0;
    const score =
      avgDrum * 1.45 +
      Math.min(1, avgRms * 3.2) * 0.9 +
      avgMel * 0.7 -
      avgVoc * 2.2 +
      phraseBonus;

    if (score > bestDonorScore) {
      bestDonorScore = score;
      bestDonorStart = start;
      bestWindowVocalAvg = avgVoc;
    }
  }

  return {
    recommendedCue1Bar,
    recommendedDonorStartBar: bestDonorStart,
    donorHasVocals: bestWindowVocalAvg > 0.35,
  };
}

export function analyzeTrack(
  buffer: AudioBuffer,
  overrideBpm?: number,
  overrideDownbeatSec?: number
): TrackAnalysis {
  const sr = buffer.sampleRate;
  const durationSec = buffer.duration;
  const left = buffer.getChannelData(0);
  const right = buffer.numberOfChannels > 1 ? buffer.getChannelData(1) : left;

  const detected =
    overrideBpm && overrideBpm > 40 && overrideDownbeatSec !== undefined
      ? {
          bpm: overrideBpm,
          confidence: 0.95,
          beatPhaseConfidence: 0.9,
          firstDownbeatSec: overrideDownbeatSec,
        }
      : detectBeatGridFromEnvelopes(
          buildMultiBandEnvelopes(left, right, sr, undefined, undefined, 200),
          overrideBpm,
          overrideDownbeatSec
        );

  const bpm = detected.bpm;
  const firstDownbeatSec =
    overrideDownbeatSec !== undefined ? overrideDownbeatSec : detected.firstDownbeatSec;

  const beatSec = 60 / bpm;
  const barSec = beatSec * 4;
  const totalBars = Math.max(1, Math.floor((durationSec - firstDownbeatSec) / barSec));

  const vocalMidBand = makeBandpassCoeffs(sr, 1150, 0.85);
  const subBand = makeLowpassCoeffs(sr, 160, 0.707);
  const highBand = makeBandpassCoeffs(sr, 4800, 0.9);

  const bars: BarMetrics[] = [];
  let maxVocalRaw = 0.0001;
  let maxDrumRaw = 0.0001;

  const rawVocalScores: number[] = [];
  const rawDrumScores: number[] = [];

  for (let b = 0; b < totalBars; b++) {
    const startSec = firstDownbeatSec + b * barSec;
    const endSec = Math.min(durationSec, startSec + barSec);
    const startIdx = Math.floor(startSec * sr);
    const endIdx = Math.min(buffer.length, Math.floor(endSec * sr));

    const len = endIdx - startIdx;
    const targetSamples = Math.min(len, 16384);
    const step = Math.max(1, Math.floor(len / Math.max(1, targetSamples)));
    const count = Math.floor(len / step);

    const midBuf = new Float32Array(count);
    const sideBuf = new Float32Array(count);

    let sumSq = 0;
    let transientSum = 0;
    let prevEnv = 0;

    for (let k = 0; k < count; k++) {
      const i = startIdx + k * step;
      const l = left[i];
      const r = right[i];
      const m = 0.5 * (l + r);
      const s = 0.5 * (l - r);
      midBuf[k] = m;
      sideBuf[k] = s;
      sumSq += m * m + s * s;

      const absM = Math.abs(m);
      if (absM > prevEnv * 1.45 && absM > 0.06) {
        transientSum += absM - prevEnv;
      }
      prevEnv = prevEnv * 0.9 + absM * 0.1;
    }

    const rmsEnergy = Math.sqrt(sumSq / Math.max(1, count));
    const effectiveSr = sr / step;
    const barVocBand =
      effectiveSr > 4000 ? makeBandpassCoeffs(effectiveSr, 1150, 0.85) : vocalMidBand;
    const barSubBand =
      effectiveSr > 1000 ? makeLowpassCoeffs(effectiveSr, 160, 0.707) : subBand;
    const barHighBand =
      effectiveSr > 10000 ? makeBandpassCoeffs(effectiveSr, 4800, 0.9) : highBand;

    const midVoc = runBiquadEnergy(midBuf, 0, count, barVocBand);
    const sideVoc = runBiquadEnergy(sideBuf, 0, count, barVocBand);
    const subE = runBiquadEnergy(midBuf, 0, count, barSubBand);
    const highE = runBiquadEnergy(midBuf, 0, count, barHighBand);

    const centeredVocal = Math.max(0, midVoc - sideVoc * 0.9);
    const vocalRaw = rmsEnergy > 0.02 ? centeredVocal / (rmsEnergy + 0.01) : 0;

    const drumRaw = subE * 0.65 + (transientSum / Math.max(1, count)) * 2.2 + highE * 0.35;
    const melodyRichnessScore = Math.min(1, (sideVoc / (rmsEnergy + 0.02)) * 1.6);

    rawVocalScores.push(vocalRaw);
    rawDrumScores.push(drumRaw);
    if (vocalRaw > maxVocalRaw) maxVocalRaw = vocalRaw;
    if (drumRaw > maxDrumRaw) maxDrumRaw = drumRaw;

    bars.push({
      barIndex: b,
      startSec,
      endSec,
      rmsEnergy,
      drumTransientScore: drumRaw,
      vocalPresenceScore: vocalRaw,
      melodyRichnessScore,
      isInstrumentalCandidate: false,
    });
  }

  for (let b = 0; b < bars.length; b++) {
    bars[b].vocalPresenceScore = Math.min(1, rawVocalScores[b] / Math.max(0.08, maxVocalRaw));
    bars[b].drumTransientScore = Math.min(1, rawDrumScores[b] / Math.max(0.05, maxDrumRaw));
    bars[b].isInstrumentalCandidate =
      bars[b].vocalPresenceScore < 0.42 &&
      bars[b].rmsEnergy > 0.04 &&
      bars[b].drumTransientScore > 0.28;
  }

  const { recommendedCue1Bar, recommendedDonorStartBar, donorHasVocals } =
    selectCue1AndDonorBars(bars);
  const { originalPeaks, vocalHeatmap } = buildWaveformAndVocalMap(buffer);

  return {
    bpm,
    confidence: detected.confidence,
    beatPhaseConfidence: detected.beatPhaseConfidence,
    refinedByDemucs: false,
    firstDownbeatSec,
    beatSec,
    barSec,
    totalBars,
    durationSec,
    sampleRate: sr,
    bars,
    recommendedCue1Bar,
    recommendedDonorStartBar,
    donorHasVocals,
    originalPeaks,
    vocalHeatmap,
  };
}

/**
 * Refines BPM, sub-3ms downbeat transient phase, Bar-1 rotation, per-bar vocal/drum
 * metrics, and Cue 1 / Inst Loop phrasing directly on pure Demucs drums, bass, other & vocals stems.
 */
export function refineAnalysisWithDemucsStems(
  prev: TrackAnalysis,
  stems: DemucsStemSet,
  pinnedBpm?: number
): TrackAnalysis {
  const sr = stems.sampleRate;
  const durationSec = stems.durationSec;

  // Build isolated harmonic change + sub-bass rhythm signal from pure Bass + Other stems
  const envLen = Math.min(stems.length, sr * 150);
  const rhythmL = new Float32Array(envLen);
  const rhythmR = new Float32Array(envLen);
  const harmL = new Float32Array(envLen);
  const harmR = new Float32Array(envLen);
  for (let i = 0; i < envLen; i++) {
    rhythmL[i] = stems.drumsL[i] + stems.bassL[i] * 0.25;
    rhythmR[i] = stems.drumsR[i] + stems.bassR[i] * 0.25;
    harmL[i] = stems.bassL[i] + stems.otherL[i];
    harmR[i] = stems.bassR[i] + stems.otherR[i];
  }

  const drumEnv = buildMultiBandEnvelopes(
    rhythmL,
    rhythmR,
    sr,
    harmL,
    harmR,
    250
  );

  // Measure drum energy to make sure drums stem isn't purely acapella/ambient
  let drumEnergySum = 0;
  for (let i = 0; i < drumEnv.combinedFlux.length; i += 4) {
    drumEnergySum += drumEnv.combinedFlux[i];
  }

  const hasClearDrums = drumEnergySum / Math.max(1, drumEnv.combinedFlux.length / 4) > 0.002;

  // Full-range BPM discovery on pure Demucs drums+bass whenever not user-pinned,
  // so initial mixed-audio BPM traps (e.g. off by >1.5 BPM or wrong octave) are always corrected.
  const grid = hasClearDrums
    ? detectBeatGridFromEnvelopes(
        drumEnv,
        pinnedBpm,
        undefined,
        undefined
      )
    : {
        bpm: pinnedBpm ?? prev.bpm,
        confidence: prev.confidence,
        beatPhaseConfidence: prev.beatPhaseConfidence ?? 0.75,
        firstDownbeatSec: prev.firstDownbeatSec,
      };

  const bpm = grid.bpm;
  const firstDownbeatSec = grid.firstDownbeatSec;
  const beatSec = 60 / bpm;
  const barSec = beatSec * 4;
  const totalBars = Math.max(1, Math.floor((durationSec - firstDownbeatSec) / barSec));

  const bars: BarMetrics[] = [];
  const rawVocalRms: number[] = [];
  const rawDrumRms: number[] = [];
  const rawMelRms: number[] = [];

  let maxVoc = 0.0001;
  let maxDrum = 0.0001;
  let maxMel = 0.0001;

  for (let b = 0; b < totalBars; b++) {
    const startSec = firstDownbeatSec + b * barSec;
    const endSec = Math.min(durationSec, startSec + barSec);
    const startIdx = Math.floor(startSec * sr);
    const endIdx = Math.min(stems.length, Math.floor(endSec * sr));
    const span = Math.max(1, endIdx - startIdx);
    const stride = Math.max(1, Math.floor(span / 4096));

    let vSq = 0;
    let dSq = 0;
    let mSq = 0;
    let bSq = 0;
    let count = 0;

    for (let i = startIdx; i < endIdx; i += stride) {
      vSq += stems.vocalsL[i] * stems.vocalsL[i] + stems.vocalsR[i] * stems.vocalsR[i];
      dSq += stems.drumsL[i] * stems.drumsL[i] + stems.drumsR[i] * stems.drumsR[i];
      mSq += stems.otherL[i] * stems.otherL[i] + stems.otherR[i] * stems.otherR[i];
      bSq += stems.bassL[i] * stems.bassL[i] + stems.bassR[i] * stems.bassR[i];
      count++;
    }

    const vRms = Math.sqrt(vSq / Math.max(1, count * 2));
    const dRms = Math.sqrt(dSq / Math.max(1, count * 2));
    const mRms = Math.sqrt(mSq / Math.max(1, count * 2));
    const bRms = Math.sqrt(bSq / Math.max(1, count * 2));
    const totalRms = Math.sqrt((vSq + dSq + mSq + bSq) / Math.max(1, count * 2));

    rawVocalRms.push(vRms);
    rawDrumRms.push(dRms);
    rawMelRms.push(mRms);

    if (vRms > maxVoc) maxVoc = vRms;
    if (dRms > maxDrum) maxDrum = dRms;
    if (mRms > maxMel) maxMel = mRms;

    bars.push({
      barIndex: b,
      startSec,
      endSec,
      rmsEnergy: Math.max(totalRms, bRms),
      drumTransientScore: dRms,
      vocalPresenceScore: vRms,
      melodyRichnessScore: mRms,
      isInstrumentalCandidate: false,
    });
  }

  for (let b = 0; b < bars.length; b++) {
    bars[b].vocalPresenceScore = Math.min(1, rawVocalRms[b] / Math.max(0.015, maxVoc));
    bars[b].drumTransientScore = Math.min(1, rawDrumRms[b] / Math.max(0.02, maxDrum));
    bars[b].melodyRichnessScore = Math.min(1, rawMelRms[b] / Math.max(0.015, maxMel));
    bars[b].isInstrumentalCandidate =
      bars[b].vocalPresenceScore < 0.25 &&
      bars[b].rmsEnergy > 0.03 &&
      bars[b].drumTransientScore > 0.28;
  }

  const { recommendedCue1Bar, recommendedDonorStartBar, donorHasVocals } =
    selectCue1AndDonorBars(bars);

  // Build crisp vocal heatmap directly from Demucs isolated vocals peaks
  const vocalHeatmap = new Float32Array(prev.vocalHeatmap.length);
  const peakSrc = stems.peaks.vocals;
  for (let i = 0; i < vocalHeatmap.length; i++) {
    const pIdx = Math.min(peakSrc.length - 1, Math.floor((i / vocalHeatmap.length) * peakSrc.length));
    vocalHeatmap[i] = Math.min(1, peakSrc[pIdx] * 1.45);
  }

  return {
    ...prev,
    bpm,
    confidence: Math.max(prev.confidence, grid.confidence),
    beatPhaseConfidence: grid.beatPhaseConfidence,
    refinedByDemucs: true,
    firstDownbeatSec,
    beatSec,
    barSec,
    totalBars,
    bars,
    recommendedCue1Bar,
    recommendedDonorStartBar,
    donorHasVocals,
    vocalHeatmap,
  };
}

/**
 * Picks '1x', '0.5x', or '2x' so Deck B vocal tempo sits closest to Deck A target BPM.
 */
export function computeBestHalfDoubleTime(
  vocalBpm: number,
  targetInstBpm: number
): '1x' | '0.5x' | '2x' {
  const safeVoc = Math.max(45, vocalBpm);
  const safeTarget = Math.max(50, targetInstBpm);
  const opts: Array<{ mode: '1x' | '0.5x' | '2x'; bpm: number }> = [
    { mode: '1x', bpm: safeVoc },
    { mode: '0.5x', bpm: safeVoc * 0.5 },
    { mode: '2x', bpm: safeVoc * 2 },
  ];

  let bestMode: '1x' | '0.5x' | '2x' = '1x';
  let bestDist = Infinity;
  for (const opt of opts) {
    if (opt.bpm < 52 || opt.bpm > 215) continue;
    const ratio = opt.bpm / safeTarget;
    const dist = Math.abs(Math.log2(ratio)) + (opt.mode === '1x' ? 0 : 0.04);
    if (dist < bestDist) {
      bestDist = dist;
      bestMode = opt.mode;
    }
  }
  return bestMode;
}

/**
 * Checks Demucs isolated vocal phrase onset across the selected cue bar to verify whether
 * a whole-beat rotation locks vocal phrasing tighter onto Beat 1 (does not arbitrarily shift
 * by ±0.5 beat on drummed tracks so upbeat vocal pickups remain intact).
 */
export function suggestVocalBeatPhaseShift(
  vocalStems: DemucsStemSet,
  effectiveVocalBpm: number,
  vocalFirstDownbeatSec: number,
  vocalCueBar: number
): number {
  const sr = vocalStems.sampleRate;
  const beatSec = 60 / Math.max(50, effectiveVocalBpm);
  const barSec = beatSec * 4;
  const baseStartSec = vocalFirstDownbeatSec + vocalCueBar * barSec;

  if (baseStartSec < 0 || baseStartSec + barSec * 2 > vocalStems.durationSec) {
    return 0;
  }

  const candidateShifts = [0, -1, 1, 2, -2];
  const windowSamples = Math.round(0.065 * sr);

  const scoreShift = (shiftBeats: number): number => {
    let score = 0;
    const shiftSec = shiftBeats * beatSec;
    for (let bar = 0; bar < 4; bar++) {
      for (const beatInBar of [0, 2]) {
        const tSec = baseStartSec + shiftSec + bar * barSec + beatInBar * beatSec;
        if (tSec < 0.05 || tSec + 0.08 > vocalStems.durationSec) continue;
        const center = Math.round(tSec * sr);
        const preStart = Math.max(0, center - windowSamples);
        const postEnd = Math.min(vocalStems.length, center + windowSamples);

        let preE = 0;
        let postE = 0;
        for (let i = preStart; i < center; i += 4) {
          preE += Math.max(Math.abs(vocalStems.vocalsL[i]), Math.abs(vocalStems.vocalsR[i]));
        }
        for (let i = center; i < postEnd; i += 4) {
          postE += Math.max(Math.abs(vocalStems.vocalsL[i]), Math.abs(vocalStems.vocalsR[i]));
        }
        const preAvg = preE / Math.max(1, (center - preStart) / 4);
        const postAvg = postE / Math.max(1, (postEnd - center) / 4);
        const weight = beatInBar === 0 ? 1.25 : 0.85;
        score += (postAvg + Math.max(0, postAvg - preAvg) * 1.4) * weight;
      }
    }
    return score;
  };

  const zeroScore = scoreShift(0);
  let bestShift = 0;
  let bestScore = zeroScore * 1.18;

  for (const shift of candidateShifts) {
    if (shift === 0) continue;
    const candSec = baseStartSec + shift * beatSec;
    if (candSec < 0) continue;
    const sc = scoreShift(shift);
    if (sc > bestScore) {
      bestScore = sc;
      bestShift = shift;
    }
  }

  return bestShift;
}

/**
 * Computes sample-accurate Demucs drum beat timestamps starting from `anchorSec` onward using
 * sliding 8-beat phase tracking + confident per-beat transient snapping.
 * Bridges drumless breakdowns along the local trend without jumping offbeat, so piecewise
 * beat-warping keeps even live/variable-tempo tracks locked <2 ms across the entire remix.
 */
export function trackBeatsWithDp(
  drumsL: Float32Array,
  drumsR: Float32Array,
  bassL: Float32Array | null,
  bassR: Float32Array | null,
  sr: number,
  bpm: number,
  anchorSec: number,
  endSecLimit?: number
): { beatsSec: number[]; hasClearDrums: boolean; avgDriftMs: number } {
  const safeBpm = Math.max(50, Math.min(210, bpm));
  const beatSec = 60 / safeBpm;
  const maxSec = Math.min(
    drumsL.length / sr,
    endSecLimit ?? drumsL.length / sr
  );
  const startBeat = Math.max(0, anchorSec);
  const numBeats = Math.max(0, Math.floor((maxSec - startBeat) / beatSec));
  const nominalBeats: number[] = [];
  for (let k = 0; k <= numBeats; k++) {
    nominalBeats.push(startBeat + k * beatSec);
  }
  if (nominalBeats.length < 4) {
    return { beatsSec: nominalBeats, hasClearDrums: false, avgDriftMs: 0 };
  }

  // Build fast 250 Hz drum onset envelope over the full track slice
  const frameRate = 250;
  const hop = Math.max(1, Math.floor(sr / frameRate));
  const effFr = sr / hop;
  const sliceSamples = Math.min(drumsL.length, Math.ceil(maxSec * sr));
  const numFrames = Math.floor(sliceSamples / hop);

  const lowFlux = new Float32Array(numFrames);
  const highFlux = new Float32Array(numFrames);
  const lp = makeLowpassCoeffs(sr, 150, 0.707);
  const hp = makeHighpassCoeffs(sr, 1100, 0.707);

  let lx1 = 0, lx2 = 0, ly1 = 0, ly2 = 0;
  let hx1 = 0, hx2 = 0, hy1 = 0, hy2 = 0;
  let prevLow = 0;
  let prevHigh = 0;
  let totalFlux = 0;

  for (let f = 0; f < numFrames; f++) {
    const s0 = f * hop;
    const s1 = Math.min(sliceSamples, s0 + hop);
    let eLow = 0;
    let eHigh = 0;
    for (let i = s0; i < s1; i++) {
      const m =
        0.5 * (drumsL[i] + drumsR[i]) +
        (bassL && bassR ? 0.12 * (bassL[i] + bassR[i]) : 0);
      const lowY = lp.b0 * m + lp.b1 * lx1 + lp.b2 * lx2 - lp.a1 * ly1 - lp.a2 * ly2;
      lx2 = lx1; lx1 = m; ly2 = ly1; ly1 = lowY;
      eLow += lowY * lowY;

      const highY = hp.b0 * m + hp.b1 * hx1 + hp.b2 * hx2 - hp.a1 * hy1 - hp.a2 * hy2;
      hx2 = hx1; hx1 = m; hy2 = hy1; hy1 = highY;
      eHigh += highY * highY;
    }
    const span = Math.max(1, s1 - s0);
    const rmsL = Math.sqrt(eLow / span);
    const rmsH = Math.sqrt(eHigh / span);
    const fl = Math.max(0, rmsL - prevLow * 0.75);
    const fh = Math.max(0, rmsH - prevHigh * 0.78);
    lowFlux[f] = fl;
    highFlux[f] = fh;
    totalFlux += fl + fh;
    prevLow = rmsL;
    prevHigh = rmsH;
  }

  const meanFlux = totalFlux / Math.max(1, numFrames);
  const hasClearDrums = meanFlux > 0.0025;
  if (!hasClearDrums) {
    return { beatsSec: nominalBeats, hasClearDrums: false, avgDriftMs: 0 };
  }

  // Sliding 8-beat window phase tracker with continuity spring (±100 ms range in 4 ms steps)
  const lagRangeFrames = Math.round(0.1 * effFr); // ±100 ms
  const rawOffsetsSec = new Float32Array(nominalBeats.length);
  const winConf = new Float32Array(nominalBeats.length);

  let prevLagFrames = 0;
  for (let b = 0; b < nominalBeats.length; b++) {
    const winStart = Math.max(0, b - 3);
    const winEnd = Math.min(nominalBeats.length - 1, b + 4);
    let bestLag = prevLagFrames;
    let bestScore = -1;
    let energySum = 0;

    for (let lag = -lagRangeFrames; lag <= lagRangeFrames; lag++) {
      let s = 0;
      for (let k = winStart; k <= winEnd; k++) {
        const framePos = Math.round(nominalBeats[k] * effFr) + lag;
        if (framePos <= 0 || framePos >= numFrames - 1) continue;
        const peak =
          Math.max(lowFlux[framePos - 1], lowFlux[framePos], lowFlux[framePos + 1]) * 1.4 +
          highFlux[framePos] * 0.65;
        s += peak;
      }
      if (lag === prevLagFrames) energySum = s;
      // Gentle smoothness penalty prevents sudden octave or upbeat jumps
      const jump = Math.abs(lag - prevLagFrames);
      const reg = 1 - (jump / (lagRangeFrames + 1)) * 0.22;
      const sc = s * reg;
      if (sc > bestScore) {
        bestScore = sc;
        bestLag = lag;
      }
    }

    const activeDrumsInWin = bestScore > meanFlux * (winEnd - winStart + 1) * 0.55;
    if (activeDrumsInWin && Math.abs(bestLag - prevLagFrames) <= Math.round(0.045 * effFr)) {
      prevLagFrames = bestLag;
      winConf[b] = 1;
    } else if (activeDrumsInWin && energySum < bestScore * 0.6) {
      prevLagFrames = Math.round(prevLagFrames * 0.5 + bestLag * 0.5);
      winConf[b] = 0.6;
    } else {
      // During vocal/pad breakdown: gently hold previous offset
      winConf[b] = 0;
    }
    rawOffsetsSec[b] = prevLagFrames / effFr;
  }

  // Smooth tracked offsets symmetrically so instantaneous jitter stays <3ms
  const smoothedOffsets = new Float32Array(nominalBeats.length);
  for (let b = 0; b < nominalBeats.length; b++) {
    let wSum = 0;
    let vSum = 0;
    for (let d = -4; d <= 4; d++) {
      const idx = b + d;
      if (idx < 0 || idx >= nominalBeats.length) continue;
      const kernel = 5 - Math.abs(d);
      wSum += kernel;
      vSum += rawOffsetsSec[idx] * kernel;
    }
    smoothedOffsets[b] = vSum / Math.max(1, wSum);
  }

  // Enforce monotonicity & build tracked beat timestamps
  const beatsSec: number[] = [];
  let sumAbsShiftMs = 0;
  for (let b = 0; b < nominalBeats.length; b++) {
    let t = Math.max(0, nominalBeats[b] + smoothedOffsets[b]);
    if (b > 0) {
      t = Math.max(beatsSec[b - 1] + beatSec * 0.88, Math.min(beatsSec[b - 1] + beatSec * 1.12, t));
    }
    beatsSec.push(t);
    sumAbsShiftMs += Math.abs(t - nominalBeats[b]) * 1000;
  }

  return {
    beatsSec,
    hasClearDrums: true,
    avgDriftMs: sumAbsShiftMs / Math.max(1, beatsSec.length),
  };
}

export interface CrossDeckSyncResult {
  halfDoubleTime: '1x' | '0.5x' | '2x';
  beatShift: number;
  fineOffsetMs: number;
  recommendedInstStartBar: number;
  grooveCorrScore: number;
  hasVocalDrums: boolean;
}

/**
 * Locks Deck B (Vocal song) cleanly onto Deck A (Instrumental Bed) by cross-correlating
 * Demucs isolated Drums+Bass onset grooves (kick & snare lock) directly across beat rotations
 * and ±60 ms micro-pocket lag. Preserves vocal upbeat pickups (anacrusis) rather than pushing
 * pre-beat syllables onto Beat 1!
 */
export function alignVocalDeckToInstDeck(
  instStems: DemucsStemSet,
  instAnalysis: TrackAnalysis,
  instBpm: number,
  instDownbeatSec: number,
  instStartBarOverride: number | null,
  vocalStems: DemucsStemSet,
  vocalAnalysis: TrackAnalysis,
  vocalBpm: number,
  vocalDownbeatSec: number,
  vocalCueBar: number,
  vocalTargetDropBar: number
): CrossDeckSyncResult {
  const halfDoubleTime = computeBestHalfDoubleTime(vocalBpm, instBpm);
  const effVocBpm =
    halfDoubleTime === '0.5x'
      ? vocalBpm * 0.5
      : halfDoubleTime === '2x'
        ? vocalBpm * 2
        : vocalBpm;

  // Choose an instrumental phrase start bar divisible by 4 that contains real steady drums
  let recInstStartBar = Math.max(0, instStartBarOverride ?? 0);
  if (instStartBarOverride === null) {
    recInstStartBar = 0;
    const phraseLimit = Math.max(0, instAnalysis.bars.length - 8);
    if (
      instAnalysis.bars.length >= 4 &&
      instAnalysis.bars[0].drumTransientScore >= 0.42 &&
      instAnalysis.bars[1].drumTransientScore >= 0.42
    ) {
      recInstStartBar = 0;
    } else {
      for (let b = 0; b <= phraseLimit; b += 4) {
        const slice = instAnalysis.bars.slice(b, Math.min(instAnalysis.bars.length, b + 4));
        const avgDrum =
          slice.reduce((acc, m) => acc + m.drumTransientScore, 0) / Math.max(1, slice.length);
        if (avgDrum >= 0.42) {
          recInstStartBar = b;
          break;
        }
      }
    }
  }

  const instBeatSec = 60 / Math.max(50, instBpm);
  const instBarSec = instBeatSec * 4;
  const vocBeatSec = 60 / Math.max(50, effVocBpm);
  const vocBarSec = vocBeatSec * 4;
  const ratio = effVocBpm / Math.max(50, instBpm);

  const instDropStartSec = Math.max(
    0,
    instDownbeatSec + (recInstStartBar + vocalTargetDropBar) * instBarSec
  );
  const vocCueBaseSec = Math.max(0, vocalDownbeatSec + vocalCueBar * vocBarSec);

  // Measure whether Deck B carries usable Demucs drum transients around the cue section
  const vocSr = vocalStems.sampleRate;
  const checkS0 = Math.max(0, Math.floor(vocCueBaseSec * vocSr));
  const checkS1 = Math.min(vocalStems.length, checkS0 + Math.floor(vocBarSec * 8 * vocSr));
  let vocDrumRmsSq = 0;
  let vocDrumCount = 0;
  for (let i = checkS0; i < checkS1; i += 8) {
    vocDrumRmsSq += vocalStems.drumsL[i] * vocalStems.drumsL[i];
    vocDrumCount++;
  }
  const hasVocalDrums =
    Math.sqrt(vocDrumRmsSq / Math.max(1, vocDrumCount)) > 0.015;

  if (!hasVocalDrums) {
    const cleanShift = suggestVocalBeatPhaseShift(
      vocalStems,
      effVocBpm,
      vocalDownbeatSec,
      vocalCueBar
    );
    return {
      halfDoubleTime,
      beatShift: Math.round(cleanShift),
      fineOffsetMs: 0,
      recommendedInstStartBar: recInstStartBar,
      grooveCorrScore: 0.78,
      hasVocalDrums: false,
    };
  }

  // Sample both decks onto a common 250 Hz (4 ms) beat-synchronized timebase
  // covering up to 8 bars so kick (1&3) and snare (2&4) pockets align directly.
  const fr = 250;
  const dt = 1 / fr;
  const evalDurOutSec = Math.min(
    instBarSec * 8,
    Math.max(instBarSec * 2, instStems.durationSec - instDropStartSec),
    Math.max(instBarSec * 2, (vocalStems.durationSec - vocCueBaseSec) * ratio)
  );
  const numFrames = Math.max(128, Math.floor(evalDurOutSec * fr));

  const instLow = new Float32Array(numFrames);
  const instHigh = new Float32Array(numFrames);
  const instSr = instStems.sampleRate;
  const iLp = makeLowpassCoeffs(instSr, 145, 0.707);
  const iHp = makeHighpassCoeffs(instSr, 1100, 0.707);
  let ilx1 = 0, ilx2 = 0, ily1 = 0, ily2 = 0;
  let ihx1 = 0, ihx2 = 0, ihy1 = 0, ihy2 = 0;

  // Sample per-frame RMS onset energy across Deck A instrumental drums+bass
  const instStartS = Math.floor(instDropStartSec * instSr);
  const instStepS = Math.max(1, Math.round(dt * instSr));
  let prevIL = 0, prevIH = 0;
  for (let f = 0; f < numFrames; f++) {
    const s0 = instStartS + f * instStepS;
    const s1 = Math.min(instStems.length, s0 + instStepS);
    let eL = 0, eH = 0, cnt = 0;
    for (let i = s0; i < s1; i++) {
      const m =
        0.5 * (instStems.drumsL[i] + instStems.drumsR[i]) +
        0.15 * (instStems.bassL[i] + instStems.bassR[i]);
      const ly = iLp.b0 * m + iLp.b1 * ilx1 + iLp.b2 * ilx2 - iLp.a1 * ily1 - iLp.a2 * ily2;
      ilx2 = ilx1; ilx1 = m; ily2 = ily1; ily1 = ly;
      const hy = iHp.b0 * m + iHp.b1 * ihx1 + iHp.b2 * ihx2 - iHp.a1 * ihy1 - iHp.a2 * ihy2;
      ihx2 = ihx1; ihx1 = m; ihy2 = ihy1; ihy1 = hy;
      eL += ly * ly;
      eH += hy * hy;
      cnt++;
    }
    const rmsL = Math.sqrt(eL / Math.max(1, cnt));
    const rmsH = Math.sqrt(eH / Math.max(1, cnt));
    instLow[f] = Math.max(0, rmsL - prevIL * 0.75);
    instHigh[f] = Math.max(0, rmsH - prevIH * 0.78);
    prevIL = rmsL;
    prevIH = rmsH;
  }

  // Helper to compute normalized stretched Deck B drums+bass onset envelope at any cue start
  const vLp = makeLowpassCoeffs(vocSr, 145, 0.707);
  const vHp = makeHighpassCoeffs(vocSr, 1100, 0.707);

  const evalVocEnvelopeCorr = (beatShift: number, lagFrames: number): number => {
    const cueSec = vocCueBaseSec + beatShift * vocBeatSec;
    if (cueSec < 0 || cueSec + evalDurOutSec / ratio > vocalStems.durationSec + 0.5) {
      return -1;
    }

    let vlx1 = 0, vlx2 = 0, vly1 = 0, vly2 = 0;
    let vhx1 = 0, vhx2 = 0, vhy1 = 0, vhy2 = 0;
    let num = 0;
    let denI = 0;
    let denV = 0;
    let prevVL = 0;
    let prevVH = 0;
    const srcSpanS = Math.max(4, Math.round((dt / ratio) * vocSr));

    for (let f = 0; f < numFrames; f++) {
      const instIdx = f + lagFrames;
      const vocTimeSec = cueSec + f * dt / ratio;
      const vs0 = Math.round(vocTimeSec * vocSr);
      const vs1 = Math.min(vocalStems.length, vs0 + srcSpanS);
      let eL = 0, eH = 0, cnt = 0;
      for (let i = Math.max(0, vs0); i < vs1; i++) {
        const m =
          0.5 * (vocalStems.drumsL[i] + vocalStems.drumsR[i]) +
          0.15 * (vocalStems.bassL[i] + vocalStems.bassR[i]);
        const ly = vLp.b0 * m + vLp.b1 * vlx1 + vLp.b2 * vlx2 - vLp.a1 * vly1 - vLp.a2 * vly2;
        vlx2 = vlx1; vlx1 = m; vly2 = vly1; vly1 = ly;
        const hy = vHp.b0 * m + vHp.b1 * vhx1 + vHp.b2 * vhx2 - vHp.a1 * vhy1 - vHp.a2 * vhy2;
        vhx2 = vhx1; vhx1 = m; vhy2 = vhy1; vhy1 = hy;
        eL += ly * ly;
        eH += hy * hy;
        cnt++;
      }
      const rmsVL = Math.sqrt(eL / Math.max(1, cnt));
      const rmsVH = Math.sqrt(eH / Math.max(1, cnt));
      const vFluxL = Math.max(0, rmsVL - prevVL * 0.75);
      const vFluxH = Math.max(0, rmsVH - prevVH * 0.78);
      prevVL = rmsVL;
      prevVH = rmsVH;

      if (instIdx >= 0 && instIdx < numFrames) {
        const iVal = instLow[instIdx] * 1.4 + instHigh[instIdx] * 0.8;
        const vVal = vFluxL * 1.4 + vFluxH * 0.8;
        num += iVal * vVal;
        denI += iVal * iVal;
        denV += vVal * vVal;
      }
    }

    const denom = Math.sqrt(denI * denV);
    return denom > 1e-8 ? num / denom : 0;
  };

  // Sweep integer beat rotations [-2, -1, 0, 1, 2] and coarse lags to locate exact bar-1 beat lock
  const wholeBeatShifts = [0, 1, -1, 2, -2];
  let bestBeatShift = 0;
  let bestLagFrames = 0;
  let bestCorr = -1;

  for (const bs of wholeBeatShifts) {
    // Only consider negative shift if cueSec won't go negative
    if (vocCueBaseSec + bs * vocBeatSec < 0) continue;
    for (let lag = -14; lag <= 14; lag += 2) {
      const c = evalVocEnvelopeCorr(bs, lag);
      const zeroBias = bs === 0 ? 1.03 : 1.0; // slight preference for Bar 1 at 0 if symmetric
      if (c * zeroBias > bestCorr) {
        bestCorr = c * zeroBias;
        bestBeatShift = bs;
        bestLagFrames = lag;
      }
    }
  }

  // Only allow half-beat fix if Deck B downbeat landed squarely on an upbeat (requires >28% stronger groove lock)
  for (const hs of [0.5, -0.5]) {
    if (vocCueBaseSec + hs * vocBeatSec < 0) continue;
    for (let lag = -6; lag <= 6; lag += 2) {
      const c = evalVocEnvelopeCorr(hs, lag);
      if (c > bestCorr * 1.28) {
        bestCorr = c;
        bestBeatShift = hs;
        bestLagFrames = lag;
      }
    }
  }

  // Fine 2 ms polish around winning lag
  let polishedLag = bestLagFrames;
  let polishedCorr = evalVocEnvelopeCorr(bestBeatShift, bestLagFrames);
  for (let lag = bestLagFrames - 3; lag <= bestLagFrames + 3; lag++) {
    const c = evalVocEnvelopeCorr(bestBeatShift, lag);
    if (c > polishedCorr) {
      polishedCorr = c;
      polishedLag = lag;
    }
  }

  // Sign convention: positive `lagFrames` meant Deck B needed to be delayed? Let's verify:
  // In evalVocEnvelopeCorr, frame `f` of Deck B matches `instIdx = f + lagFrames` of Deck A.
  // So Deck B frame 0 aligns with `f_A = lagFrames` -> `vocalDropSec + fineOffsetMs = instStart + lagFrames * dt`!
  // Thus fineOffsetMs = polishedLag * dt * 1000!
  const fineOffsetMs = Math.max(-75, Math.min(75, Math.round(polishedLag * dt * 1000)));

  return {
    halfDoubleTime,
    beatShift: bestBeatShift,
    fineOffsetMs,
    recommendedInstStartBar: recInstStartBar,
    grooveCorrScore: Math.min(0.99, polishedCorr),
    hasVocalDrums: true,
  };
}

