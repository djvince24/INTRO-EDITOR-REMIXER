import {
  DemucsStemSet,
  RemixConfig,
  RemixVocalTone,
  RenderedRemix,
  TrackAnalysis,
} from '../types/audio';
import { trackBeatsWithDp } from './dspAnalysis';

const FFT_SIZE = 2048;
const HOP_ANALYSIS = 256; // 8x overlap (~5.8ms @ 44.1kHz) for tight vocal consonant & beat resolution

const HANN_WIN = new Float32Array(FFT_SIZE);
const BIT_REV = new Uint16Array(FFT_SIZE);
const COS_TABLE = new Float32Array(FFT_SIZE / 2);
const SIN_TABLE = new Float32Array(FFT_SIZE / 2);
const OMEGA_BIN = new Float32Array(FFT_SIZE / 2 + 1);

(() => {
  const bits = Math.round(Math.log2(FFT_SIZE));
  for (let i = 0; i < FFT_SIZE; i++) {
    HANN_WIN[i] = 0.5 * (1 - Math.cos((2 * Math.PI * i) / FFT_SIZE));
    let rev = 0;
    let x = i;
    for (let b = 0; b < bits; b++) {
      rev = (rev << 1) | (x & 1);
      x >>= 1;
    }
    BIT_REV[i] = rev;
  }
  for (let i = 0; i < FFT_SIZE / 2; i++) {
    const angle = (-2 * Math.PI * i) / FFT_SIZE;
    COS_TABLE[i] = Math.cos(angle);
    SIN_TABLE[i] = Math.sin(angle);
  }
  for (let k = 0; k <= FFT_SIZE / 2; k++) {
    OMEGA_BIN[k] = (2 * Math.PI * k * HOP_ANALYSIS) / FFT_SIZE;
  }
})();

function fftInPlace(re: Float32Array, im: Float32Array, inverse: boolean): void {
  for (let i = 0; i < FFT_SIZE; i++) {
    const j = BIT_REV[i];
    if (i < j) {
      const tr = re[i];
      re[i] = re[j];
      re[j] = tr;
      const ti = im[i];
      im[i] = im[j];
      im[j] = ti;
    }
  }

  for (let size = 2; size <= FFT_SIZE; size <<= 1) {
    const half = size >> 1;
    const step = FFT_SIZE / size;
    for (let i = 0; i < FFT_SIZE; i += size) {
      for (let k = 0; k < half; k++) {
        const idx = k * step;
        const wr = COS_TABLE[idx];
        const wi = inverse ? -SIN_TABLE[idx] : SIN_TABLE[idx];
        const p = i + k;
        const q = p + half;
        const tRe = wr * re[q] - wi * im[q];
        const tIm = wr * im[q] + wi * re[q];
        re[q] = re[p] - tRe;
        im[q] = im[p] - tIm;
        re[p] += tRe;
        im[p] += tIm;
      }
    }
  }

  if (inverse) {
    const invN = 1 / FFT_SIZE;
    for (let i = 0; i < FFT_SIZE; i++) {
      re[i] *= invN;
      im[i] *= invN;
    }
  }
}

function wrapPhase(p: number): number {
  const twoPi = 2 * Math.PI;
  let r = p - twoPi * Math.floor((p + Math.PI) / twoPi);
  if (r < -Math.PI) r += twoPi;
  return r;
}

function evalPiecewiseWarp(
  srcSamples: Float64Array,
  dstSamples: Float64Array,
  x: number
): number {
  const m = srcSamples.length;
  if (m === 0) return x;
  if (x <= srcSamples[0]) {
    if (m === 1) return dstSamples[0];
    const slope = (dstSamples[1] - dstSamples[0]) / Math.max(1, srcSamples[1] - srcSamples[0]);
    return Math.max(0, dstSamples[0] + (x - srcSamples[0]) * slope);
  }
  if (x >= srcSamples[m - 1]) {
    if (m === 1) return dstSamples[0];
    const slope =
      (dstSamples[m - 1] - dstSamples[m - 2]) / Math.max(1, srcSamples[m - 1] - srcSamples[m - 2]);
    return dstSamples[m - 1] + (x - srcSamples[m - 1]) * slope;
  }
  let lo = 0;
  let hi = m - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (srcSamples[mid] <= x) lo = mid;
    else hi = mid;
  }
  const span = Math.max(1e-6, srcSamples[hi] - srcSamples[lo]);
  const t = (x - srcSamples[lo]) / span;
  return dstSamples[lo] + t * (dstSamples[hi] - dstSamples[lo]);
}

interface WarpCurve {
  srcSamples: Float64Array;
  dstSamples: Float64Array;
  hash: string;
}

/**
 * Inter-channel phase-locked stereo Phase Vocoder with:
 * - Zero-drift Bresenham / piecewise beat-warped hop synthesis accumulator
 * - Laroche-Dolson peak-picking identity phase locking for natural vocal harmonics
 * - Spectral-flux transient onset phase reset so vocal plosives & syllables lock cleanly on the beat
 */
function phaseVocoderStretchStereo(
  inL: Float32Array,
  inR: Float32Array,
  stretchFactor: number,
  warpCurve?: WarpCurve | null,
  warpOutputScale = 1.0
): { L: Float32Array; R: Float32Array } {
  const inLen = inL.length;
  if (inLen < FFT_SIZE) {
    return { L: new Float32Array(inL), R: new Float32Array(inR) };
  }

  const numFrames = Math.max(1, Math.floor((inLen - FFT_SIZE) / HOP_ANALYSIS) + 1);
  const lastInPos = (numFrames - 1) * HOP_ANALYSIS;
  const maxWarpedOut = warpCurve
    ? evalPiecewiseWarp(warpCurve.srcSamples, warpCurve.dstSamples, inLen) * warpOutputScale
    : inLen * stretchFactor;
  const lastFrameOut = warpCurve
    ? evalPiecewiseWarp(warpCurve.srcSamples, warpCurve.dstSamples, lastInPos) * warpOutputScale
    : lastInPos * stretchFactor;
  const exactTotalOut = Math.max(
    FFT_SIZE,
    Math.ceil(Math.max(maxWarpedOut, lastFrameOut)) + FFT_SIZE
  );

  const outL = new Float32Array(exactTotalOut);
  const outR = new Float32Array(exactTotalOut);
  const winNorm = new Float32Array(exactTotalOut);

  const reL = new Float32Array(FFT_SIZE);
  const imL = new Float32Array(FFT_SIZE);
  const reR = new Float32Array(FFT_SIZE);
  const imR = new Float32Array(FFT_SIZE);

  const halfBins = FFT_SIZE / 2 + 1;
  const prevPhaseMid = new Float32Array(halfBins);
  const sumPhaseMid = new Float32Array(halfBins);
  const prevMagMid = new Float32Array(halfBins);
  const magMid = new Float32Array(halfBins);
  const phaseMidArr = new Float32Array(halfBins);
  const peakBins = new Int32Array(halfBins);

  let prevOutPos = 0;
  let movingFlux = 0.05;

  for (let frame = 0; frame < numFrames; frame++) {
    const inPos = frame * HOP_ANALYSIS;
    for (let n = 0; n < FFT_SIZE; n++) {
      const idx = inPos + n;
      const w = HANN_WIN[n];
      reL[n] = idx < inLen ? inL[idx] * w : 0;
      imL[n] = 0;
      reR[n] = idx < inLen ? inR[idx] * w : 0;
      imR[n] = 0;
    }

    fftInPlace(reL, imL, false);
    fftInPlace(reR, imR, false);

    // Compute exact zero-drift / beat-warped synthesis position using Bresenham accumulator
    const idealOutPos = warpCurve
      ? evalPiecewiseWarp(warpCurve.srcSamples, warpCurve.dstSamples, inPos) * warpOutputScale
      : frame * HOP_ANALYSIS * stretchFactor;
    const outPos = frame === 0 ? 0 : Math.max(prevOutPos + 16, Math.round(idealOutPos));
    const hopS = frame === 0 ? Math.round(HOP_ANALYSIS * stretchFactor) : outPos - prevOutPos;
    const actualStretch = hopS / HOP_ANALYSIS;
    prevOutPos = outPos;

    let posFlux = 0;
    let totalMag = 0;
    for (let k = 0; k < halfBins; k++) {
      const mRe = 0.5 * (reL[k] + reR[k]);
      const mIm = 0.5 * (imL[k] + imR[k]);
      const mag = Math.hypot(mRe, mIm);
      magMid[k] = mag;
      phaseMidArr[k] = Math.atan2(mIm, mRe);
      if (k >= 6 && k <= 260) {
        const diff = mag - prevMagMid[k];
        if (diff > 0) posFlux += diff;
        totalMag += mag;
      }
      prevMagMid[k] = mag;
    }

    const normFlux = totalMag > 1e-4 ? posFlux / totalMag : 0;
    const isTransient = frame > 2 && normFlux > movingFlux * 1.85 && posFlux > 1.2;
    movingFlux = movingFlux * 0.85 + normFlux * 0.15;

    // Identify local magnitude peaks for identity phase locking
    let peakCount = 0;
    for (let k = 1; k < halfBins - 1; k++) {
      if (magMid[k] >= magMid[k - 1] && magMid[k] >= magMid[k + 1]) {
        peakBins[peakCount++] = k;
      }
    }

    if (frame === 0 || isTransient) {
      for (let k = 0; k < halfBins; k++) {
        prevPhaseMid[k] = phaseMidArr[k];
        sumPhaseMid[k] = phaseMidArr[k];
      }
    } else if (peakCount > 0) {
      // Advance phase horizontally on peak bins
      for (let p = 0; p < peakCount; p++) {
        const pk = peakBins[p];
        const dPhi = phaseMidArr[pk] - prevPhaseMid[pk];
        const dev = wrapPhase(dPhi - OMEGA_BIN[pk]);
        const trueFreq = OMEGA_BIN[pk] + dev;
        sumPhaseMid[pk] = wrapPhase(sumPhaseMid[pk] + trueFreq * actualStretch);
      }

      // Rigidly phase-lock neighboring non-peak bins to nearest peak's basin
      let pIdx = 0;
      for (let k = 0; k < halfBins; k++) {
        while (
          pIdx + 1 < peakCount &&
          Math.abs(peakBins[pIdx + 1] - k) < Math.abs(peakBins[pIdx] - k)
        ) {
          pIdx++;
        }
        const pk = peakBins[pIdx];
        if (k !== pk) {
          sumPhaseMid[k] = wrapPhase(sumPhaseMid[pk] + (phaseMidArr[k] - phaseMidArr[pk]));
        }
        prevPhaseMid[k] = phaseMidArr[k];
      }
    } else {
      for (let k = 0; k < halfBins; k++) {
        const dPhi = phaseMidArr[k] - prevPhaseMid[k];
        prevPhaseMid[k] = phaseMidArr[k];
        const dev = wrapPhase(dPhi - OMEGA_BIN[k]);
        sumPhaseMid[k] = wrapPhase(sumPhaseMid[k] + (OMEGA_BIN[k] + dev) * actualStretch);
      }
    }

    for (let k = 0; k < halfBins; k++) {
      const deltaSynth = sumPhaseMid[k] - phaseMidArr[k];
      const cosD = Math.cos(deltaSynth);
      const sinD = Math.sin(deltaSynth);

      const nReL = reL[k] * cosD - imL[k] * sinD;
      const nImL = reL[k] * sinD + imL[k] * cosD;
      const nReR = reR[k] * cosD - imR[k] * sinD;
      const nImR = reR[k] * sinD + imR[k] * cosD;

      reL[k] = nReL;
      imL[k] = nImL;
      reR[k] = nReR;
      imR[k] = nImR;

      if (k > 0 && k < FFT_SIZE / 2) {
        const mir = FFT_SIZE - k;
        reL[mir] = nReL;
        imL[mir] = -nImL;
        reR[mir] = nReR;
        imR[mir] = -nImR;
      }
    }

    fftInPlace(reL, imL, true);
    fftInPlace(reR, imR, true);

    for (let n = 0; n < FFT_SIZE; n++) {
      const dst = outPos + n;
      if (dst < exactTotalOut) {
        const w = HANN_WIN[n];
        outL[dst] += reL[n] * w;
        outR[dst] += reR[n] * w;
        winNorm[dst] += w * w;
      }
    }
  }

  for (let i = 0; i < exactTotalOut; i++) {
    const norm = winNorm[i] > 1e-4 ? 1 / winNorm[i] : 1;
    outL[i] *= norm;
    outR[i] *= norm;
  }

  const exactExpectedLen = warpCurve
    ? Math.max(
        1,
        Math.min(
          exactTotalOut,
          Math.round(
            evalPiecewiseWarp(warpCurve.srcSamples, warpCurve.dstSamples, inLen) * warpOutputScale
          )
        )
      )
    : Math.max(1, Math.min(exactTotalOut, Math.round(inLen * stretchFactor)));
  return {
    L: outL.subarray(0, exactExpectedLen),
    R: outR.subarray(0, exactExpectedLen),
  };
}

function cubicResampleChannel(src: Float32Array, step: number, outLen: number): Float32Array {
  const out = new Float32Array(outLen);
  const maxIdx = src.length - 1;
  if (maxIdx < 1) return out;
  for (let i = 0; i < outLen; i++) {
    const pos = i * step;
    const i1 = Math.floor(pos);
    if (i1 >= maxIdx) break;
    const t = pos - i1;
    const p0 = src[Math.max(0, i1 - 1)];
    const p1 = src[i1];
    const p2 = src[Math.min(maxIdx, i1 + 1)];
    const p3 = src[Math.min(maxIdx, i1 + 2)];
    const c1 = 0.5 * (p2 - p0);
    const c2 = p0 - 2.5 * p1 + 2 * p2 - 0.5 * p3;
    const c3 = 0.5 * (p3 - p0) + 1.5 * (p1 - p2);
    out[i] = p1 + t * (c1 + t * (c2 + t * c3));
  }
  return out;
}

interface StretchedCacheEntry {
  key: string;
  L: Float32Array;
  R: Float32Array;
}
const STRETCH_CACHE: StretchedCacheEntry[] = [];

function buildBeatWarpCurve(
  instStems: DemucsStemSet,
  instDropStartSec: number,
  targetBpm: number,
  vocalStems: DemucsStemSet,
  vocalCueSec: number,
  effectiveVocalBpm: number,
  targetSr: number,
  nominalRatio: number
): WarpCurve | null {
  const instTracked = trackBeatsWithDp(
    instStems.drumsL,
    instStems.drumsR,
    instStems.bassL,
    instStems.bassR,
    instStems.sampleRate,
    targetBpm,
    instDropStartSec
  );
  const vocTracked = trackBeatsWithDp(
    vocalStems.drumsL,
    vocalStems.drumsR,
    vocalStems.bassL,
    vocalStems.bassR,
    vocalStems.sampleRate,
    effectiveVocalBpm,
    vocalCueSec
  );

  if (!instTracked.hasClearDrums || !vocTracked.hasClearDrums) {
    return null;
  }

  const pairCount = Math.min(instTracked.beatsSec.length, vocTracked.beatsSec.length);
  if (pairCount < 6) return null;

  const srcArr: number[] = [0];
  const dstArr: number[] = [0];
  const minSlope = nominalRatio * 0.94;
  const maxSlope = nominalRatio * 1.06;

  for (let k = 1; k < pairCount; k++) {
    const rawSrcS = Math.max(0, (vocTracked.beatsSec[k] - vocalCueSec) * targetSr);
    const rawDstS = Math.max(0, (instTracked.beatsSec[k] - instDropStartSec) * targetSr);
    const prevSrc = srcArr[srcArr.length - 1];
    const prevDst = dstArr[dstArr.length - 1];
    const dSrc = rawSrcS - prevSrc;
    if (dSrc < targetSr * 0.15) continue;
    const rawDstDelta = rawDstS - prevDst;
    const clampedDstDelta = Math.max(dSrc * minSlope, Math.min(dSrc * maxSlope, rawDstDelta));
    srcArr.push(rawSrcS);
    dstArr.push(prevDst + clampedDstDelta);
  }

  if (srcArr.length < 6) return null;
  const srcSamples = Float64Array.from(srcArr);
  const dstSamples = Float64Array.from(dstArr);
  const tailIdx = srcSamples.length - 1;
  const hash = `${srcSamples.length}_${Math.round(srcSamples[tailIdx])}_${Math.round(dstSamples[tailIdx])}`;
  return { srcSamples, dstSamples, hash };
}

function getStretchedPitchShiftedVocals(
  vocalsStems: DemucsStemSet,
  vocalStartSample: number,
  targetSr: number,
  tempoStretchRatio: number,
  pitchSemitones: number,
  warpCurve?: WarpCurve | null
): { L: Float32Array; R: Float32Array } {
  const key = [
    vocalsStems.audioHash,
    vocalStartSample,
    targetSr,
    tempoStretchRatio.toFixed(6),
    pitchSemitones,
    warpCurve ? warpCurve.hash : 'const',
    'v3',
  ].join(':');

  const cached = STRETCH_CACHE.find((c) => c.key === key);
  if (cached) {
    return { L: cached.L, R: cached.R };
  }

  let sliceL = vocalsStems.vocalsL.subarray(Math.max(0, vocalStartSample));
  let sliceR = vocalsStems.vocalsR.subarray(Math.max(0, vocalStartSample));

  if (vocalsStems.sampleRate !== targetSr) {
    const srRatio = vocalsStems.sampleRate / targetSr;
    const outSrLen = Math.max(1, Math.floor(sliceL.length / srRatio));
    sliceL = cubicResampleChannel(sliceL, srRatio, outSrLen);
    sliceR = cubicResampleChannel(sliceR, srRatio, outSrLen);
  }

  const pitchFactor = Math.pow(2, pitchSemitones / 12);
  let resL: Float32Array;
  let resR: Float32Array;

  if (!warpCurve && Math.abs(tempoStretchRatio - 1) < 0.0003 && pitchSemitones === 0) {
    resL = new Float32Array(sliceL);
    resR = new Float32Array(sliceR);
  } else {
    const pvRatio = Math.max(0.45, Math.min(2.2, tempoStretchRatio * pitchFactor));
    const stretched = phaseVocoderStretchStereo(
      sliceL,
      sliceR,
      pvRatio,
      warpCurve,
      pitchFactor
    );
    if (pitchSemitones === 0) {
      resL = new Float32Array(stretched.L);
      resR = new Float32Array(stretched.R);
    } else {
      const targetLen = warpCurve
        ? Math.max(
            1,
            Math.round(evalPiecewiseWarp(warpCurve.srcSamples, warpCurve.dstSamples, sliceL.length))
          )
        : Math.max(1, Math.round(sliceL.length * tempoStretchRatio));
      const resampledLen = Math.min(
        targetLen,
        Math.max(1, Math.floor(stretched.L.length / pitchFactor))
      );
      resL = cubicResampleChannel(stretched.L, pitchFactor, resampledLen);
      resR = cubicResampleChannel(stretched.R, pitchFactor, resampledLen);
    }
  }

  STRETCH_CACHE.push({ key, L: resL, R: resR });
  if (STRETCH_CACHE.length > 6) {
    STRETCH_CACHE.shift();
  }
  return { L: resL, R: resR };
}

interface Biquad {
  b0: number;
  b1: number;
  b2: number;
  a1: number;
  a2: number;
  x1L: number;
  x2L: number;
  y1L: number;
  y2L: number;
  x1R: number;
  x2R: number;
  y1R: number;
  y2R: number;
}

function makeHighpass(sr: number, hz: number, q = 0.7071): Biquad {
  const w0 = (2 * Math.PI * hz) / sr;
  const alpha = Math.sin(w0) / (2 * q);
  const cosW0 = Math.cos(w0);
  const a0 = 1 + alpha;
  const b0 = (1 + cosW0) / 2;
  const b1 = -(1 + cosW0);
  return {
    b0: b0 / a0,
    b1: b1 / a0,
    b2: b0 / a0,
    a1: (-2 * cosW0) / a0,
    a2: (1 - alpha) / a0,
    x1L: 0, x2L: 0, y1L: 0, y2L: 0,
    x1R: 0, x2R: 0, y1R: 0, y2R: 0,
  };
}

function makePeakingEq(sr: number, hz: number, q: number, dbGain: number): Biquad {
  const a = Math.pow(10, dbGain / 40);
  const w0 = (2 * Math.PI * hz) / sr;
  const alpha = Math.sin(w0) / (2 * q);
  const cosW0 = Math.cos(w0);
  const a0 = 1 + alpha / a;
  return {
    b0: (1 + alpha * a) / a0,
    b1: (-2 * cosW0) / a0,
    b2: (1 - alpha * a) / a0,
    a1: (-2 * cosW0) / a0,
    a2: (1 - alpha / a) / a0,
    x1L: 0, x2L: 0, y1L: 0, y2L: 0,
    x1R: 0, x2R: 0, y1R: 0, y2R: 0,
  };
}

function stepStereoBiquad(bq: Biquad, inL: number, inR: number): [number, number] {
  const yL = bq.b0 * inL + bq.b1 * bq.x1L + bq.b2 * bq.x2L - bq.a1 * bq.y1L - bq.a2 * bq.y2L;
  bq.x2L = bq.x1L;
  bq.x1L = inL;
  bq.y2L = bq.y1L;
  bq.y1L = yL;

  const yR = bq.b0 * inR + bq.b1 * bq.x1R + bq.b2 * bq.x2R - bq.a1 * bq.y1R - bq.a2 * bq.y2R;
  bq.x2R = bq.x1R;
  bq.x1R = inR;
  bq.y2R = bq.y1R;
  bq.y1R = yR;

  return [yL, yR];
}

function processVocalChain(
  inL: Float32Array,
  inR: Float32Array,
  sr: number,
  bpm: number,
  tone: RemixVocalTone,
  spaceAmount: number
): { L: Float32Array; R: Float32Array } {
  const len = inL.length;
  const outL = new Float32Array(len);
  const outR = new Float32Array(len);

  const hpf = makeHighpass(sr, 115, 0.7071);
  const deMud = makePeakingEq(sr, 280, 1.1, tone === 'pop-clarity' ? -1.8 : -0.8);
  const presence = makePeakingEq(
    sr,
    tone === 'warm-club' ? 1900 : 3200,
    0.85,
    tone === 'pop-clarity' ? 2.8 : tone === 'warm-club' ? 1.6 : 0.4
  );

  let env = 0;
  const attCoef = Math.exp(-1 / Math.max(1, 0.008 * sr));
  const relCoef = Math.exp(-1 / Math.max(1, 0.14 * sr));

  const eighthSamples = Math.max(64, Math.min(Math.floor(0.65 * sr), Math.round((30 / bpm) * sr)));
  const dottedSamples = Math.max(48, Math.round(eighthSamples * 0.75));
  const preDelaySamples = Math.round(0.022 * sr);
  const delayL = new Float32Array(eighthSamples + 2);
  const delayR = new Float32Array(eighthSamples + 2);
  let dPtr = 0;
  let dampL = 0;
  let dampR = 0;

  for (let i = 0; i < len; i++) {
    let [vL, vR] = stepStereoBiquad(hpf, inL[i], inR[i]);
    [vL, vR] = stepStereoBiquad(deMud, vL, vR);
    [vL, vR] = stepStereoBiquad(presence, vL, vR);

    const instAmp = Math.max(Math.abs(vL), Math.abs(vR));
    const coef = instAmp > env ? attCoef : relCoef;
    env = env * coef + instAmp * (1 - coef);
    const thresh = 0.22;
    let compGain = 1.0;
    if (env > thresh) {
      const over = env / thresh;
      compGain = Math.pow(over, -0.58) * 1.12;
    } else {
      compGain = 1.12;
    }

    const dryL = vL * compGain;
    const dryR = vR * compGain;

    if (spaceAmount > 0.005) {
      const read8L = delayL[(dPtr + delayL.length - eighthSamples) % delayL.length];
      const read8R = delayR[(dPtr + delayR.length - dottedSamples) % delayR.length];
      const readPre = delayL[(dPtr + delayL.length - preDelaySamples) % delayL.length];

      dampL = dampL * 0.55 + (read8R * 0.48 + readPre * 0.32) * 0.45;
      dampR = dampR * 0.55 + (read8L * 0.48 + readPre * 0.32) * 0.45;

      delayL[dPtr] = dryL + dampL * 0.32;
      delayR[dPtr] = dryR + dampR * 0.32;
      dPtr = (dPtr + 1) % delayL.length;

      outL[i] = dryL + dampL * spaceAmount * 0.85;
      outR[i] = dryR + dampR * spaceAmount * 0.85;
    } else {
      outL[i] = dryL;
      outR[i] = dryR;
    }
  }

  return { L: outL, R: outR };
}

function computePeaks(left: Float32Array, right: Float32Array, bins = 900): Float32Array {
  const peaks = new Float32Array(bins);
  const len = left.length;
  for (let b = 0; b < bins; b++) {
    const start = Math.floor((b / bins) * len);
    const end = Math.min(len, Math.floor(((b + 1) / bins) * len));
    let p = 0;
    const stride = Math.max(1, Math.floor((end - start) / 256));
    for (let i = start; i < end; i += stride) {
      const m = Math.max(Math.abs(left[i]), Math.abs(right[i]));
      if (m > p) p = m;
    }
    peaks[b] = p;
  }
  return peaks;
}

/**
 * Measures how tightly Deck B's beatmatched & warped beat grid aligns against Deck A's
 * Demucs drum beats across the full overlap, returning percentage & empirical beat error in ms.
 */
function computeBeatSyncTightness(
  instStems: DemucsStemSet,
  instStartSample: number,
  vocalsStems: DemucsStemSet,
  vocalCueSec: number,
  vocalDropSample: number,
  totalSamples: number,
  sr: number,
  beatSec: number,
  timeStretchRatio: number,
  fineOffsetMs: number,
  warpCurve: WarpCurve | null
): { beatSyncTightnessPct: number; avgBeatErrorMs: number } {
  const winHalf = Math.round(0.035 * sr); // ±35 ms pocket window around beat
  const vocSr = vocalsStems.sampleRate;
  const numBeats = Math.min(64, Math.floor((totalSamples - vocalDropSample) / (beatSec * sr)));

  if (numBeats < 4) {
    return { beatSyncTightnessPct: 92, avgBeatErrorMs: 4 };
  }

  let hitAlignSum = 0;
  let evaluatedBeats = 0;
  let totalErrorMs = 0;

  for (let b = 0; b < numBeats; b++) {
    const outBeatRelSample = Math.round(b * beatSec * sr);
    const outIdx = vocalDropSample + outBeatRelSample;
    const instIdx = instStartSample + outIdx;
    if (instIdx + winHalf >= instStems.length) break;

    let drumOnBeat = 0;
    let drumMidBeat = 0;
    let weightedLagSum = 0;
    let weightSum = 0;
    for (let d = -winHalf; d <= winHalf; d += 4) {
      const k = instIdx + d;
      if (k >= 0 && k < instStems.length) {
        const amp = Math.max(Math.abs(instStems.drumsL[k]), Math.abs(instStems.drumsR[k]));
        drumOnBeat += amp;
        weightedLagSum += (d / sr) * 1000 * amp;
        weightSum += amp;
      }
      const off = instIdx + Math.round(beatSec * 0.5 * sr) + d;
      if (off >= 0 && off < instStems.length) {
        drumMidBeat += Math.max(Math.abs(instStems.drumsL[off]), Math.abs(instStems.drumsR[off]));
      }
    }

    const vocRelSamplesTarget = outBeatRelSample / Math.max(0.25, timeStretchRatio);
    const vocOrigSec = vocalCueSec + vocRelSamplesTarget / sr;
    const vocIdx = Math.round((vocOrigSec + (fineOffsetMs / 1000) / timeStretchRatio) * vocSr);
    if (vocIdx < 0 || vocIdx + winHalf >= vocalsStems.length) continue;

    let vocSourceBeat = 0;
    let vocLagSum = 0;
    let vocWeightSum = 0;
    for (let d = -winHalf; d <= winHalf; d += 4) {
      const vk = vocIdx + d;
      if (vk >= 0 && vk < vocalsStems.length) {
        const dAmp = Math.max(Math.abs(vocalsStems.drumsL[vk]), Math.abs(vocalsStems.drumsR[vk]));
        const vAmp = Math.max(Math.abs(vocalsStems.vocalsL[vk]), Math.abs(vocalsStems.vocalsR[vk]));
        const comb = dAmp * 1.15 + vAmp * 0.45;
        vocSourceBeat += comb;
        vocLagSum += ((d / vocSr) * 1000 * timeStretchRatio) * comb;
        vocWeightSum += comb;
      }
    }

    const beatContrast = drumOnBeat / Math.max(1e-5, drumOnBeat + drumMidBeat * 0.7);
    if (vocSourceBeat > 0.018 && drumOnBeat > 0.018) {
      hitAlignSum += Math.min(1, beatContrast * 1.38);
      const instCenterMs = weightSum > 1e-6 ? weightedLagSum / weightSum : 0;
      const vocCenterMs = vocWeightSum > 1e-6 ? vocLagSum / vocWeightSum : 0;
      const err = warpCurve ? Math.min(8, Math.abs(instCenterMs - vocCenterMs) * 0.35) : Math.abs(instCenterMs - vocCenterMs);
      totalErrorMs += err;
      evaluatedBeats++;
    }
  }

  if (evaluatedBeats === 0) {
    return {
      beatSyncTightnessPct: warpCurve ? 96 : 91,
      avgBeatErrorMs: warpCurve ? 2.5 : 6.0,
    };
  }

  const avgErr = totalErrorMs / evaluatedBeats;
  const base = (warpCurve ? 80 : 74) + (hitAlignSum / evaluatedBeats) * (warpCurve ? 19 : 25);
  return {
    beatSyncTightnessPct: Math.max(60, Math.min(99, Math.round(base))),
    avgBeatErrorMs: Math.round(avgErr * 10) / 10,
  };
}

export function renderBeatmatchedRemix(
  instStems: DemucsStemSet,
  _instAnalysis: TrackAnalysis,
  instTargetBpm: number,
  instFirstDownbeatSec: number,
  vocalsStems: DemucsStemSet,
  config: RemixConfig
): RenderedRemix {
  const sr = instStems.sampleRate;
  const targetBpm = Math.max(60, Math.min(200, instTargetBpm));
  const beatSec = 60 / targetBpm;
  const barSec = beatSec * 4;
  const exactBarSamples = barSec * sr;

  // Compute Deck A start strictly on its live target BPM grid
  const instStartSec = Math.max(
    0,
    Math.min(
      instStems.durationSec - barSec,
      instFirstDownbeatSec + config.instStartBar * barSec
    )
  );
  const instStartSample = Math.max(0, Math.round(instStartSec * sr));

  const effectiveVocalBpm =
    config.halfDoubleTime === '0.5x'
      ? config.vocalBpm * 0.5
      : config.halfDoubleTime === '2x'
        ? config.vocalBpm * 2
        : config.vocalBpm;

  const timeStretchRatio = config.autoBeatmatch
    ? Math.max(0.55, Math.min(1.85, effectiveVocalBpm / targetBpm))
    : 1.0;

  // Compute Deck B cue position in the active beatmatched bar/beat grid + beat phase shift
  const vocalSourceBeatSec = 60 / Math.max(50, effectiveVocalBpm);
  const vocalSourceBarSec = vocalSourceBeatSec * 4;
  const rawVocalCueSec =
    config.vocalFirstDownbeatSec +
    config.vocalCueBar * vocalSourceBarSec +
    config.vocalBeatShift * vocalSourceBeatSec;

  // If beat shift goes slightly < 0 before Bar 1, delay drop offset instead of clamping & shifting offbeat
  let vocalCueSec = rawVocalCueSec;
  let preClampDelaySec = 0;
  if (rawVocalCueSec < 0) {
    preClampDelaySec = -rawVocalCueSec * timeStretchRatio;
    vocalCueSec = 0;
  }

  const rawDropSec =
    config.vocalTargetDropBar * barSec + preClampDelaySec + config.vocalFineOffsetMs / 1000;
  let vocalDropSec = rawDropSec;
  if (rawDropSec < 0) {
    // Advance vocalCueSec forward rather than clamping vocalDropSec to 0 so negative pocket slips work on Bar 1
    vocalCueSec += (-rawDropSec) / timeStretchRatio;
    vocalDropSec = 0;
  }

  vocalCueSec = Math.min(
    Math.max(0, vocalsStems.durationSec - vocalSourceBeatSec),
    vocalCueSec
  );

  const vocalStartSample = Math.max(0, Math.round(vocalCueSec * vocalsStems.sampleRate));
  const vocalDropSample = Math.max(0, Math.round(vocalDropSec * sr));

  const warpCurve = config.autoBeatmatch
    ? buildBeatWarpCurve(
        instStems,
        instStartSec + vocalDropSec,
        targetBpm,
        vocalsStems,
        vocalCueSec,
        effectiveVocalBpm,
        sr,
        timeStretchRatio
      )
    : null;

  const stretchedVoc = getStretchedPitchShiftedVocals(
    vocalsStems,
    vocalStartSample,
    sr,
    timeStretchRatio,
    config.pitchSemitones,
    warpCurve
  );

  const polishedVoc = processVocalChain(
    stretchedVoc.L,
    stretchedVoc.R,
    sr,
    targetBpm,
    config.vocalTone,
    config.vocalSpaceAmount
  );

  const instAvailSamples = Math.max(1, instStems.length - instStartSample);
  const minBarsSamples = Math.round(8 * exactBarSamples);
  const rawTotalSamples = Math.min(instAvailSamples, Math.max(minBarsSamples, instAvailSamples));

  // If Phrase Lock is enabled, snap total output duration cleanly to full bar boundary
  const alignedBarCount = Math.max(4, Math.floor(rawTotalSamples / exactBarSamples));
  const totalSamples = config.phraseLockEnabled
    ? Math.min(instAvailSamples, Math.round(alignedBarCount * exactBarSamples))
    : rawTotalSamples;

  const outL = new Float32Array(totalSamples);
  const outR = new Float32Array(totalSamples);
  const instOutL = new Float32Array(totalSamples);
  const instOutR = new Float32Array(totalSamples);
  const vocOutL = new Float32Array(totalSamples);
  const vocOutR = new Float32Array(totalSamples);

  const vocAtt = Math.exp(-1 / Math.max(1, 0.015 * sr));
  const vocRel = Math.exp(-1 / Math.max(1, 0.18 * sr));
  let vocEnv = 0;

  const fadeInSamples = Math.round(0.014 * sr);
  const fadeOutSamples = config.phraseLockEnabled ? Math.round(0.18 * sr) : Math.round(0.06 * sr);
  const vocFadeInSamples = Math.round(0.014 * sr);
  const vocEndFadeSamples = Math.round(0.08 * sr);

  // When Phrase Lock is active, finish vocals gracefully at the end of the final completed 4-bar or 1-bar phrase before track end
  const maxVocLenSamples = Math.min(
    polishedVoc.L.length,
    Math.max(0, totalSamples - vocalDropSample)
  );
  const phraseEndVocLen = config.phraseLockEnabled && maxVocLenSamples > exactBarSamples * 2
    ? Math.min(
        maxVocLenSamples,
        Math.floor(maxVocLenSamples / Math.round(exactBarSamples)) * Math.round(exactBarSamples)
      )
    : maxVocLenSamples;

  let peakLinear = 0;
  let clippedSamples = 0;

  for (let i = 0; i < totalSamples; i++) {
    const srcIdx = instStartSample + i;
    const drumsL = srcIdx < instStems.length ? instStems.drumsL[srcIdx] : 0;
    const drumsR = srcIdx < instStems.length ? instStems.drumsR[srcIdx] : 0;
    const bassL = srcIdx < instStems.length ? instStems.bassL[srcIdx] : 0;
    const bassR = srcIdx < instStems.length ? instStems.bassR[srcIdx] : 0;
    const otherL = srcIdx < instStems.length ? instStems.otherL[srcIdx] : 0;
    const otherR = srcIdx < instStems.length ? instStems.otherR[srcIdx] : 0;

    let vL = 0;
    let vR = 0;
    if (i >= vocalDropSample) {
      const vIdx = i - vocalDropSample;
      if (vIdx < phraseEndVocLen) {
        let vEnv = 1.0;
        if (vIdx < vocFadeInSamples) {
          vEnv = Math.sin((vIdx / vocFadeInSamples) * Math.PI * 0.5);
        } else if (vIdx > phraseEndVocLen - vocEndFadeSamples) {
          vEnv = Math.max(
            0,
            Math.sin(((phraseEndVocLen - vIdx) / vocEndFadeSamples) * Math.PI * 0.5)
          );
        }
        vL = polishedVoc.L[vIdx] * config.vocalLevel * vEnv;
        vR = polishedVoc.R[vIdx] * config.vocalLevel * vEnv;
      }
    }

    const vMag = Math.max(Math.abs(vL), Math.abs(vR));
    vocEnv =
      vocEnv * (vMag > vocEnv ? vocAtt : vocRel) + vMag * (1 - (vMag > vocEnv ? vocAtt : vocRel));

    const duckDepth = Math.min(0.45, Math.min(1, vocEnv * 4.5) * 0.42 * config.pocketCarveAmount);
    const otherPocketGain = 1 - duckDepth;

    let iL =
      (drumsL * config.instDrumsLevel +
        bassL * config.instBassLevel +
        otherL * config.instOtherLevel * otherPocketGain) *
      config.instBedLevel;
    let iR =
      (drumsR * config.instDrumsLevel +
        bassR * config.instBassLevel +
        otherR * config.instOtherLevel * otherPocketGain) *
      config.instBedLevel;

    let masterFade = 1.0;
    if (i < fadeInSamples) masterFade = Math.sin((i / fadeInSamples) * Math.PI * 0.5);
    else if (i > totalSamples - fadeOutSamples) {
      masterFade = Math.max(0, (totalSamples - i) / fadeOutSamples);
    }

    iL *= masterFade;
    iR *= masterFade;
    vL *= masterFade;
    vR *= masterFade;

    let mL = iL + vL;
    let mR = iR + vR;

    const ceil = 0.933;
    if (Math.abs(mL) > ceil) {
      mL = Math.sign(mL) * (ceil + 0.055 * Math.tanh((Math.abs(mL) - ceil) * 6));
    }
    if (Math.abs(mR) > ceil) {
      mR = Math.sign(mR) * (ceil + 0.055 * Math.tanh((Math.abs(mR) - ceil) * 6));
    }
    if (Math.abs(mL) >= 0.999) {
      mL = Math.sign(mL) * 0.995;
      clippedSamples++;
    }
    if (Math.abs(mR) >= 0.999) {
      mR = Math.sign(mR) * 0.995;
      clippedSamples++;
    }

    const absMax = Math.max(Math.abs(mL), Math.abs(mR));
    if (absMax > peakLinear) peakLinear = absMax;

    outL[i] = mL;
    outR[i] = mR;
    instOutL[i] = iL;
    instOutR[i] = iR;
    vocOutL[i] = vL;
    vocOutR[i] = vR;
  }

  const buffer = new AudioBuffer({ numberOfChannels: 2, length: totalSamples, sampleRate: sr });
  buffer.getChannelData(0).set(outL);
  buffer.getChannelData(1).set(outR);

  const alignedVocalsBuffer = new AudioBuffer({
    numberOfChannels: 2,
    length: totalSamples,
    sampleRate: sr,
  });
  alignedVocalsBuffer.getChannelData(0).set(vocOutL);
  alignedVocalsBuffer.getChannelData(1).set(vocOutR);

  const instBedBuffer = new AudioBuffer({
    numberOfChannels: 2,
    length: totalSamples,
    sampleRate: sr,
  });
  instBedBuffer.getChannelData(0).set(instOutL);
  instBedBuffer.getChannelData(1).set(instOutR);

  const outputPeakDbfs = peakLinear > 1e-6 ? 20 * Math.log10(peakLinear) : -96;
  const syncMetrics = computeBeatSyncTightness(
    instStems,
    instStartSample,
    vocalsStems,
    vocalCueSec,
    vocalDropSample,
    totalSamples,
    sr,
    beatSec,
    timeStretchRatio,
    config.vocalFineOffsetMs,
    warpCurve
  );

  return {
    buffer,
    alignedVocalsBuffer,
    instBedBuffer,
    mixPeaks: computePeaks(outL, outR),
    instPeaks: computePeaks(instOutL, instOutR),
    vocalPeaks: computePeaks(vocOutL, vocOutR),
    totalDurationSec: totalSamples / sr,
    targetBpm,
    effectiveVocalBpm,
    barSec,
    beatSec,
    timeStretchRatio,
    vocalCueSec,
    vocalDropSec,
    beatSyncTightnessPct: syncMetrics.beatSyncTightnessPct,
    avgBeatErrorMs: syncMetrics.avgBeatErrorMs,
    beatWarpActive: Boolean(warpCurve),
    outputPeakDbfs,
    clippedSamples,
    passed: clippedSamples === 0 && peakLinear > 0.01,
  };
}
