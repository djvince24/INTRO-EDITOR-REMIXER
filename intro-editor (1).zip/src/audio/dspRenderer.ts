import {
  DemucsStemSet,
  IntroEditConfig,
  RenderedIntroEdit,
  RenderQualityControl,
  StemCutRegion,
  StemName,
  TrackAnalysis,
} from '../types/audio';

const STEM_NAMES: StemName[] = ['drums', 'bass', 'other', 'vocals'];

function computePeaks(left: Float32Array, right: Float32Array, bins = 900): Float32Array {
  const peaks = new Float32Array(bins);
  const len = left.length;
  for (let b = 0; b < bins; b++) {
    const start = Math.floor((b / bins) * len);
    const end = Math.min(len, Math.floor(((b + 1) / bins) * len));
    let p = 0;
    const stride = Math.max(1, Math.floor((end - start) / 256));
    for (let i = start; i < end; i += stride) {
      const m = Math.max(Math.abs(left[i]), Math.abs(right[i]));
      if (m > p) p = m;
    }
    peaks[b] = p;
  }
  return peaks;
}

interface BiquadState {
  b0: number;
  b1: number;
  b2: number;
  a1: number;
  a2: number;
  x1: number;
  x2: number;
  y1: number;
  y2: number;
}

function createLowpass(sr: number, hz: number, q = 0.7071): BiquadState {
  const w0 = (2 * Math.PI * hz) / sr;
  const alpha = Math.sin(w0) / (2 * q);
  const cosW0 = Math.cos(w0);
  const a0 = 1 + alpha;
  const b1 = 1 - cosW0;
  const b0 = b1 / 2;
  return {
    b0: b0 / a0,
    b1: b1 / a0,
    b2: b0 / a0,
    a1: (-2 * cosW0) / a0,
    a2: (1 - alpha) / a0,
    x1: 0,
    x2: 0,
    y1: 0,
    y2: 0,
  };
}

function createHighpass(sr: number, hz: number, q = 0.7071): BiquadState {
  const w0 = (2 * Math.PI * hz) / sr;
  const alpha = Math.sin(w0) / (2 * q);
  const cosW0 = Math.cos(w0);
  const a0 = 1 + alpha;
  const b1 = -(1 + cosW0);
  const b0 = (1 + cosW0) / 2;
  return {
    b0: b0 / a0,
    b1: b1 / a0,
    b2: b0 / a0,
    a1: (-2 * cosW0) / a0,
    a2: (1 - alpha) / a0,
    x1: 0,
    x2: 0,
    y1: 0,
    y2: 0,
  };
}

function stepBiquad(s: BiquadState, x0: number): number {
  const y0 = s.b0 * x0 + s.b1 * s.x1 + s.b2 * s.x2 - s.a1 * s.y1 - s.a2 * s.y2;
  s.x2 = s.x1;
  s.x1 = x0;
  s.y2 = s.y1;
  s.y1 = y0;
  return y0;
}

function getEffectiveStemGains(config: IntroEditConfig): Record<StemName, number> {
  const anySolo = STEM_NAMES.some((s) => config.stems[s].solo);
  const gains = {} as Record<StemName, number>;
  for (const s of STEM_NAMES) {
    const st = config.stems[s];
    const active = anySolo ? st.solo : !st.mute;
    gains[s] = active ? st.volume : 0;
  }
  return gains;
}

/**
 * Computes sample-level cut envelope [0..1] for a given stem across [0, totalSamples),
 * applying smooth 8 ms raised-cosine edges so stem cuts never produce clicks.
 */
function buildCutEnvelope(
  cuts: StemCutRegion[],
  stem: StemName,
  totalSamples: number,
  sr: number
): Float32Array | null {
  const relevant = cuts.filter((c) => c.stem === stem && c.endSec > c.startSec);
  if (relevant.length === 0) return null;

  const env = new Float32Array(totalSamples);
  env.fill(1);
  const edgeSamples = Math.max(1, Math.round(0.008 * sr));

  for (const cut of relevant) {
    const s0 = Math.max(0, Math.floor(cut.startSec * sr));
    const s1 = Math.min(totalSamples, Math.ceil(cut.endSec * sr));
    if (s1 <= s0) continue;

    for (let i = s0; i < s1; i++) {
      env[i] = 0;
    }

    const fadeOutStart = Math.max(0, s0 - edgeSamples);
    for (let i = fadeOutStart; i < s0; i++) {
      const t = (i - fadeOutStart) / Math.max(1, s0 - fadeOutStart);
      env[i] = Math.min(env[i], Math.cos(t * Math.PI * 0.5));
    }

    const fadeInEnd = Math.min(totalSamples, s1 + edgeSamples);
    for (let i = s1; i < fadeInEnd; i++) {
      const t = (i - s1) / Math.max(1, fadeInEnd - s1);
      env[i] = Math.min(env[i], Math.sin(t * Math.PI * 0.5));
    }
  }
  return env;
}

function getStemChannels(
  stemSet: DemucsStemSet,
  stem: StemName
): { L: Float32Array; R: Float32Array } {
  switch (stem) {
    case 'drums':
      return { L: stemSet.drumsL, R: stemSet.drumsR };
    case 'bass':
      return { L: stemSet.bassL, R: stemSet.bassR };
    case 'other':
      return { L: stemSet.otherL, R: stemSet.otherR };
    case 'vocals':
      return { L: stemSet.vocalsL, R: stemSet.vocalsR };
  }
}

/**
 * Computes the beat-synchronized DJ intro stem automation gain at sample `introSampleIdx`.
 */
function getIntroStemAutomationGain(
  stem: StemName,
  introSampleIdx: number,
  introSamples: number,
  barSamples: number,
  beatSamples: number,
  config: IntroEditConfig
): number {
  const st = config.stems[stem];
  const barPos = introSampleIdx / Math.max(1, barSamples);

  if (config.introArrangement === 'full-instrumental') {
    if (stem === 'vocals') {
      return st.introLevel > 0 ? st.introLevel : 0;
    }
    return 1.0;
  }

  if (config.introArrangement === 'custom-automation') {
    const entrySample = Math.max(0, Math.min(introSamples - 1, st.introEntryBar * barSamples));
    const rampLen = config.phraseAwareTransition ? beatSamples * 2 : Math.round(beatSamples);
    let gate = 1;
    if (introSampleIdx < entrySample) {
      gate = 0;
    } else if (introSampleIdx < entrySample + rampLen) {
      const t = (introSampleIdx - entrySample) / Math.max(1, rampLen);
      gate = Math.sin(t * Math.PI * 0.5);
    }
    return gate * st.introLevel;
  }

  // 'progressive-build': classic DJ production stem build
  // - Bars 1-2 (0..2): Drums lead the groove
  // - Bars 3-4 (2..4): Bass enters smoothly on Bar 3 downbeat
  // - Bars 5-8 (4..8): Melodies & instruments (Other) swell in cleanly
  // - Vocals: held out of intro unless user explicitly raised vocals introLevel > 0
  if (stem === 'drums') {
    return 1.0;
  }

  if (stem === 'bass') {
    const entryBar = 2; // Bar 3
    if (barPos < entryBar) return 0;
    const fadeLenBars = config.phraseAwareTransition ? 0.5 : 0.25;
    if (barPos < entryBar + fadeLenBars) {
      const t = (barPos - entryBar) / fadeLenBars;
      return Math.sin(t * Math.PI * 0.5);
    }
    return 1.0;
  }

  if (stem === 'other') {
    const entryBar = 4; // Bar 5
    if (barPos < entryBar) return 0.12; // subtle atmospheric tease before Bar 5
    const rampBars = 2.0;
    if (barPos < entryBar + rampBars) {
      const t = (barPos - entryBar) / rampBars;
      return 0.12 + 0.88 * Math.sin(t * Math.PI * 0.5);
    }
    return 1.0;
  }

  // vocals: excluded during intro so Bar 9 Cue 1 vocal drop hits cleanly
  return 0;
}

/**
 * Renders both:
 * 1) `buffer`: The 8-bar Demucs stem-built DJ Intro Edit -> Cue 1 Verse + full track
 * 2) `stemMixBuffer`: Full-length 4-stem interactive mix (with user Mute/Solo/Volume/Fades/Cuts)
 */
export function renderDjIntroEdit(
  sourceBuffer: AudioBuffer,
  _analysis: TrackAnalysis,
  config: IntroEditConfig,
  stemSet?: DemucsStemSet | null
): RenderedIntroEdit {
  const sr = sourceBuffer.sampleRate;
  const srcL = sourceBuffer.getChannelData(0);
  const srcR =
    sourceBuffer.numberOfChannels > 1 ? sourceBuffer.getChannelData(1) : srcL;

  const beatSec = 60 / config.bpm;
  const barSec = beatSec * 4;
  const exactBeatSamples = beatSec * sr;
  const exactBarSamples = barSec * sr;
  const barSamples = Math.round(exactBarSamples);
  const beatSamples = Math.round(exactBeatSamples);
  const introBars = 8;
  const introSamples = Math.round(introBars * exactBarSamples);

  const downbeatSample = config.firstDownbeatSec * sr;
  const rawCue1Sample =
    config.cue1ExactSec != null
      ? Math.round(config.cue1ExactSec * sr)
      : Math.round(downbeatSample + config.cue1Bar * exactBarSamples);

  // Preserve beat-grid phase continuity at the Bar 8 -> Cue 1 transition:
  // If Cue 1 was placed slightly before a grid beat (vocal pickup / anacrusis),
  // keep the drum/bass transition locked on the grid beat and pre-roll the vocal stem
  // cleanly over the final beat of Bar 8.
  let cue1BeatAnchor = rawCue1Sample;
  let vocalPickupSamples = 0;
  if (config.cue1ExactSec != null && config.phraseAwareTransition) {
    const beatsFromDownbeat = (rawCue1Sample - downbeatSample) / exactBeatSamples;
    const nearestBeatIdx = Math.round(beatsFromDownbeat);
    const nearestBeatSample = Math.round(downbeatSample + nearestBeatIdx * exactBeatSamples);
    const deltaSamples = nearestBeatSample - rawCue1Sample; // positive if rawCue1 is before the beat
    if (
      deltaSamples > 0 &&
      deltaSamples <= Math.round(0.45 * exactBeatSamples) &&
      rawCue1Sample >= Math.round(0.02 * sr)
    ) {
      cue1BeatAnchor = nearestBeatSample;
      vocalPickupSamples = deltaSamples;
    }
  }

  const cue1StartSample = Math.min(
    Math.max(0, srcL.length - barSamples),
    Math.max(0, cue1BeatAnchor)
  );

  const phraseBars = config.loopStructure === '4-bar-x2' ? 4 : 8;
  const rawPhraseSamples = Math.round(phraseBars * exactBarSamples);
  const tailOverlapSamples =
    config.transitionBlend === 'bar-overlap'
      ? barSamples
      : config.transitionBlend === 'beat-blend'
        ? beatSamples
        : Math.round(0.03 * sr);

  const rawDonorSample =
    config.donorStartExactSec != null
      ? Math.round(config.donorStartExactSec * sr)
      : Math.round(downbeatSample + config.donorStartBar * exactBarSamples);
  const donorStartSample = Math.min(
    Math.max(0, srcL.length - barSamples * 4),
    Math.max(0, rawDonorSample)
  );

  const hasDemucs =
    Boolean(stemSet) &&
    stemSet!.sampleRate === sr &&
    stemSet!.length === srcL.length;

  const gains = getEffectiveStemGains(config);

  // Build cut envelopes & per-stem fade envelopes over the full original track timeline
  const trackLen = srcL.length;
  const fullStemMixL = new Float32Array(trackLen);
  const fullStemMixR = new Float32Array(trackLen);

  const cutEnvs = {} as Record<StemName, Float32Array | null>;
  for (const s of STEM_NAMES) {
    cutEnvs[s] = buildCutEnvelope(config.cuts, s, trackLen, sr);
  }

  const fadeFactorAt = (stem: StemName, idx: number, len: number): number => {
    const st = config.stems[stem];
    let f = 1;
    const fiSamples = Math.round(st.fadeInSec * sr);
    const foSamples = Math.round(st.fadeOutSec * sr);
    if (fiSamples > 0 && idx < fiSamples) {
      f *= Math.sin((idx / fiSamples) * Math.PI * 0.5);
    }
    if (foSamples > 0 && idx >= len - foSamples) {
      const rem = Math.max(0, len - 1 - idx);
      f *= Math.sin((rem / foSamples) * Math.PI * 0.5);
    }
    return f;
  };

  if (hasDemucs && stemSet) {
    for (const s of STEM_NAMES) {
      const g = gains[s];
      if (g <= 0) continue;
      const ch = getStemChannels(stemSet, s);
      const cutEnv = cutEnvs[s];
      const fiSamples = Math.round(config.stems[s].fadeInSec * sr);
      const foSamples = Math.round(config.stems[s].fadeOutSec * sr);

      for (let i = 0; i < trackLen; i++) {
        let env = g;
        if (cutEnv) env *= cutEnv[i];
        if (fiSamples > 0 && i < fiSamples) {
          env *= Math.sin((i / fiSamples) * Math.PI * 0.5);
        }
        if (foSamples > 0 && i >= trackLen - foSamples) {
          const rem = Math.max(0, trackLen - 1 - i);
          env *= Math.sin((rem / foSamples) * Math.PI * 0.5);
        }
        fullStemMixL[i] += ch.L[i] * env;
        fullStemMixR[i] += ch.R[i] * env;
      }
    }
  } else {
    fullStemMixL.set(srcL);
    fullStemMixR.set(srcR);
  }

  // Construct 8-bar DJ Intro (+ overlap tail for smooth transition into Cue 1)
  const introTotalWithTail = introSamples + tailOverlapSamples;
  const introL = new Float32Array(introTotalWithTail);
  const introR = new Float32Array(introTotalWithTail);
  const introBassL = new Float32Array(introTotalWithTail);
  const introBassR = new Float32Array(introTotalWithTail);
  const introDrumsL = new Float32Array(introTotalWithTail);
  const introDrumsR = new Float32Array(introTotalWithTail);
  const introOtherTailL = new Float32Array(introTotalWithTail);
  const introOtherTailR = new Float32Array(introTotalWithTail);
  const halfPhraseSamples = Math.round(4 * exactBarSamples);
  const loopCrossfadeSamples = Math.min(Math.round(0.018 * sr), Math.floor(barSamples * 0.05));

  const lpKickL = createLowpass(sr, 130);
  const lpKickR = createLowpass(sr, 130);

  if (hasDemucs && stemSet) {
    // Sample synchronized donor bars across all 4 Demucs stems with exact zero drift
    const sampleDonorStemAt = (
      stem: StemName,
      phraseSampleOffset: number
    ): [number, number] => {
      const ch = getStemChannels(stemSet, stem);
      const cutEnv = cutEnvs[stem];
      const srcIdx = Math.min(trackLen - 1, Math.max(0, donorStartSample + phraseSampleOffset));
      const cutMul = cutEnv ? cutEnv[srcIdx] : 1;
      return [ch.L[srcIdx] * cutMul, ch.R[srcIdx] * cutMul];
    };

    const readDonorPos = (outPos: number): number => {
      if (config.loopStructure === '4-bar-x2') {
        return outPos % Math.max(1, halfPhraseSamples);
      }
      return outPos % Math.max(1, rawPhraseSamples);
    };

    const bassSwapLen = config.transitionBlend === 'bar-overlap' ? beatSamples * 2 : beatSamples;
    const bassSwapStart = Math.max(0, introSamples - bassSwapLen);

    for (let i = 0; i < introTotalWithTail; i++) {
      const pIdx = readDonorPos(i);

      // Smooth equal-power loop seam at Bar 5 when using 4-bar x 2 structure
      let useCrossfade = false;
      let fadeIn = 1;
      let fadeOut = 0;
      let prevPIdx = 0;
      if (
        config.loopStructure === '4-bar-x2' &&
        i >= halfPhraseSamples &&
        i < halfPhraseSamples + loopCrossfadeSamples
      ) {
        const t = (i - halfPhraseSamples) / Math.max(1, loopCrossfadeSamples);
        fadeIn = config.phaseAwareMixing ? Math.sin(t * Math.PI * 0.5) : t;
        fadeOut = config.phaseAwareMixing ? Math.cos(t * Math.PI * 0.5) : 1 - t;
        prevPIdx = halfPhraseSamples + (i - halfPhraseSamples);
        useCrossfade = true;
      }

      // Per-stem intro automation + user Mute/Solo/Volume
      let sumL = 0;
      let sumR = 0;

      for (const s of STEM_NAMES) {
        const userGain = gains[s];
        if (userGain <= 0) continue;

        const autoGain = getIntroStemAutomationGain(
          s,
          Math.min(i, introSamples - 1),
          introSamples,
          barSamples,
          beatSamples,
          config
        );
        const totalG = userGain * autoGain;
        if (totalG <= 0.0001) continue;

        let [sL, sR] = sampleDonorStemAt(s, pIdx);
        if (useCrossfade) {
          const [pL, pR] = sampleDonorStemAt(s, prevPIdx);
          sL = pL * fadeOut + sL * fadeIn;
          sR = pR * fadeOut + sR * fadeIn;
        }

        sL *= totalG;
        sR *= totalG;

        if (s === 'bass') {
          introBassL[i] = sL;
          introBassR[i] = sR;
        } else if (s === 'drums') {
          introDrumsL[i] = sL;
          introDrumsR[i] = sR;
          if (config.kickPreservationEnabled && config.drumPunchBoost > 0.01) {
            const subL = stepBiquad(lpKickL, sL);
            const subR = stepBiquad(lpKickR, sR);
            sL += subL * config.drumPunchBoost * 0.16;
            sR += subR * config.drumPunchBoost * 0.16;
          }
        } else if (s === 'other') {
          introOtherTailL[i] = sL;
          introOtherTailR[i] = sR;
        }

        sumL += sL;
        sumR += sR;
      }

      // Clean Beat-Synchronized Bass Swap: completes smoothly BEFORE Bar 9 Beat 1 so
      // incoming Cue 1 Kick + Bass slams in phase-pure with zero low-end mud
      if (config.bassSwapEnabled && i >= bassSwapStart) {
        const t = Math.min(1, Math.max(0, (i - bassSwapStart) / Math.max(1, bassSwapLen)));
        const bassHold = Math.cos(t * Math.PI * 0.5);
        sumL -= introBassL[i] * (1 - bassHold);
        sumR -= introBassR[i] * (1 - bassHold);
      }

      introL[i] = sumL;
      introR[i] = sumR;
    }
  } else {
    // Before Demucs finishes separating: preview unmodified source donor slice without fake EQ/STFT
    for (let i = 0; i < introTotalWithTail; i++) {
      const pIdx =
        config.loopStructure === '4-bar-x2'
          ? i % Math.max(1, halfPhraseSamples)
          : i % Math.max(1, rawPhraseSamples);
      const idx = Math.min(trackLen - 1, donorStartSample + pIdx);
      introL[i] = srcL[idx];
      introR[i] = srcR[idx];
      introOtherTailL[i] = srcL[idx];
      introOtherTailR[i] = srcR[idx];
    }
  }

  // Click-free 12ms intro start
  const startClickFade = Math.min(Math.round(0.012 * sr), barSamples);
  for (let i = 0; i < startClickFade; i++) {
    const g = Math.sin((i / startClickFade) * Math.PI * 0.5);
    introL[i] *= g;
    introR[i] *= g;
  }

  // Bar 7-8 Groove Energy Lift + subtle pre-drop filter sweep on last 2 beats
  // (carves tension while preserving kick punch before releasing full weight at Cue 1)
  if (config.grooveLiftAmount > 0.01) {
    const liftStart = Math.round(6 * exactBarSamples);
    const liftLen = Math.max(1, introSamples - liftStart);
    const hpTeaseL = createHighpass(sr, 125);
    const hpTeaseR = createHighpass(sr, 125);
    const preDropLen = config.phraseAwareTransition ? beatSamples * 2 : beatSamples;
    const lastBeatsStart = Math.max(liftStart, introSamples - preDropLen);
    for (let i = liftStart; i < introSamples; i++) {
      const progress = (i - liftStart) / liftLen;
      const gainPush = 1 + progress * 0.07 * config.grooveLiftAmount;
      const hpL = stepBiquad(hpTeaseL, introL[i]);
      const hpR = stepBiquad(hpTeaseR, introR[i]);
      if (i >= lastBeatsStart) {
        const beatProg = (i - lastBeatsStart) / Math.max(1, preDropLen);
        const wet = Math.sin(beatProg * Math.PI * 0.5) * 0.3 * config.grooveLiftAmount;
        // Keep kick punch intact when kickPreservationEnabled
        const kickPreserveL = config.kickPreservationEnabled ? introDrumsL[i] * wet * 0.65 : 0;
        const kickPreserveR = config.kickPreservationEnabled ? introDrumsR[i] * wet * 0.65 : 0;
        introL[i] = (introL[i] * (1 - wet) + hpL * wet) * gainPush + kickPreserveL;
        introR[i] = (introR[i] * (1 - wet) + hpR * wet) * gainPush + kickPreserveR;
      } else {
        introL[i] *= gainPush;
        introR[i] *= gainPush;
      }
    }
  }

  const anySolo = STEM_NAMES.some((s) => config.stems[s].solo);
  const vocalsMuted = anySolo ? !config.stems.vocals.solo : config.stems.vocals.mute;

  // RMS Continuity Leveling across Bars 5-8 toward upcoming Cue 1 instrumental energy
  // so Bar 8.4 -> Bar 9.1 flows smoothly with zero abrupt drop or surge
  const measureSpan = Math.min(barSamples * 2, introSamples, trackLen - cue1StartSample);
  if (measureSpan > 256) {
    let introTailSq = 0;
    let cueHeadSq = 0;
    const stride = Math.max(1, Math.floor(measureSpan / 4096));
    let mCount = 0;
    for (let k = 0; k < measureSpan; k += stride) {
      const iIdx = introSamples - measureSpan + k;
      const cIdx = cue1StartSample + k;
      introTailSq += introL[iIdx] * introL[iIdx] + introR[iIdx] * introR[iIdx];
      if (hasDemucs && stemSet) {
        const instCL =
          stemSet.drumsL[cIdx] * gains.drums +
          stemSet.bassL[cIdx] * gains.bass +
          stemSet.otherL[cIdx] * gains.other +
          (vocalsMuted ? 0 : stemSet.vocalsL[cIdx] * gains.vocals * 0.45);
        const instCR =
          stemSet.drumsR[cIdx] * gains.drums +
          stemSet.bassR[cIdx] * gains.bass +
          stemSet.otherR[cIdx] * gains.other +
          (vocalsMuted ? 0 : stemSet.vocalsR[cIdx] * gains.vocals * 0.45);
        cueHeadSq += instCL * instCL + instCR * instCR;
      } else {
        cueHeadSq += fullStemMixL[cIdx] * fullStemMixL[cIdx] + fullStemMixR[cIdx] * fullStemMixR[cIdx];
      }
      mCount++;
    }
    const rmsIntro = Math.sqrt(introTailSq / Math.max(1, mCount * 2));
    const rmsCue = Math.sqrt(cueHeadSq / Math.max(1, mCount * 2));
    if (rmsIntro > 0.008 && rmsCue > 0.008) {
      const targetTrim = Math.max(0.8, Math.min(1.45, rmsCue / rmsIntro));
      const rampStart = halfPhraseSamples;
      const rampSpan = Math.max(1, introSamples - rampStart);
      for (let i = rampStart; i < introSamples; i++) {
        const t = (i - rampStart) / rampSpan;
        const smoothG = 1 + (targetTrim - 1) * (0.5 - 0.5 * Math.cos(Math.PI * t));
        introL[i] *= smoothG;
        introR[i] *= smoothG;
      }
    }
  }

  const postCueSamples = Math.max(barSamples, trackLen - cue1StartSample);
  const totalSamples = introSamples + postCueSamples;
  const outL = new Float32Array(totalSamples);
  const outR = new Float32Array(totalSamples);

  outL.set(introL.subarray(0, introSamples), 0);
  outR.set(introR.subarray(0, introSamples), 0);

  // Seamless pre-roll of Cue 1 vocal pickup / anacrusis across final fraction of Bar 8
  if (hasDemucs && stemSet && !vocalsMuted && vocalPickupSamples > 64) {
    const pickupFadeSamples = Math.min(Math.round(0.015 * sr), Math.floor(vocalPickupSamples * 0.5));
    for (let k = 0; k < vocalPickupSamples; k++) {
      const sIdx = cue1StartSample - vocalPickupSamples + k;
      const outIdx = introSamples - vocalPickupSamples + k;
      if (sIdx >= 0 && sIdx < trackLen && outIdx >= 0 && outIdx < introSamples) {
        const env = k < pickupFadeSamples ? Math.sin((k / pickupFadeSamples) * Math.PI * 0.5) : 1;
        const vGain = gains.vocals * (cutEnvs.vocals ? cutEnvs.vocals[sIdx] : 1) * env;
        outL[outIdx] += stemSet.vocalsL[sIdx] * vGain;
        outR[outIdx] += stemSet.vocalsR[sIdx] * vGain;
      }
    }
  }

  // Micro 4ms anti-click taper at end of intro drums/mix before Bar 9 Beat 1
  const endMicro = Math.min(Math.round(0.004 * sr), introSamples);
  for (let k = 0; k < endMicro; k++) {
    const g = Math.cos(((k + 1) / endMicro) * Math.PI * 0.5);
    const idx = introSamples - endMicro + k;
    outL[idx] *= 0.35 + 0.65 * g;
    outR[idx] *= 0.35 + 0.65 * g;
  }

  const cueBassLockSamples = Math.min(Math.round(0.022 * sr), postCueSamples);

  for (let i = 0; i < postCueSamples; i++) {
    const sIdx = cue1StartSample + i;
    if (sIdx < trackLen) {
      let l = fullStemMixL[sIdx];
      let r = fullStemMixR[sIdx];

      // Crisp 22ms phase-locked bass entry at Bar 9 Beat 1 so kick + bass lock smoothly
      if (hasDemucs && stemSet && config.bassSwapEnabled && i < cueBassLockSamples) {
        const t = i / Math.max(1, cueBassLockSamples);
        const bassInGain = Math.sin(t * Math.PI * 0.5);
        const bCut = cutEnvs.bass ? cutEnvs.bass[sIdx] : 1;
        const bGain = gains.bass * bCut * fadeFactorAt('bass', sIdx, trackLen);
        l -= stemSet.bassL[sIdx] * bGain * (1 - bassInGain);
        r -= stemSet.bassR[sIdx] * bGain * (1 - bassInGain);
      }

      // Smooth 18ms vocal entry at Bar 9 Cue 1 so vocals land naturally on the downbeat
      if (hasDemucs && stemSet && !vocalsMuted && i < Math.round(0.018 * sr)) {
        const t = i / Math.round(0.018 * sr);
        const vGain = gains.vocals * (cutEnvs.vocals ? cutEnvs.vocals[sIdx] : 1);
        const vFade = Math.sin(t * Math.PI * 0.5);
        l -= stemSet.vocalsL[sIdx] * vGain * (1 - vFade);
        r -= stemSet.vocalsR[sIdx] * vGain * (1 - vFade);
      }

      outL[introSamples + i] = l;
      outR[introSamples + i] = r;
    }
  }

  // Stem-pure atmospheric glide tail (uses ONLY high-passed `other` shimmer when Demucs stems
  // are loaded so donor drums & Cue 1 drums NEVER collide or double-kick!)
  const tailHpL = createHighpass(sr, hasDemucs ? 280 : config.bassSwapEnabled ? 240 : 140);
  const tailHpR = createHighpass(sr, hasDemucs ? 280 : config.bassSwapEnabled ? 240 : 140);
  const actualBlend = Math.min(tailOverlapSamples, postCueSamples);

  const warmStart = Math.max(0, introSamples - Math.round(0.05 * sr));
  for (let i = warmStart; i < introSamples; i++) {
    stepBiquad(tailHpL, introOtherTailL[i]);
    stepBiquad(tailHpR, introOtherTailR[i]);
  }

  const microSamples = Math.min(Math.round(0.004 * sr), actualBlend);
  const tailWeight =
    config.transitionBlend === 'tight-cut'
      ? 0.25
      : config.transitionBlend === 'bar-overlap'
        ? 0.68
        : 0.55;
  for (let i = 0; i < actualBlend; i++) {
    const outIdx = introSamples + i;
    const t = i / Math.max(1, actualBlend);
    const tailDecay = config.phaseAwareMixing ? Math.cos(t * Math.PI * 0.5) : 1 - t;
    const tailValL = stepBiquad(tailHpL, introOtherTailL[introSamples + i]);
    const tailValR = stepBiquad(tailHpR, introOtherTailR[introSamples + i]);
    const cueInGain = i < microSamples ? Math.sin((i / microSamples) * Math.PI * 0.5) : 1;

    outL[outIdx] = outL[outIdx] * cueInGain + tailValL * tailDecay * tailWeight;
    outR[outIdx] = outR[outIdx] * cueInGain + tailValR * tailDecay * tailWeight;
  }

  // Loudness & True-Peak Soft Ceiling (-0.3 dBFS = 0.966) with sign-preserving saturation
  let postLimitClipped = 0;
  let outputPeakLinear = 0;
  const ceil = 0.935;
  for (let i = 0; i < totalSamples; i++) {
    let l = outL[i];
    let r = outR[i];
    if (Math.abs(l) > ceil) {
      l = Math.sign(l) * (ceil + 0.055 * Math.tanh((Math.abs(l) - ceil) / 0.18));
    }
    if (Math.abs(r) > ceil) {
      r = Math.sign(r) * (ceil + 0.055 * Math.tanh((Math.abs(r) - ceil) / 0.18));
    }
    if (Math.abs(l) >= 0.999) {
      l = Math.sign(l) * 0.995;
      postLimitClipped++;
    }
    if (Math.abs(r) >= 0.999) {
      r = Math.sign(r) * 0.995;
      postLimitClipped++;
    }
    outL[i] = l;
    outR[i] = r;
    const p = Math.max(Math.abs(l), Math.abs(r));
    if (p > outputPeakLinear) outputPeakLinear = p;
  }

  // Also limit fullStemMix gently
  for (let i = 0; i < trackLen; i++) {
    const l = fullStemMixL[i];
    const r = fullStemMixR[i];
    if (Math.abs(l) > ceil) fullStemMixL[i] = Math.sign(l) * (ceil + 0.055 * Math.tanh((Math.abs(l) - ceil) / 0.18));
    if (Math.abs(r) > ceil) fullStemMixR[i] = Math.sign(r) * (ceil + 0.055 * Math.tanh((Math.abs(r) - ceil) / 0.18));
  }

  // Quality Control check across seam (last 2 beats of Bar 8 vs first 2 beats of Cue 1)
  const checkSpan = Math.min(beatSamples * 2, introSamples, postCueSamples);
  let preSeamEnergy = 0;
  let postSeamEnergy = 0;
  let seamDot = 0;
  let seamSqL = 0;
  let seamSqR = 0;
  for (let i = 0; i < checkSpan; i++) {
    const pIdx = introSamples - checkSpan + i;
    const nIdx = introSamples + i;
    preSeamEnergy += outL[pIdx] * outL[pIdx] + outR[pIdx] * outR[pIdx];
    postSeamEnergy += outL[nIdx] * outL[nIdx] + outR[nIdx] * outR[nIdx];
    seamDot += outL[nIdx] * outR[nIdx];
    seamSqL += outL[nIdx] * outL[nIdx];
    seamSqR += outR[nIdx] * outR[nIdx];
  }
  const preRms = Math.sqrt(preSeamEnergy / Math.max(1, checkSpan * 2));
  const postRms = Math.sqrt(postSeamEnergy / Math.max(1, checkSpan * 2));
  const seamPeakContinuity =
    Math.max(preRms, postRms) > 0.001
      ? Math.min(preRms, postRms) / Math.max(preRms, postRms)
      : 1;
  const seamDenom = Math.sqrt(seamSqL * seamSqR);
  const phaseCorrelationSeam = seamDenom > 1e-9 ? seamDot / seamDenom : 1;

  let introEnergy = 0;
  const introStride = Math.max(1, Math.floor(introSamples / 4096));
  let introCount = 0;
  for (let i = 0; i < introSamples; i += introStride) {
    introEnergy += outL[i] * outL[i] + outR[i] * outR[i];
    introCount++;
  }
  const introRms = Math.sqrt(introEnergy / Math.max(1, introCount * 2));
  const hasSilentIntro = introRms < 1e-5;
  const hasSilentCue1 = postRms < 1e-5;

  const issues: string[] = [];
  if (!hasDemucs) {
    issues.push('Demucs 4-stem separation has not completed for this track.');
  } else if (!stemSet!.qc.syncVerified) {
    issues.push(`Stem timing drift detected (${stemSet!.qc.maxDriftSamples} samples).`);
  }
  if (hasSilentIntro) {
    issues.push('Generated DJ intro audio is silent (check stem mutes or cuts).');
  }
  if (hasSilentCue1) {
    issues.push('Cue 1 verse section is silent.');
  }
  if (phaseCorrelationSeam < -0.35) {
    issues.push(`Negative stereo phase correlation at Cue 1 seam (${phaseCorrelationSeam.toFixed(2)}).`);
  }

  const qc: RenderQualityControl = {
    outputPeakLinear,
    outputPeakDbfs: outputPeakLinear > 1e-9 ? 20 * Math.log10(outputPeakLinear) : -120,
    clippedSamples: postLimitClipped,
    hasSilentIntro,
    hasSilentCue1,
    phaseCorrelationSeam,
    seamPeakContinuity,
    stemSyncVerified: hasDemucs ? stemSet!.qc.syncVerified : false,
    reconstructionSnrDb: hasDemucs ? stemSet!.qc.reconstructionSnrDb : null,
    passed: hasDemucs && !hasSilentIntro && !hasSilentCue1 && stemSet!.qc.passed && phaseCorrelationSeam >= -0.35,
    issues,
  };

  const outBuffer = new AudioBuffer({
    length: totalSamples,
    numberOfChannels: 2,
    sampleRate: sr,
  });
  outBuffer.copyToChannel(outL, 0);
  outBuffer.copyToChannel(outR, 1);

  const stemMixBuffer = new AudioBuffer({
    length: trackLen,
    numberOfChannels: 2,
    sampleRate: sr,
  });
  stemMixBuffer.copyToChannel(fullStemMixL, 0);
  stemMixBuffer.copyToChannel(fullStemMixR, 1);

  const peaks = computePeaks(outL, outR, 900);
  const stemMixPeaks = computePeaks(fullStemMixL, fullStemMixR, 900);
  const introDurationSec = introSamples / sr;

  return {
    buffer: outBuffer,
    peaks,
    stemMixBuffer,
    stemMixPeaks,
    introDurationSec,
    cue1OutputSec: introDurationSec,
    totalDurationSec: totalSamples / sr,
    barSec,
    beatSec,
    bpm: config.bpm,
    usingDemucsStems: hasDemucs,
    demucsModelUsed: hasDemucs ? stemSet!.modelUsed : null,
    seamPeakContinuity,
    qc,
  };
}

export function encodeAudioBufferToWav(buffer: AudioBuffer): Blob {
  const numChannels = Math.min(2, buffer.numberOfChannels);
  const sampleRate = buffer.sampleRate;
  const length = buffer.length;
  const bytesPerSample = 2;
  const blockAlign = numChannels * bytesPerSample;
  const dataSize = length * blockAlign;
  const arrayBuffer = new ArrayBuffer(44 + dataSize);
  const view = new DataView(arrayBuffer);

  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, dataSize, true);

  const ch0 = buffer.getChannelData(0);
  const ch1 = numChannels > 1 ? buffer.getChannelData(1) : ch0;

  let offset = 44;
  for (let i = 0; i < length; i++) {
    const s0 = Math.max(-1, Math.min(1, ch0[i]));
    view.setInt16(offset, s0 < 0 ? s0 * 0x8000 : s0 * 0x7fff, true);
    offset += 2;
    if (numChannels > 1) {
      const s1 = Math.max(-1, Math.min(1, ch1[i]));
      view.setInt16(offset, s1 < 0 ? s1 * 0x8000 : s1 * 0x7fff, true);
      offset += 2;
    }
  }

  return new Blob([arrayBuffer], { type: 'audio/wav' });
}
