import {
  DemucsHardwareCapabilities,
  DemucsModelPreference,
  DemucsModelVariant,
  DemucsStemSet,
  StemName,
  StemQualityReport,
} from '../types/audio';

const CHUNK_BYTES = 4 * 1024 * 1024; // 4 MiB — safely below Cloud Run's 32 MiB cap
const IDB_NAME = 'CueGridDemucsStemsDB';
const IDB_STORE = 'stems';
const IDB_VERSION = 1;

const STEM_NAMES: StemName[] = ['drums', 'bass', 'other', 'vocals'];

function openStemDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB unavailable'));
      return;
    }
    const req = indexedDB.open(IDB_NAME, IDB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(IDB_STORE)) {
        db.createObjectStore(IDB_STORE, { keyPath: 'cacheKey' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('IndexedDB open failed'));
  });
}

async function readStemCacheIdb(cacheKey: string): Promise<DemucsStemSet | null> {
  try {
    const db = await openStemDb();
    return await new Promise((resolve) => {
      const tx = db.transaction(IDB_STORE, 'readonly');
      const store = tx.objectStore(IDB_STORE);
      const req = store.get(cacheKey);
      req.onsuccess = () => {
        const rec = req.result;
        if (!rec) {
          resolve(null);
          return;
        }
        resolve({
          ...rec,
          fromCache: true,
        } as DemucsStemSet);
      };
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

async function writeStemCacheIdb(cacheKey: string, stemSet: DemucsStemSet): Promise<void> {
  try {
    const db = await openStemDb();
    await new Promise<void>((resolve) => {
      const tx = db.transaction(IDB_STORE, 'readwrite');
      const store = tx.objectStore(IDB_STORE);
      store.put({ cacheKey, ...stemSet });
      tx.oncomplete = () => resolve();
      tx.onerror = () => resolve();
    });
  } catch {
    // Ignore IndexedDB quota errors on very large files
  }
}

export function computeStemPeaks(
  left: Float32Array,
  right: Float32Array,
  bins = 900
): Float32Array {
  const peaks = new Float32Array(bins);
  const len = left.length;
  for (let b = 0; b < bins; b++) {
    const start = Math.floor((b / bins) * len);
    const end = Math.min(len, Math.floor(((b + 1) / bins) * len));
    let p = 0;
    const stride = Math.max(1, Math.floor((end - start) / 128));
    for (let i = start; i < end; i += stride) {
      const m = Math.max(Math.abs(left[i]), Math.abs(right[i]));
      if (m > p) p = m;
    }
    peaks[b] = p;
  }
  return peaks;
}

export async function computeAudioFingerprint(buffer: AudioBuffer): Promise<string> {
  const len = buffer.length;
  const ch0 = buffer.getChannelData(0);
  const ch1 = buffer.numberOfChannels > 1 ? buffer.getChannelData(1) : ch0;

  // Deterministic sample header + full digest if <= 60 MB, otherwise dense 4096-point fingerprint + exact length/sr
  const header = new Uint32Array([buffer.sampleRate, buffer.numberOfChannels, len]);
  if (len * 8 <= 48 * 1024 * 1024) {
    const payload = new Uint8Array(12 + len * 8);
    payload.set(new Uint8Array(header.buffer), 0);
    payload.set(new Uint8Array(ch0.buffer, ch0.byteOffset, len * 4), 12);
    payload.set(new Uint8Array(ch1.buffer, ch1.byteOffset, len * 4), 12 + len * 4);
    const digest = await crypto.subtle.digest('SHA-256', payload);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }

  const samples = 4096;
  const payload = new Uint8Array(12 + samples * 8);
  payload.set(new Uint8Array(header.buffer), 0);
  const view = new Float32Array(payload.buffer, 12, samples * 2);
  for (let i = 0; i < samples; i++) {
    const idx = Math.min(len - 1, Math.floor((i / samples) * len));
    view[i * 2] = ch0[idx];
    view[i * 2 + 1] = ch1[idx];
  }
  const digest = await crypto.subtle.digest('SHA-256', payload);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

let memoryCapsCache: DemucsHardwareCapabilities | null = null;

function readCachedCaps(): DemucsHardwareCapabilities | null {
  if (memoryCapsCache) return memoryCapsCache;
  try {
    const raw = window.sessionStorage.getItem('cuegrid_demucs_caps');
    if (raw) {
      const parsed = JSON.parse(raw) as DemucsHardwareCapabilities;
      if (parsed && typeof parsed.recommendedModel === 'string') {
        memoryCapsCache = parsed;
        return parsed;
      }
    }
  } catch {
    // Ignore storage failures
  }
  return null;
}

function writeCachedCaps(caps: DemucsHardwareCapabilities): void {
  memoryCapsCache = caps;
  try {
    window.sessionStorage.setItem('cuegrid_demucs_caps', JSON.stringify(caps));
  } catch {
    // Ignore storage failures
  }
}

async function waitMs(ms: number, signal?: AbortSignal): Promise<void> {
  if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => {
      cleanup();
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(timer);
      cleanup();
      reject(new DOMException('Aborted', 'AbortError'));
    };
    const cleanup = () => {
      signal?.removeEventListener('abort', onAbort);
    };
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

export async function fetchDemucsCapabilities(
  signal?: AbortSignal
): Promise<DemucsHardwareCapabilities> {
  const retryDelays = [0, 450, 1100, 2200];
  let lastError: Error | null = null;

  for (let attempt = 0; attempt < retryDelays.length; attempt++) {
    if (retryDelays[attempt] > 0) {
      await waitMs(retryDelays[attempt], signal);
    }
    try {
      const res = await fetch('/api/demucs/capabilities', {
        cache: 'no-store',
        credentials: 'same-origin',
        headers: { Accept: 'application/json' },
        signal,
      });

      const contentType = res.headers.get('content-type') || '';
      if (!res.ok) {
        let serverMsg = '';
        if (contentType.includes('application/json')) {
          const errJson = (await res.json().catch(() => ({}))) as { error?: string };
          serverMsg = errJson.error ? `: ${errJson.error}` : '';
        }
        lastError = new Error(`Failed to fetch Demucs capabilities (${res.status}${serverMsg})`);
        if (res.status >= 500 || res.status === 404 || res.status === 429) {
          continue;
        }
        throw lastError;
      }

      if (!contentType.includes('application/json')) {
        lastError = new Error('Server returned non-JSON response while checking Demucs capabilities');
        continue;
      }

      const caps = (await res.json()) as DemucsHardwareCapabilities;
      writeCachedCaps(caps);
      return caps;
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') throw err;
      lastError = err instanceof Error ? err : new Error('Failed to fetch Demucs capabilities');
    }
  }

  const fallback = readCachedCaps();
  if (fallback) return fallback;
  throw lastError ?? new Error('Failed to fetch Demucs capabilities');
}

interface ServerJobResponse {
  jobId: string;
  cacheKey: string;
  resolvedModel: DemucsModelVariant;
  providerUsed: string;
  sampleRate: number;
  lengthSamples: number;
  status: 'uploading' | 'queued' | 'downloading_model' | 'separating' | 'verifying' | 'completed' | 'error';
  progressPct: number;
  stage: string;
  error: string | null;
  qc: StemQualityReport | null;
  fromCache: boolean;
}

async function downloadStemPlanar(
  jobId: string,
  stem: StemName,
  lengthSamples: number,
  signal?: AbortSignal
): Promise<{ L: Float32Array; R: Float32Array }> {
  const totalBytes = lengthSamples * 2 * 4;
  const raw = new Uint8Array(totalBytes);
  let received = 0;

  while (received < totalBytes) {
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    const start = received;
    const end = Math.min(totalBytes - 1, start + CHUNK_BYTES - 1);
    const res = await fetch(
      `/api/demucs/jobs/${encodeURIComponent(jobId)}/stem/${stem}?start=${start}&end=${end}`,
      { signal, credentials: 'same-origin' }
    );
    if (!res.ok) {
      throw new Error(`Failed to download ${stem} stem (HTTP ${res.status})`);
    }
    const buf = new Uint8Array(await res.arrayBuffer());
    raw.set(buf, start);
    received += buf.byteLength;
    if (buf.byteLength === 0) {
      throw new Error(`Incomplete download for ${stem} stem.`);
    }
  }

  const floatView = new Float32Array(raw.buffer);
  return {
    L: new Float32Array(floatView.subarray(0, lengthSamples)),
    R: new Float32Array(floatView.subarray(lengthSamples, lengthSamples * 2)),
  };
}

export async function separateTrackWithDemucs(
  buffer: AudioBuffer,
  modelPreference: DemucsModelPreference,
  onProgress: (pct: number, stage: string) => void,
  signal?: AbortSignal
): Promise<DemucsStemSet> {
  onProgress(1, 'Computing track fingerprint & checking Demucs stem cache...');
  const audioHash = await computeAudioFingerprint(buffer);
  if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');

  let preferredAutoModel: DemucsModelVariant | null =
    modelPreference === 'auto' ? readCachedCaps()?.recommendedModel ?? null : modelPreference;

  if (!preferredAutoModel) {
    try {
      const caps = await fetchDemucsCapabilities(signal);
      preferredAutoModel = caps.recommendedModel;
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') throw err;
      // Do not fail early if /api/demucs/capabilities flickered; check IDB & let /api/demucs/jobs resolve model
      preferredAutoModel = null;
    }
  }

  const idbCandidates: DemucsModelVariant[] = preferredAutoModel
    ? [preferredAutoModel]
    : ['htdemucs_ft', 'htdemucs'];

  for (const cand of idbCandidates) {
    const cachedIdb = await readStemCacheIdb(`${audioHash}_${cand}`);
    if (
      cachedIdb &&
      cachedIdb.sampleRate === buffer.sampleRate &&
      cachedIdb.length === buffer.length
    ) {
      onProgress(100, `Loaded cached ${cachedIdb.modelUsed} 4-stem separation`);
      return cachedIdb;
    }
  }

  // Create job (or hit server disk cache) — retry briefly on transient proxy 5xx
  let createRes: Response | null = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    if (attempt > 0) await waitMs(attempt * 700, signal);
    const res = await fetch('/api/demucs/jobs', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        audioHash,
        modelPreference,
        sampleRate: buffer.sampleRate,
        channels: Math.min(2, buffer.numberOfChannels),
        lengthSamples: buffer.length,
      }),
      signal,
    });
    if (res.ok || (res.status < 500 && res.status !== 404)) {
      createRes = res;
      break;
    }
    createRes = res;
  }

  if (!createRes || !createRes.ok) {
    const errBody = createRes ? await createRes.json().catch(() => ({})) : {};
    throw new Error(
      errBody.error || `Failed to create Demucs job (${createRes?.status ?? 'network error'})`
    );
  }

  let job = (await createRes.json()) as ServerJobResponse;
  const idbKey = `${audioHash}_${job.resolvedModel}`;

  if (job.status !== 'completed') {
    const onAbort = () => {
      void fetch(`/api/demucs/jobs/${encodeURIComponent(job.jobId)}`, {
        method: 'DELETE',
        credentials: 'same-origin',
        keepalive: true,
      }).catch(() => {});
    };
    signal?.addEventListener('abort', onAbort, { once: true });

    try {
      // Upload planar stereo Float32 in 4 MiB chunks
      const len = buffer.length;
      const ch0 = buffer.getChannelData(0);
      const ch1 = buffer.numberOfChannels > 1 ? buffer.getChannelData(1) : ch0;
      const planar = new Float32Array(len * 2);
      planar.set(ch0, 0);
      planar.set(ch1, len);
      const totalBytes = planar.byteLength;
      const byteView = new Uint8Array(planar.buffer);

      let sent = 0;
      while (sent < totalBytes) {
        if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
        const end = Math.min(totalBytes, sent + CHUNK_BYTES);
        const slice = byteView.subarray(sent, end);
        const chunkRes = await fetch(
          `/api/demucs/jobs/${encodeURIComponent(job.jobId)}/chunk?offset=${sent}`,
          {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/octet-stream' },
            body: slice,
            signal,
          }
        );
        if (!chunkRes.ok) {
          const errBody = await chunkRes.json().catch(() => ({}));
          throw new Error(errBody.error || `Chunk upload failed (${chunkRes.status})`);
        }
        sent = end;
        const pct = Math.max(2, Math.round((sent / totalBytes) * 8));
        onProgress(pct, `Uploading audio to ${job.resolvedModel} (${Math.round((sent / totalBytes) * 100)}%)...`);
      }

      const startRes = await fetch(`/api/demucs/jobs/${encodeURIComponent(job.jobId)}/start`, {
        method: 'POST',
        credentials: 'same-origin',
        signal,
      });
      if (!startRes.ok) {
        const errBody = await startRes.json().catch(() => ({}));
        throw new Error(errBody.error || 'Failed to start Demucs separation.');
      }
      job = (await startRes.json()) as ServerJobResponse;

      let consecutivePollErrors = 0;
      while (job.status !== 'completed' && job.status !== 'error') {
        if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
        await waitMs(500, signal);
        try {
          const pollRes = await fetch(`/api/demucs/jobs/${encodeURIComponent(job.jobId)}`, {
            cache: 'no-store',
            credentials: 'same-origin',
            signal,
          });
          if (!pollRes.ok) {
            if (pollRes.status >= 500 && consecutivePollErrors < 4) {
              consecutivePollErrors++;
              continue;
            }
            throw new Error(`Lost connection to Demucs job (${pollRes.status})`);
          }
          consecutivePollErrors = 0;
          job = (await pollRes.json()) as ServerJobResponse;
          const mappedPct = Math.min(92, 8 + Math.round(job.progressPct * 0.84));
          onProgress(mappedPct, job.stage);
        } catch (pollErr) {
          if (pollErr instanceof DOMException && pollErr.name === 'AbortError') throw pollErr;
          if (consecutivePollErrors < 4) {
            consecutivePollErrors++;
            continue;
          }
          throw pollErr;
        }
      }

      if (job.status === 'error') {
        throw new Error(job.error || 'Demucs stem separation failed.');
      }
    } finally {
      signal?.removeEventListener('abort', onAbort);
    }
  }

  if (!job.qc) {
    throw new Error('Demucs job finished without Quality Control report.');
  }

  // Download all 4 stems in 4 MiB chunks
  const stemAudio = {} as Record<StemName, { L: Float32Array; R: Float32Array }>;
  const peaks = {} as Record<StemName, Float32Array>;

  for (let i = 0; i < STEM_NAMES.length; i++) {
    const sName = STEM_NAMES[i];
    onProgress(
      92 + Math.round(((i + 0.5) / STEM_NAMES.length) * 7),
      `Streaming ${sName} stem from ${job.resolvedModel}...`
    );
    const data = await downloadStemPlanar(job.jobId, sName, job.lengthSamples, signal);
    stemAudio[sName] = data;
    peaks[sName] = computeStemPeaks(data.L, data.R, 900);
  }

  const stemSet: DemucsStemSet = {
    audioHash,
    modelUsed: job.resolvedModel,
    providerUsed: job.providerUsed,
    fromCache: job.fromCache,
    sampleRate: job.sampleRate,
    length: job.lengthSamples,
    durationSec: job.lengthSamples / job.sampleRate,
    vocalsL: stemAudio.vocals.L,
    vocalsR: stemAudio.vocals.R,
    drumsL: stemAudio.drums.L,
    drumsR: stemAudio.drums.R,
    bassL: stemAudio.bass.L,
    bassR: stemAudio.bass.R,
    otherL: stemAudio.other.L,
    otherR: stemAudio.other.R,
    peaks,
    qc: job.qc,
    engineLabel: `${job.resolvedModel} · 4-Stem (${job.providerUsed})`,
  };

  await writeStemCacheIdb(idbKey, stemSet);
  onProgress(100, `${job.resolvedModel} 4-stem separation ready`);
  return stemSet;
}
