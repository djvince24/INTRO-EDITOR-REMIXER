import { DemoTrackSpec } from '../types/audio';

export const DEMO_TRACKS: DemoTrackSpec[] = [
  {
    id: 'midnight-velvet',
    title: 'Midnight Velvet',
    artist: 'Studio Groove Pack',
    genre: 'Nu-Disco / House',
    bpm: 124,
    key: 'F Minor',
    description:
      'Vocal hook enters early at Bar 5; clean full-drum & Rhodes instrumental chorus groove sits at Bars 13–20.',
  },
  {
    id: 'solar-drift',
    title: 'Solar Drift',
    artist: 'Studio Groove Pack',
    genre: 'Melodic Club',
    bpm: 126,
    key: 'A Minor',
    description:
      'Lead vocal enters right on Bar 1; instrumental break with full percussion and synth arps appears at Bars 9–16.',
  },
  {
    id: 'concrete-bounce',
    title: 'Concrete Bounce',
    artist: 'Studio Groove Pack',
    genre: 'Afro-Pop / Groove',
    bpm: 104,
    key: 'D Minor',
    description:
      'Syncopated rim-percussion and plucked stereo guitar groove with Verse 1 entering cleanly at Bar 5.',
  },
];

function midiToHz(midi: number): number {
  return 440 * Math.pow(2, (midi - 69) / 12);
}

interface SynthDemoOutputs {
  fullMix: AudioBuffer;
  drumsL: Float32Array;
  drumsR: Float32Array;
  bassL: Float32Array;
  bassR: Float32Array;
  otherL: Float32Array;
  otherR: Float32Array;
  barSec: number;
}

function synthesizeDemoLayers(trackId: string, sampleRate = 44100): SynthDemoOutputs {
  const spec = DEMO_TRACKS.find((t) => t.id === trackId) ?? DEMO_TRACKS[0];
  const bpm = spec.bpm;
  const beatSec = 60 / bpm;
  const barSec = beatSec * 4;
  const totalBars = 24;
  const totalSamples = Math.round(totalBars * barSec * sampleRate);

  const drumsL = new Float32Array(totalSamples);
  const drumsR = new Float32Array(totalSamples);
  const bassL = new Float32Array(totalSamples);
  const bassR = new Float32Array(totalSamples);
  const otherL = new Float32Array(totalSamples);
  const otherR = new Float32Array(totalSamples);
  const vocL = new Float32Array(totalSamples);
  const vocR = new Float32Array(totalSamples);

  const barSamples = Math.round(barSec * sampleRate);
  const beatSamples = Math.round(beatSec * sampleRate);
  const sixteenthSamples = Math.floor(beatSamples / 4);

  const addKick = (pos: number, gain = 0.72) => {
    const len = Math.min(Math.floor(0.28 * sampleRate), totalSamples - pos);
    let phase = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sampleRate;
      const freq = 48 + 115 * Math.exp(-t * 34);
      phase += (2 * Math.PI * freq) / sampleRate;
      const env = Math.exp(-t * 9.5) * Math.min(1, t / 0.003);
      const click = Math.exp(-t * 140) * 0.25;
      const s = (Math.sin(phase) * 0.92 + click) * env * gain;
      drumsL[pos + i] += s;
      drumsR[pos + i] += s;
    }
  };

  const addClap = (pos: number, gain = 0.42) => {
    const len = Math.min(Math.floor(0.18 * sampleRate), totalSamples - pos);
    let lpL = 0;
    let lpR = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sampleRate;
      const n1 = Math.sin(i * 12.9898) * 43758.5453;
      const noiseL = (n1 - Math.floor(n1)) * 2 - 1;
      const n2 = Math.sin((i + 17) * 78.233) * 43758.5453;
      const noiseR = (n2 - Math.floor(n2)) * 2 - 1;
      lpL = lpL * 0.55 + noiseL * 0.45;
      lpR = lpR * 0.55 + noiseR * 0.45;
      const multi =
        Math.exp(-t * 28) +
        (t > 0.011 ? Math.exp(-(t - 0.011) * 32) * 0.7 : 0);
      const body = Math.sin(2 * Math.PI * 190 * t) * Math.exp(-t * 36) * 0.35;
      drumsL[pos + i] += (lpL * multi * 0.7 + body) * gain;
      drumsR[pos + i] += (lpR * multi * 0.7 + body) * gain;
    }
  };

  const addHat = (pos: number, open = false, gain = 0.19) => {
    const dur = open ? 0.19 : 0.045;
    const len = Math.min(Math.floor(dur * sampleRate), totalSamples - pos);
    let prev = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sampleRate;
      const r = Math.sin((i + pos) * 19.313) * 43758.5453;
      const white = (r - Math.floor(r)) * 2 - 1;
      const hp = white - prev * 0.88;
      prev = white;
      const env = Math.exp(-t * (open ? 14 : 65));
      const val = hp * env * gain;
      drumsL[pos + i] += val * 0.92;
      drumsR[pos + i] += val * 1.08;
    }
  };

  const addBass = (pos: number, midi: number, durSec: number, gain = 0.42) => {
    const len = Math.min(Math.floor(durSec * sampleRate), totalSamples - pos);
    const hz = midiToHz(midi);
    let lp = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sampleRate;
      const p = (t * hz) % 1;
      const saw = p * 2 - 1;
      const sub = Math.sin(2 * Math.PI * hz * t);
      const cutoff = 0.08 + 0.24 * Math.exp(-t * 8);
      lp = lp + cutoff * (saw - lp);
      const env = Math.min(1, t / 0.006) * Math.min(1, (durSec - t) / 0.025);
      const s = (lp * 0.55 + sub * 0.65) * env * gain;
      bassL[pos + i] += s;
      bassR[pos + i] += s;
    }
  };

  const addStereoChord = (
    pos: number,
    midis: number[],
    durSec: number,
    gain = 0.18
  ) => {
    const len = Math.min(Math.floor(durSec * sampleRate), totalSamples - pos);
    for (let i = 0; i < len; i++) {
      const t = i / sampleRate;
      const env =
        Math.min(1, t / 0.015) *
        Math.exp(-t * 2.2) *
        Math.min(1, (durSec - t) / 0.03);
      let sL = 0;
      let sR = 0;
      for (let n = 0; n < midis.length; n++) {
        const hz = midiToHz(midis[n]);
        const detune = n % 2 === 0 ? 1.0025 : 0.9975;
        const oscA =
          Math.sin(2 * Math.PI * hz * t) + 0.22 * Math.sin(4 * Math.PI * hz * t);
        const oscB =
          Math.sin(2 * Math.PI * hz * detune * t) +
          0.18 * Math.sin(6 * Math.PI * hz * t);
        const pan = (n / Math.max(1, midis.length - 1)) * 0.8 - 0.4;
        sL += oscA * (0.65 - pan * 0.45) + oscB * 0.25;
        sR += oscB * (0.65 + pan * 0.45) + oscA * 0.25;
      }
      otherL[pos + i] += (sL / midis.length) * env * gain;
      otherR[pos + i] += (sR / midis.length) * env * gain;
    }
  };

  const addStereoPluck = (pos: number, midi: number, pan: number, gain = 0.2) => {
    const dur = 0.26;
    const len = Math.min(Math.floor(dur * sampleRate), totalSamples - pos);
    const hz = midiToHz(midi);
    for (let i = 0; i < len; i++) {
      const t = i / sampleRate;
      const env = Math.min(1, t / 0.004) * Math.exp(-t * 11);
      const tone =
        Math.sin(2 * Math.PI * hz * t) * 0.7 +
        Math.sin(4 * Math.PI * hz * t) * 0.25 * Math.exp(-t * 18);
      const gL = Math.cos(((pan + 1) * Math.PI) / 4) * tone * env * gain;
      const gR = Math.sin(((pan + 1) * Math.PI) / 4) * tone * env * gain;
      otherL[pos + i] += gL;
      otherR[pos + i] += gR;
    }
  };

  const addCenteredVocalLead = (pos: number, midi: number, durSec: number, gain = 0.34) => {
    const len = Math.min(Math.floor(durSec * sampleRate), totalSamples - pos);
    const baseHz = midiToHz(midi);
    for (let i = 0; i < len; i++) {
      const t = i / sampleRate;
      const vibrato = 1 + 0.005 * Math.sin(2 * Math.PI * 5.6 * t);
      const hz = baseHz * vibrato;
      const f1 = Math.sin(2 * Math.PI * hz * t);
      const f2 = 0.65 * Math.sin(2 * Math.PI * hz * 2 * t);
      const f3 = 0.45 * Math.sin(2 * Math.PI * hz * 3 * t);
      const f4 = 0.25 * Math.sin(2 * Math.PI * hz * 4 * t);
      const env =
        Math.min(1, t / 0.025) *
        Math.min(1, (durSec - t) / 0.04) *
        (0.85 + 0.15 * Math.sin(2 * Math.PI * 2.5 * t));
      const v = (f1 + f2 + f3 + f4) * 0.45 * env * gain;
      vocL[pos + i] += v;
      vocR[pos + i] += v;
    }
  };

  const chordsMinor = [
    [53, 56, 60, 63],
    [51, 55, 58, 62],
    [49, 53, 56, 60],
    [48, 52, 55, 58],
  ];
  const bassRoots = [41, 39, 37, 36];
  const arpNotes = [65, 68, 72, 75, 72, 68, 67, 70];
  const vocalMelody = [65, 68, 67, 65, 63, 65, 68, 72];

  for (let bar = 0; bar < totalBars; bar++) {
    const barPos = bar * barSamples;
    const chord = chordsMinor[bar % 4];
    const root = bassRoots[bar % 4];

    let hasFullDrums = true;
    let hasVocal = false;
    let sparseIntro = false;

    if (trackId === 'midnight-velvet') {
      sparseIntro = bar < 4;
      hasFullDrums = bar >= 4;
      hasVocal = (bar >= 4 && bar < 12) || bar >= 20;
    } else if (trackId === 'solar-drift') {
      hasFullDrums = true;
      hasVocal = bar < 8 || bar >= 16;
    } else {
      sparseIntro = bar < 4;
      hasFullDrums = bar >= 4;
      hasVocal = (bar >= 4 && bar < 12) || bar >= 20;
    }

    if (hasFullDrums) {
      if (trackId === 'concrete-bounce') {
        addKick(barPos, 0.74);
        addKick(barPos + sixteenthSamples * 3, 0.56);
        addKick(barPos + sixteenthSamples * 6, 0.68);
        addKick(barPos + sixteenthSamples * 10, 0.62);
        addKick(barPos + sixteenthSamples * 12, 0.72);
        addClap(barPos + sixteenthSamples * 4, 0.36);
        addClap(barPos + sixteenthSamples * 12, 0.42);
      } else {
        for (let beat = 0; beat < 4; beat++) {
          addKick(barPos + beat * beatSamples, 0.74);
          if (beat === 1 || beat === 3) {
            addClap(barPos + beat * beatSamples, 0.42);
          }
          addHat(barPos + beat * beatSamples + sixteenthSamples * 2, true, 0.21);
          addHat(barPos + beat * beatSamples + sixteenthSamples * 1, false, 0.11);
          addHat(barPos + beat * beatSamples + sixteenthSamples * 3, false, 0.13);
        }
      }
    } else {
      addHat(barPos + beatSamples * 1, false, 0.1);
      addHat(barPos + beatSamples * 3, false, 0.1);
    }

    if (!sparseIntro) {
      for (let beat = 0; beat < 4; beat++) {
        const bPos = barPos + beat * beatSamples;
        if (trackId === 'concrete-bounce') {
          if (beat === 0 || beat === 2) {
            addBass(bPos, root, beatSec * 0.7, 0.45);
            addBass(bPos + sixteenthSamples * 3, root + 7, beatSec * 0.45, 0.35);
          }
        } else {
          addBass(
            bPos + sixteenthSamples * 2,
            root + (beat === 3 ? 3 : 0),
            beatSec * 0.46,
            0.42
          );
          if (beat === 0 || beat === 2) {
            addBass(bPos, root, beatSec * 0.4, 0.32);
          }
        }
      }
    }

    addStereoChord(barPos, chord, barSec * 0.85, sparseIntro ? 0.14 : 0.2);
    if (!sparseIntro) {
      addStereoChord(
        barPos + beatSamples * 2 + sixteenthSamples * 2,
        chord,
        beatSec * 0.9,
        0.15
      );
      for (let step = 0; step < 8; step++) {
        const arpPos = barPos + step * sixteenthSamples * 2;
        const note = arpNotes[(bar * 3 + step) % arpNotes.length];
        const pan = step % 2 === 0 ? -0.65 : 0.65;
        addStereoPluck(arpPos, note, pan, 0.18);
      }
    } else {
      for (let step = 0; step < 4; step++) {
        addStereoPluck(
          barPos + step * beatSamples,
          arpNotes[step],
          step % 2 === 0 ? -0.5 : 0.5,
          0.14
        );
      }
    }

    if (hasVocal) {
      addCenteredVocalLead(
        barPos,
        vocalMelody[(bar * 2) % vocalMelody.length] + 12,
        beatSec * 1.4,
        0.28
      );
      addCenteredVocalLead(
        barPos + beatSamples * 2,
        vocalMelody[(bar * 2 + 1) % vocalMelody.length] + 12,
        beatSec * 1.3,
        0.26
      );
    }
  }

  const outL = new Float32Array(totalSamples);
  const outR = new Float32Array(totalSamples);
  for (let i = 0; i < totalSamples; i++) {
    const l = drumsL[i] + bassL[i] + otherL[i] + vocL[i];
    const r = drumsR[i] + bassR[i] + otherR[i] + vocR[i];
    outL[i] = Math.abs(l) > 0.95 ? Math.tanh(l) : l;
    outR[i] = Math.abs(r) > 0.95 ? Math.tanh(r) : r;
  }

  const fullMix = new AudioBuffer({
    length: totalSamples,
    numberOfChannels: 2,
    sampleRate,
  });
  fullMix.copyToChannel(outL, 0);
  fullMix.copyToChannel(outR, 1);

  return { fullMix, drumsL, drumsR, bassL, bassR, otherL, otherR, barSec };
}

export function generateDemoTrackBuffer(trackId: string, sampleRate = 44100): AudioBuffer {
  return synthesizeDemoLayers(trackId, sampleRate).fullMix;
}
