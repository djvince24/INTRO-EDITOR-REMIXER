import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Play, Pause, Upload, SkipBack, Repeat, Volume2, Volume1, VolumeX } from 'lucide-react';
import { DEMO_TRACKS, generateDemoTrackBuffer } from './audio/demoTracks';
import { fetchDemucsCapabilities, separateTrackWithDemucs } from './audio/demucsClient';
import {
  alignVocalDeckToInstDeck,
  analyzeTrack,
  computeBestHalfDoubleTime,
  refineAnalysisWithDemucsStems,
} from './audio/dspAnalysis';
import { encodeAudioBufferToWav, renderDjIntroEdit } from './audio/dspRenderer';
import { renderBeatmatchedRemix } from './audio/remixEngine';
import { DemucsStemEditor } from './components/DemucsStemEditor';
import { EditControlsPanel } from './components/EditControlsPanel';
import { RemixStudioView } from './components/RemixStudioView';
import { ActiveTab, TopBar } from './components/TopBar';
import { TrackSourceView } from './components/TrackSourceView';
import { TransitionCheckView } from './components/TransitionCheckView';
import {
  OriginalMonitorMode,
  SourceGridMode,
  WaveformTimeline,
} from './components/WaveformTimeline';
import {
  DemucsHardwareCapabilities,
  DemucsModelPreference,
  DemucsStemSet,
  IntroEditConfig,
  PlaybackDeck,
  RemixConfig,
  RenderedIntroEdit,
  RenderedRemix,
  TrackAnalysis,
} from './types/audio';

function formatClock(sec: number): string {
  const s = Math.max(0, sec);
  const mins = Math.floor(s / 60);
  const rem = s - mins * 60;
  return `${String(mins).padStart(2, '0')}:${rem.toFixed(2).padStart(5, '0')}`;
}

function buildStemAudioBuffer(
  left: Float32Array,
  right: Float32Array,
  sampleRate: number
): AudioBuffer {
  const buf = new AudioBuffer({
    numberOfChannels: 2,
    length: left.length,
    sampleRate,
  });
  buf.getChannelData(0).set(left);
  buf.getChannelData(1).set(right);
  return buf;
}

function gridModeToMonitor(mode: SourceGridMode): OriginalMonitorMode {
  if (mode === 'cue1') return 'vocals';
  if (mode === 'donor') return 'instrumental';
  return 'full';
}

function createDefaultStemsConfig(): IntroEditConfig['stems'] {
  return {
    drums: {
      volume: 1.0,
      mute: false,
      solo: false,
      fadeInSec: 0,
      fadeOutSec: 0,
      introEntryBar: 0,
      introLevel: 1.0,
    },
    bass: {
      volume: 1.0,
      mute: false,
      solo: false,
      fadeInSec: 0,
      fadeOutSec: 0,
      introEntryBar: 2,
      introLevel: 1.0,
    },
    other: {
      volume: 1.0,
      mute: false,
      solo: false,
      fadeInSec: 0,
      fadeOutSec: 0,
      introEntryBar: 4,
      introLevel: 1.0,
    },
    vocals: {
      volume: 1.0,
      mute: false,
      solo: false,
      fadeInSec: 0,
      fadeOutSec: 0,
      introEntryBar: 0,
      introLevel: 0.0,
    },
  };
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('studio');
  const [trackId, setTrackId] = useState<string>(DEMO_TRACKS[0].id);
  const [trackName, setTrackName] = useState<string>(
    `${DEMO_TRACKS[0].title} — ${DEMO_TRACKS[0].artist}`
  );
  const [sourceBuffer, setSourceBuffer] = useState<AudioBuffer | null>(null);
  const [analysis, setAnalysis] = useState<TrackAnalysis | null>(null);
  const [config, setConfig] = useState<IntroEditConfig | null>(null);
  const [rendered, setRendered] = useState<RenderedIntroEdit | null>(null);

  const [capabilities, setCapabilities] = useState<DemucsHardwareCapabilities | null>(null);
  const [demucsStems, setDemucsStems] = useState<DemucsStemSet | null>(null);
  const [isSeparatingDemucs, setIsSeparatingDemucs] = useState<boolean>(false);
  const [stemProgress, setStemProgress] = useState<{ pct: number; stage: string } | null>(null);
  const [demucsError, setDemucsError] = useState<string | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState<boolean>(false);

  const [activeDeck, setActiveDeck] = useState<PlaybackDeck>('edit');
  const [sourceGridMode, setSourceGridMode] = useState<SourceGridMode>('scrub');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTimeSec, setCurrentTimeSec] = useState<number>(0);
  const [loopSeamMode, setLoopSeamMode] = useState<boolean>(false);

  // Deck B: Vocal track state for cross-song Beatmatched Vocal Remix
  const [vocalTrackId, setVocalTrackId] = useState<string>('');
  const [vocalTrackName, setVocalTrackName] = useState<string>('No vocal track loaded');
  const [vocalBuffer, setVocalBuffer] = useState<AudioBuffer | null>(null);
  const [vocalAnalysis, setVocalAnalysis] = useState<TrackAnalysis | null>(null);
  const [vocalStems, setVocalStems] = useState<DemucsStemSet | null>(null);
  const [isSeparatingVocal, setIsSeparatingVocal] = useState<boolean>(false);
  const [vocalProgress, setVocalProgress] = useState<{ pct: number; stage: string } | null>(null);
  const [vocalError, setVocalError] = useState<string | null>(null);
  const [remixConfig, setRemixConfig] = useState<RemixConfig>({
    instStartBar: 0,
    instDrumsLevel: 1.0,
    instBassLevel: 1.0,
    instOtherLevel: 0.95,
    instBedLevel: 1.0,
    vocalBpm: 120,
    vocalFirstDownbeatSec: 0,
    vocalCueBar: 0,
    vocalBeatShift: 0,
    vocalTargetDropBar: 0,
    vocalFineOffsetMs: 0,
    autoBeatmatch: true,
    halfDoubleTime: '1x',
    phraseLockEnabled: true,
    pitchSemitones: 0,
    vocalLevel: 1.05,
    pocketCarveAmount: 0.55,
    vocalSpaceAmount: 0.14,
    vocalTone: 'pop-clarity',
  });
  const [renderedRemix, setRenderedRemix] = useState<RenderedRemix | null>(null);
  const [beatClickEnabled, setBeatClickEnabled] = useState<boolean>(false);

  const [masterVolume, setMasterVolume] = useState<number>(() => {
    try {
      const saved = window.localStorage.getItem('cuegrid_master_volume');
      if (saved !== null) {
        const n = Number(saved);
        if (Number.isFinite(n) && n >= 0 && n <= 1.5) return n;
      }
    } catch {
      // Ignore storage access failures
    }
    return 1.0;
  });
  const [masterMuted, setMasterMuted] = useState<boolean>(() => {
    try {
      return window.localStorage.getItem('cuegrid_master_muted') === '1';
    } catch {
      return false;
    }
  });
  const [masterMeterLevel, setMasterMeterLevel] = useState<number>(0);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);
  const masterLimiterRef = useRef<DynamicsCompressorNode | null>(null);
  const masterAnalyserRef = useRef<AnalyserNode | null>(null);
  const meterSamplesRef = useRef<Float32Array<ArrayBuffer> | null>(null);
  const masterGainValRef = useRef<number>(masterMuted ? 0 : masterVolume);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const playStartCtxTimeRef = useRef<number>(0);
  const playOffsetSecRef = useRef<number>(0);
  const rafRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const demucsAbortRef = useRef<AbortController | null>(null);
  const demucsRequestIdRef = useRef<number>(0);
  const vocalDemucsAbortRef = useRef<AbortController | null>(null);
  const vocalDemucsReqIdRef = useRef<number>(0);
  const lastModelPrefRef = useRef<DemucsModelPreference>('auto');
  const activeOrigSourceKindRef = useRef<'full' | 'vocals' | 'instrumental'>('full');
  const beatClickEnabledRef = useRef<boolean>(false);
  const lastScheduledBeatRef = useRef<number>(-1);
  const deckAKnownBpmRef = useRef<number | undefined>(undefined);
  const deckBKnownBpmRef = useRef<number | undefined>(undefined);
  const deckACustomEditedRef = useRef<boolean>(false);
  const analysisRef = useRef<TrackAnalysis | null>(null);
  const vocalAnalysisRef = useRef<TrackAnalysis | null>(null);
  const demucsStemsRef = useRef<DemucsStemSet | null>(null);
  const vocalStemsRef = useRef<DemucsStemSet | null>(null);
  const configRef = useRef<IntroEditConfig | null>(null);
  const remixConfigRef = useRef<RemixConfig>(remixConfig);

  useEffect(() => {
    analysisRef.current = analysis;
  }, [analysis]);

  useEffect(() => {
    vocalAnalysisRef.current = vocalAnalysis;
  }, [vocalAnalysis]);

  useEffect(() => {
    demucsStemsRef.current = demucsStems;
  }, [demucsStems]);

  useEffect(() => {
    vocalStemsRef.current = vocalStems;
  }, [vocalStems]);

  useEffect(() => {
    configRef.current = config;
  }, [config]);

  useEffect(() => {
    remixConfigRef.current = remixConfig;
  }, [remixConfig]);

  const { vocalsOnlyBuffer, instOnlyBuffer } = useMemo(() => {
    if (!demucsStems) {
      return { vocalsOnlyBuffer: null, instOnlyBuffer: null };
    }
    const len = demucsStems.length;
    const sr = demucsStems.sampleRate;
    const vocalsBuf = buildStemAudioBuffer(demucsStems.vocalsL, demucsStems.vocalsR, sr);

    const instL = new Float32Array(len);
    const instR = new Float32Array(len);
    for (let i = 0; i < len; i++) {
      let l = demucsStems.drumsL[i] + demucsStems.bassL[i] + demucsStems.otherL[i];
      let r = demucsStems.drumsR[i] + demucsStems.bassR[i] + demucsStems.otherR[i];
      if (Math.abs(l) > 0.96) l = Math.sign(l) * (0.96 + 0.03 * Math.tanh((Math.abs(l) - 0.96) * 8));
      if (Math.abs(r) > 0.96) r = Math.sign(r) * (0.96 + 0.03 * Math.tanh((Math.abs(r) - 0.96) * 8));
      instL[i] = l;
      instR[i] = r;
    }
    const instBuf = buildStemAudioBuffer(instL, instR, sr);
    return { vocalsOnlyBuffer: vocalsBuf, instOnlyBuffer: instBuf };
  }, [demucsStems]);

  useEffect(() => {
    void fetchDemucsCapabilities()
      .then((caps) => setCapabilities(caps))
      .catch(() => {});
  }, []);

  const ensureMasterBus = useCallback((ctx: AudioContext): GainNode => {
    if (!masterGainRef.current) {
      const gainNode = ctx.createGain();
      gainNode.gain.value = masterGainValRef.current;

      // Transparent protective ceiling limiter so >100% monitoring boost stays clean without DAC clipping
      const limiter = ctx.createDynamicsCompressor();
      limiter.threshold.value = -0.8;
      limiter.knee.value = 2;
      limiter.ratio.value = 12;
      limiter.attack.value = 0.002;
      limiter.release.value = 0.06;

      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;

      gainNode.connect(limiter);
      limiter.connect(analyser);
      analyser.connect(ctx.destination);

      masterGainRef.current = gainNode;
      masterLimiterRef.current = limiter;
      masterAnalyserRef.current = analyser;
      meterSamplesRef.current = new Float32Array(new ArrayBuffer(analyser.fftSize * 4));
    }
    return masterGainRef.current;
  }, []);

  const getAudioContext = useCallback((): AudioContext => {
    if (!audioCtxRef.current) {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      audioCtxRef.current = new Ctx();
    }
    if (audioCtxRef.current.state === 'suspended') {
      void audioCtxRef.current.resume();
    }
    ensureMasterBus(audioCtxRef.current);
    return audioCtxRef.current;
  }, [ensureMasterBus]);

  useEffect(() => {
    const effective = masterMuted ? 0 : masterVolume;
    masterGainValRef.current = effective;
    if (masterGainRef.current && audioCtxRef.current) {
      masterGainRef.current.gain.setTargetAtTime(effective, audioCtxRef.current.currentTime, 0.015);
    }
    try {
      window.localStorage.setItem('cuegrid_master_volume', String(masterVolume));
      window.localStorage.setItem('cuegrid_master_muted', masterMuted ? '1' : '0');
    } catch {
      // Ignore storage access failures
    }
  }, [masterVolume, masterMuted]);

  useEffect(() => {
    beatClickEnabledRef.current = beatClickEnabled;
    if (!beatClickEnabled) {
      lastScheduledBeatRef.current = -1;
    }
  }, [beatClickEnabled]);

  const stopPlayback = useCallback(() => {
    if (sourceNodeRef.current) {
      try {
        sourceNodeRef.current.onended = null;
        sourceNodeRef.current.stop();
        sourceNodeRef.current.disconnect();
      } catch {
        // Ignore already stopped
      }
      sourceNodeRef.current = null;
    }
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    lastScheduledBeatRef.current = -1;
    setMasterMeterLevel(0);
    setIsPlaying(false);
  }, []);

  const startPlaybackAt = useCallback(
    (
      deck: PlaybackDeck,
      offsetSec: number,
      loopSeam = false,
      monitorOverride?: OriginalMonitorMode
    ) => {
      let buf: AudioBuffer | null | undefined;
      if (deck === 'edit') {
        buf = rendered?.buffer;
      } else if (deck === 'stems-mix') {
        buf = rendered?.stemMixBuffer;
      } else if (deck === 'remix') {
        buf = renderedRemix?.buffer;
      } else if (deck === 'remix-vocals') {
        buf = renderedRemix?.alignedVocalsBuffer;
      } else if (deck === 'remix-inst') {
        buf = renderedRemix?.instBedBuffer;
      } else {
        const monitor = monitorOverride ?? gridModeToMonitor(sourceGridMode);
        if (monitor === 'vocals' && vocalsOnlyBuffer) {
          buf = vocalsOnlyBuffer;
          activeOrigSourceKindRef.current = 'vocals';
        } else if (monitor === 'instrumental' && instOnlyBuffer) {
          buf = instOnlyBuffer;
          activeOrigSourceKindRef.current = 'instrumental';
        } else {
          buf = sourceBuffer;
          activeOrigSourceKindRef.current = 'full';
        }
      }
      if (!buf) return;

      stopPlayback();
      const ctx = getAudioContext();
      const safeOffset = Math.max(0, Math.min(buf.duration - 0.05, offsetSec));

      const node = ctx.createBufferSource();
      node.buffer = buf;

      if (loopSeam && deck === 'edit' && rendered) {
        const seamStart = Math.max(0, rendered.introDurationSec - rendered.barSec * 2);
        const seamEnd = Math.min(buf.duration, rendered.introDurationSec + rendered.barSec * 2);
        node.loop = true;
        node.loopStart = seamStart;
        node.loopEnd = seamEnd;
      }

      const masterInput = ensureMasterBus(ctx);
      masterInput.gain.setValueAtTime(masterGainValRef.current, ctx.currentTime);
      node.connect(masterInput);
      node.onended = () => {
        setIsPlaying(false);
        setMasterMeterLevel(0);
        setCurrentTimeSec(0);
        playOffsetSecRef.current = 0;
        if (rafRef.current !== null) {
          cancelAnimationFrame(rafRef.current);
          rafRef.current = null;
        }
      };

      playStartCtxTimeRef.current = ctx.currentTime;
      playOffsetSecRef.current = safeOffset;
      lastScheduledBeatRef.current = -1;
      sourceNodeRef.current = node;
      node.start(0, safeOffset);

      setActiveDeck(deck);
      setIsPlaying(true);
      setCurrentTimeSec(safeOffset);

      const isRemixDeck =
        deck === 'remix' || deck === 'remix-vocals' || deck === 'remix-inst';
      const clickBeatSec =
        isRemixDeck && renderedRemix
          ? renderedRemix.beatSec
          : config
            ? 60 / config.bpm
            : 0.5;

      const scheduleClick = (ctxTime: number, isDownbeat: boolean) => {
        if (!masterGainRef.current) return;
        const osc = ctx.createOscillator();
        const cg = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(isDownbeat ? 1180 : 790, ctxTime);
        cg.gain.setValueAtTime(isDownbeat ? 0.24 : 0.14, ctxTime);
        cg.gain.exponentialRampToValueAtTime(0.0005, ctxTime + 0.032);
        osc.connect(cg);
        cg.connect(masterGainRef.current);
        osc.start(ctxTime);
        osc.stop(ctxTime + 0.036);
      };

      const tick = () => {
        if (!audioCtxRef.current || !sourceNodeRef.current) return;
        const nowCtx = audioCtxRef.current.currentTime;
        let elapsed = nowCtx - playStartCtxTimeRef.current + playOffsetSecRef.current;

        if (isRemixDeck && beatClickEnabledRef.current && clickBeatSec > 0.2) {
          const lookAheadSec = 0.09;
          const firstBeat = Math.ceil(Math.max(0, elapsed) / clickBeatSec);
          const horizonBeat = Math.floor((elapsed + lookAheadSec) / clickBeatSec);
          for (let bIdx = firstBeat; bIdx <= horizonBeat; bIdx++) {
            if (bIdx > lastScheduledBeatRef.current) {
              const beatElapsed = bIdx * clickBeatSec;
              const beatCtxTime = playStartCtxTimeRef.current + (beatElapsed - playOffsetSecRef.current);
              if (beatCtxTime >= nowCtx - 0.005 && beatElapsed < buf.duration - 0.02) {
                scheduleClick(Math.max(nowCtx, beatCtxTime), bIdx % 4 === 0);
                lastScheduledBeatRef.current = bIdx;
              }
            }
          }
        }

        if (loopSeam && deck === 'edit' && rendered) {
          const seamStart = Math.max(0, rendered.introDurationSec - rendered.barSec * 2);
          const seamEnd = Math.min(buf.duration, rendered.introDurationSec + rendered.barSec * 2);
          const span = seamEnd - seamStart;
          if (span > 0.1 && elapsed >= seamEnd) {
            elapsed = seamStart + ((elapsed - seamStart) % span);
          }
        }

        if (masterAnalyserRef.current && meterSamplesRef.current) {
          masterAnalyserRef.current.getFloatTimeDomainData(meterSamplesRef.current);
          let peak = 0;
          const samples = meterSamplesRef.current;
          for (let i = 0; i < samples.length; i += 2) {
            const abs = Math.abs(samples[i]);
            if (abs > peak) peak = abs;
          }
          const quantized = peak < 0.015 ? 0 : Math.min(6, Math.ceil(Math.sqrt(peak) * 6));
          setMasterMeterLevel((prev) => (prev === quantized ? prev : quantized));
        }

        if (elapsed >= buf.duration) {
          setCurrentTimeSec(buf.duration);
          setMasterMeterLevel(0);
          return;
        }
        setCurrentTimeSec(elapsed);
        rafRef.current = requestAnimationFrame(tick);
      };

      rafRef.current = requestAnimationFrame(tick);
    },
    [
      rendered,
      renderedRemix,
      config,
      sourceBuffer,
      vocalsOnlyBuffer,
      instOnlyBuffer,
      sourceGridMode,
      stopPlayback,
      getAudioContext,
      ensureMasterBus,
    ]
  );

  const handleChangeSourceGridMode = useCallback(
    (nextMode: SourceGridMode) => {
      setSourceGridMode(nextMode);
      if (isPlaying && activeDeck === 'original' && audioCtxRef.current) {
        const elapsed =
          audioCtxRef.current.currentTime - playStartCtxTimeRef.current + playOffsetSecRef.current;
        startPlaybackAt('original', elapsed, false, gridModeToMonitor(nextMode));
      }
    },
    [isPlaying, activeDeck, startPlaybackAt]
  );

  // If Demucs stems finish separating while user is auditioning Place Cue 1 or Place Inst Loop,
  // seamlessly switch live playback from full mix fallback to the isolated stem buffer.
  useEffect(() => {
    if (!isPlaying || activeDeck !== 'original' || !audioCtxRef.current) return;
    const desired = gridModeToMonitor(sourceGridMode);
    if (desired === 'vocals' && vocalsOnlyBuffer && activeOrigSourceKindRef.current !== 'vocals') {
      const elapsed =
        audioCtxRef.current.currentTime - playStartCtxTimeRef.current + playOffsetSecRef.current;
      startPlaybackAt('original', elapsed, false, 'vocals');
    } else if (
      desired === 'instrumental' &&
      instOnlyBuffer &&
      activeOrigSourceKindRef.current !== 'instrumental'
    ) {
      const elapsed =
        audioCtxRef.current.currentTime - playStartCtxTimeRef.current + playOffsetSecRef.current;
      startPlaybackAt('original', elapsed, false, 'instrumental');
    }
  }, [vocalsOnlyBuffer, instOnlyBuffer, isPlaying, activeDeck, sourceGridMode, startPlaybackAt]);

  const togglePlayPause = useCallback(() => {
    if (isPlaying) {
      if (audioCtxRef.current) {
        const elapsed =
          audioCtxRef.current.currentTime - playStartCtxTimeRef.current + playOffsetSecRef.current;
        playOffsetSecRef.current = elapsed;
        setCurrentTimeSec(elapsed);
      }
      stopPlayback();
    } else {
      startPlaybackAt(activeDeck, currentTimeSec, loopSeamMode);
    }
  }, [isPlaying, activeDeck, currentTimeSec, loopSeamMode, stopPlayback, startPlaybackAt]);

  const runDemucsSeparation = useCallback(
    async (buf: AudioBuffer, modelPref: DemucsModelPreference) => {
      if (demucsAbortRef.current) {
        demucsAbortRef.current.abort();
      }
      const controller = new AbortController();
      demucsAbortRef.current = controller;
      const reqId = ++demucsRequestIdRef.current;

      setDemucsError(null);
      setIsSeparatingDemucs(true);
      setStemProgress({ pct: 1, stage: 'Initializing Demucs 4-stem separation...' });

      try {
        const stems = await separateTrackWithDemucs(
          buf,
          modelPref,
          (pct, stage) => {
            if (demucsRequestIdRef.current === reqId) {
              setStemProgress({ pct, stage });
            }
          },
          controller.signal
        );
        if (demucsRequestIdRef.current !== reqId) return;
        demucsStemsRef.current = stems;
        setDemucsStems(stems);
        const currA = analysisRef.current;
        if (currA) {
          const refined = refineAnalysisWithDemucsStems(
            currA,
            stems,
            deckAKnownBpmRef.current
          );
          analysisRef.current = refined;
          setAnalysis(refined);
          if (!deckACustomEditedRef.current) {
            setConfig((prevCfg) =>
              prevCfg
                ? {
                    ...prevCfg,
                    bpm: refined.bpm,
                    firstDownbeatSec: refined.firstDownbeatSec,
                    cue1Bar: refined.recommendedCue1Bar,
                    donorStartBar: refined.recommendedDonorStartBar,
                  }
                : prevCfg
            );
          }

          // If Deck B vocal stems are already ready, lock Deck B onto Deck A's refined Demucs grid immediately
          const vStems = vocalStemsRef.current;
          const vAnalysis = vocalAnalysisRef.current;
          const rCfg = remixConfigRef.current;
          if (vStems && vAnalysis) {
            const sync = alignVocalDeckToInstDeck(
              stems,
              refined,
              refined.bpm,
              refined.firstDownbeatSec,
              null,
              vStems,
              vAnalysis,
              rCfg.vocalBpm,
              rCfg.vocalFirstDownbeatSec,
              rCfg.vocalCueBar,
              rCfg.vocalTargetDropBar
            );
            setRemixConfig((prevRemix) => ({
              ...prevRemix,
              instStartBar: sync.recommendedInstStartBar,
              halfDoubleTime: sync.halfDoubleTime,
              vocalBeatShift: sync.beatShift,
              vocalFineOffsetMs: sync.fineOffsetMs,
            }));
          }
        }
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') return;
        if (demucsRequestIdRef.current !== reqId) return;
        setDemucsError(
          err instanceof Error
            ? err.message
            : 'Demucs stem separation failed. Retry or switch Demucs model.'
        );
      } finally {
        if (demucsRequestIdRef.current === reqId) {
          setIsSeparatingDemucs(false);
          setStemProgress(null);
        }
      }
    },
    []
  );

  const runVocalDemucsSeparation = useCallback(
    async (buf: AudioBuffer, modelPref: DemucsModelPreference, targetInstBpm: number) => {
      if (vocalDemucsAbortRef.current) {
        vocalDemucsAbortRef.current.abort();
      }
      const controller = new AbortController();
      vocalDemucsAbortRef.current = controller;
      const reqId = ++vocalDemucsReqIdRef.current;

      setVocalError(null);
      setIsSeparatingVocal(true);
      setVocalProgress({ pct: 1, stage: 'Initializing Demucs vocal isolation...' });

      try {
        const stems = await separateTrackWithDemucs(
          buf,
          modelPref,
          (pct, stage) => {
            if (vocalDemucsReqIdRef.current === reqId) {
              setVocalProgress({ pct, stage });
            }
          },
          controller.signal
        );
        if (vocalDemucsReqIdRef.current !== reqId) return;
        vocalStemsRef.current = stems;
        setVocalStems(stems);
        const currV = vocalAnalysisRef.current;
        if (currV) {
          const refined = refineAnalysisWithDemucsStems(currV, stems, deckBKnownBpmRef.current);
          vocalAnalysisRef.current = refined;
          setVocalAnalysis(refined);

          const iStems = demucsStemsRef.current;
          const iAnalysis = analysisRef.current;
          const iCfg = configRef.current;
          const rCfg = remixConfigRef.current;

          if (iStems && iAnalysis && iCfg) {
            const sync = alignVocalDeckToInstDeck(
              iStems,
              iAnalysis,
              iCfg.bpm,
              iCfg.firstDownbeatSec,
              null,
              stems,
              refined,
              refined.bpm,
              refined.firstDownbeatSec,
              refined.recommendedCue1Bar,
              rCfg.vocalTargetDropBar
            );
            setRemixConfig((prevRemix) => ({
              ...prevRemix,
              instStartBar: sync.recommendedInstStartBar,
              vocalBpm: refined.bpm,
              vocalFirstDownbeatSec: refined.firstDownbeatSec,
              vocalCueBar: refined.recommendedCue1Bar,
              vocalBeatShift: sync.beatShift,
              halfDoubleTime: sync.halfDoubleTime,
              vocalFineOffsetMs: sync.fineOffsetMs,
            }));
          } else {
            const bestMult = computeBestHalfDoubleTime(refined.bpm, targetInstBpm);
            setRemixConfig((prevRemix) => ({
              ...prevRemix,
              vocalBpm: refined.bpm,
              vocalFirstDownbeatSec: refined.firstDownbeatSec,
              vocalCueBar: refined.recommendedCue1Bar,
              vocalBeatShift: 0,
              halfDoubleTime: bestMult,
              vocalFineOffsetMs: 0,
            }));
          }
        }
      } catch (err) {
        if (err instanceof DOMException && err.name === 'AbortError') return;
        if (vocalDemucsReqIdRef.current !== reqId) return;
        setVocalError(
          err instanceof Error
            ? err.message
            : 'Demucs vocal extraction failed. Retry or try another track.'
        );
      } finally {
        if (vocalDemucsReqIdRef.current === reqId) {
          setIsSeparatingVocal(false);
          setVocalProgress(null);
        }
      }
    },
    []
  );

  const loadVocalBuffer = useCallback(
    (buffer: AudioBuffer, id: string, displayName: string, knownBpm?: number) => {
      if (vocalDemucsAbortRef.current) {
        vocalDemucsAbortRef.current.abort();
      }
      deckBKnownBpmRef.current = knownBpm;
      setVocalError(null);
      setVocalStems(null);
      setVocalTrackId(id);
      setVocalTrackName(displayName);
      setVocalBuffer(buffer);

      const vAnalysis = analyzeTrack(buffer, knownBpm);
      vocalAnalysisRef.current = vAnalysis;
      setVocalAnalysis(vAnalysis);
      const instBpm = config?.bpm ?? 120;
      const bestMult = computeBestHalfDoubleTime(vAnalysis.bpm, instBpm);
      setRemixConfig((prev) => ({
        ...prev,
        vocalBpm: vAnalysis.bpm,
        vocalFirstDownbeatSec: vAnalysis.firstDownbeatSec,
        vocalCueBar: vAnalysis.recommendedCue1Bar,
        vocalBeatShift: 0,
        halfDoubleTime: bestMult,
        vocalFineOffsetMs: 0,
      }));

      const pref = config?.demucsModelPreference ?? lastModelPrefRef.current;
      void runVocalDemucsSeparation(buffer, pref, instBpm);
    },
    [config?.bpm, config?.demucsModelPreference, runVocalDemucsSeparation]
  );

  const handleUploadVocalFile = async (file: File) => {
    setVocalError(null);
    try {
      const ctx = getAudioContext();
      const arrayBuf = await file.arrayBuffer();
      const decoded = await ctx.decodeAudioData(arrayBuf);
      const cleanName = file.name.replace(/\.[^/.]+$/, '');
      loadVocalBuffer(decoded, `vocal-file-${Date.now()}`, cleanName);
    } catch {
      setVocalError(
        'Could not decode vocal file. Please try a standard MP3, WAV, FLAC, M4A, or OGG file.'
      );
    }
  };

  const handleSelectVocalDemo = useCallback(
    (demoId: string) => {
      const spec = DEMO_TRACKS.find((d) => d.id === demoId);
      if (!spec) return;
      const buf = generateDemoTrackBuffer(spec.id);
      loadVocalBuffer(buf, spec.id, `${spec.title} — ${spec.artist}`, spec.bpm);
    },
    [loadVocalBuffer]
  );

  const loadAudioBuffer = useCallback(
    (
      buffer: AudioBuffer,
      id: string,
      displayName: string,
      knownBpm?: number,
      autoRunDemucs = true
    ) => {
      stopPlayback();
      if (demucsAbortRef.current) {
        demucsAbortRef.current.abort();
      }
      deckAKnownBpmRef.current = knownBpm;
      deckACustomEditedRef.current = false;
      setIsLoading(true);
      setErrorMessage(null);
      setDemucsStems(null);
      setDemucsError(null);
      setStemProgress(null);

      setTimeout(() => {
        try {
          const result = analyzeTrack(buffer, knownBpm);
          analysisRef.current = result;
          const initialConfig: IntroEditConfig = {
            bpm: result.bpm,
            firstDownbeatSec: result.firstDownbeatSec,
            cue1Bar: result.recommendedCue1Bar,
            cue1ExactSec: null,
            donorStartBar: result.recommendedDonorStartBar,
            donorStartExactSec: null,
            loopStructure: result.totalBars >= 8 ? '8-bar-continuous' : '4-bar-x2',
            demucsModelPreference: lastModelPrefRef.current,
            introArrangement: 'progressive-build',
            grooveLiftAmount: 0.45,
            transitionBlend: 'beat-blend',
            drumPunchBoost: 0.35,
            bassSwapEnabled: true,
            kickPreservationEnabled: true,
            phaseAwareMixing: true,
            phraseAwareTransition: true,
            stems: createDefaultStemsConfig(),
            cuts: [],
          };

          const editResult = renderDjIntroEdit(buffer, result, initialConfig, null);

          setTrackId(id);
          setTrackName(displayName);
          setSourceBuffer(buffer);
          setAnalysis(result);
          setConfig(initialConfig);
          setRendered(editResult);
          setActiveDeck('edit');
          setSourceGridMode('scrub');
          setCurrentTimeSec(0);
          playOffsetSecRef.current = 0;

          if (autoRunDemucs) {
            void runDemucsSeparation(buffer, initialConfig.demucsModelPreference);
          }
        } catch (err) {
          setErrorMessage(
            err instanceof Error ? err.message : 'Unable to analyze audio track.'
          );
        } finally {
          setIsLoading(false);
        }
      }, 20);
    },
    [stopPlayback, runDemucsSeparation]
  );

  useEffect(() => {
    const spec = DEMO_TRACKS[0];
    const buf = generateDemoTrackBuffer(spec.id);
    loadAudioBuffer(buf, spec.id, `${spec.title} — ${spec.artist}`, spec.bpm, true);

    return () => {
      if (demucsAbortRef.current) {
        demucsAbortRef.current.abort();
      }
      if (vocalDemucsAbortRef.current) {
        vocalDemucsAbortRef.current.abort();
      }
      stopPlayback();
      if (audioCtxRef.current) {
        void audioCtxRef.current.close();
      }
    };
  }, [loadAudioBuffer, stopPlayback]);

  // Re-render DJ Intro Edit & 4-Stem Mix whenever config or Demucs stems update
  useEffect(() => {
    if (!sourceBuffer || !analysis || !config) return;
    const timer = setTimeout(() => {
      const nextRendered = renderDjIntroEdit(sourceBuffer, analysis, config, demucsStems);
      setRendered(nextRendered);
    }, 35);
    return () => clearTimeout(timer);
  }, [sourceBuffer, analysis, config, demucsStems]);

  // Auto-initialize Deck B Vocal track on first open of Vocal Remix tab
  useEffect(() => {
    if (activeTab !== 'remix' || vocalBuffer) return;
    const fallbackSpec =
      DEMO_TRACKS.find((d) => d.id !== trackId) ?? DEMO_TRACKS[1] ?? DEMO_TRACKS[0];
    if (fallbackSpec) {
      handleSelectVocalDemo(fallbackSpec.id);
    }
  }, [activeTab, vocalBuffer, trackId, handleSelectVocalDemo]);

  // Render Beatmatched Vocal Remix whenever Deck A stems, Deck B vocal stems, or Remix settings update
  useEffect(() => {
    if (!demucsStems || !analysis || !config || !vocalStems) {
      setRenderedRemix(null);
      return;
    }
    const timer = setTimeout(() => {
      try {
        const next = renderBeatmatchedRemix(
          demucsStems,
          analysis,
          config.bpm,
          config.firstDownbeatSec,
          vocalStems,
          remixConfig
        );
        setRenderedRemix(next);
      } catch (err) {
        setVocalError(err instanceof Error ? err.message : 'Unable to render beatmatched remix.');
      }
    }, 45);
    return () => clearTimeout(timer);
  }, [demucsStems, analysis, config, vocalStems, remixConfig]);

  // Trigger Demucs re-separation only when the user changes the Demucs model preference
  useEffect(() => {
    if (!config || !sourceBuffer) return;
    if (config.demucsModelPreference !== lastModelPrefRef.current) {
      lastModelPrefRef.current = config.demucsModelPreference;
      void runDemucsSeparation(sourceBuffer, config.demucsModelPreference);
    }
  }, [config?.demucsModelPreference, sourceBuffer, runDemucsSeparation]);

  const handleUploadFile = async (file: File, stayOnCurrentTab = false) => {
    stopPlayback();
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const ctx = getAudioContext();
      const arrayBuf = await file.arrayBuffer();
      const decoded = await ctx.decodeAudioData(arrayBuf);
      const cleanName = file.name.replace(/\.[^/.]+$/, '');
      loadAudioBuffer(decoded, `file-${Date.now()}`, cleanName, undefined, true);
      if (!stayOnCurrentTab) {
        setActiveTab('studio');
      }
    } catch {
      setIsLoading(false);
      setErrorMessage(
        'Could not decode audio file. Please try a standard MP3, WAV, FLAC, M4A, or OGG file.'
      );
    }
  };

  const handleSelectDemo = (demoId: string, stayOnCurrentTab = false) => {
    const spec = DEMO_TRACKS.find((d) => d.id === demoId);
    if (!spec) return;
    const buf = generateDemoTrackBuffer(spec.id);
    loadAudioBuffer(buf, spec.id, `${spec.title} — ${spec.artist}`, spec.bpm, true);
    if (!stayOnCurrentTab) {
      setActiveTab('studio');
    }
  };

  const handleReanalyzeWithBpm = (nextBpm: number, nextDownbeatSec: number) => {
    if (!sourceBuffer) return;
    deckACustomEditedRef.current = true;
    deckAKnownBpmRef.current = nextBpm;
    const updatedAnalysis = analyzeTrack(sourceBuffer, nextBpm, nextDownbeatSec);
    setAnalysis(updatedAnalysis);
    setConfig((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        bpm: updatedAnalysis.bpm,
        firstDownbeatSec: updatedAnalysis.firstDownbeatSec,
        cue1Bar: Math.min(updatedAnalysis.totalBars - 1, prev.cue1Bar),
        donorStartBar: Math.min(
          Math.max(0, updatedAnalysis.totalBars - 4),
          prev.donorStartBar
        ),
      };
    });
  };

  const handleResetAuto = () => {
    if (!sourceBuffer) return;
    deckACustomEditedRef.current = false;
    deckAKnownBpmRef.current = undefined;
    const base = analyzeTrack(sourceBuffer);
    const fresh = demucsStems ? refineAnalysisWithDemucsStems(base, demucsStems) : base;
    setAnalysis(fresh);
    setConfig((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        bpm: fresh.bpm,
        firstDownbeatSec: fresh.firstDownbeatSec,
        cue1Bar: fresh.recommendedCue1Bar,
        cue1ExactSec: null,
        donorStartBar: fresh.recommendedDonorStartBar,
        donorStartExactSec: null,
      };
    });
  };

  const handleAutoSyncRemix = useCallback(() => {
    if (!analysis || !config || !demucsStems || !vocalAnalysis || !vocalStems) return;
    const refinedVoc = refineAnalysisWithDemucsStems(
      vocalAnalysis,
      vocalStems,
      deckBKnownBpmRef.current
    );
    setVocalAnalysis(refinedVoc);
    const sync = alignVocalDeckToInstDeck(
      demucsStems,
      analysis,
      config.bpm,
      config.firstDownbeatSec,
      null,
      vocalStems,
      refinedVoc,
      refinedVoc.bpm,
      refinedVoc.firstDownbeatSec,
      refinedVoc.recommendedCue1Bar,
      remixConfig.vocalTargetDropBar
    );
    setRemixConfig((prev) => ({
      ...prev,
      instStartBar: sync.recommendedInstStartBar,
      vocalBpm: refinedVoc.bpm,
      vocalFirstDownbeatSec: refinedVoc.firstDownbeatSec,
      vocalCueBar: refinedVoc.recommendedCue1Bar,
      vocalBeatShift: sync.beatShift,
      vocalTargetDropBar: 0,
      vocalFineOffsetMs: sync.fineOffsetMs,
      halfDoubleTime: sync.halfDoubleTime,
      autoBeatmatch: true,
      phraseLockEnabled: true,
    }));
  }, [analysis, config, demucsStems, vocalAnalysis, vocalStems, remixConfig.vocalTargetDropBar]);

  const handleUpdateDonorStartBar = (barIdx: number, exactSec: number | null = null) => {
    deckACustomEditedRef.current = true;
    setConfig((prev) =>
      prev
        ? {
            ...prev,
            donorStartBar: barIdx,
            donorStartExactSec: exactSec,
          }
        : prev
    );
  };

  const handleExportWav = () => {
    if (!rendered || !config) return;
    if (!rendered.usingDemucsStems) {
      setErrorMessage(
        'Wait for Demucs 4-stem separation to finish before exporting so the output uses genuine Demucs-separated stems.'
      );
      return;
    }
    if (!rendered.qc.passed) {
      setErrorMessage(
        `Quality Control flagged an issue before export: ${rendered.qc.issues.join(' ')}`
      );
      setActiveTab('transition');
      return;
    }

    setErrorMessage(null);
    setIsExporting(true);
    setTimeout(() => {
      try {
        const blob = encodeAudioBufferToWav(rendered.buffer);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const safeTitle = trackName.replace(/[^a-zA-Z0-9_-]+/g, '_').replace(/^_|_$/g, '');
        a.href = url;
        a.download = `${safeTitle}_Demucs_8Bar_DJ_Intro_${Math.round(config.bpm)}BPM.wav`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } finally {
        setIsExporting(false);
      }
    }, 20);
  };

  const toggleMasterMute = useCallback(() => {
    setMasterMuted((prev) => {
      if (prev && masterVolume === 0) {
        setMasterVolume(1.0);
      }
      return !prev;
    });
  }, [masterVolume]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement ||
        e.target instanceof HTMLSelectElement
      ) {
        return;
      }
      if (e.code === 'Space') {
        e.preventDefault();
        togglePlayPause();
      } else if (e.code === 'KeyM') {
        e.preventDefault();
        toggleMasterMute();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [togglePlayPause, toggleMasterMute]);

  const handleExportRemixWav = () => {
    if (!renderedRemix) return;
    if (!renderedRemix.passed) {
      setErrorMessage('Remix output failed clip/silence verification before export.');
      return;
    }
    setErrorMessage(null);
    setIsExporting(true);
    setTimeout(() => {
      try {
        const blob = encodeAudioBufferToWav(renderedRemix.buffer);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const safeInst = trackName.replace(/[^a-zA-Z0-9_-]+/g, '_').replace(/^_|_$/g, '');
        const safeVoc = vocalTrackName.replace(/[^a-zA-Z0-9_-]+/g, '_').replace(/^_|_$/g, '');
        a.href = url;
        a.download = `${safeInst}_x_${safeVoc}_Remix_${Math.round(renderedRemix.targetBpm)}BPM.wav`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      } finally {
        setIsExporting(false);
      }
    }, 20);
  };

  const activeDuration =
    activeDeck === 'remix' || activeDeck === 'remix-vocals' || activeDeck === 'remix-inst'
      ? renderedRemix?.totalDurationSec ?? 0
      : activeDeck === 'edit'
        ? rendered?.totalDurationSec ?? 0
        : analysis?.durationSec ?? 0;
  const activeBarSec =
    activeDeck === 'remix' || activeDeck === 'remix-vocals' || activeDeck === 'remix-inst'
      ? renderedRemix?.barSec ?? 2
      : activeDeck === 'edit'
        ? rendered?.barSec ?? 2
        : analysis?.barSec ?? 2;
  const activeBeatSec = activeBarSec / 4;
  const barOffset =
    activeDeck === 'edit' ||
    activeDeck === 'remix' ||
    activeDeck === 'remix-vocals' ||
    activeDeck === 'remix-inst'
      ? 0
      : config?.firstDownbeatSec ?? 0;
  const relSec = Math.max(0, currentTimeSec - barOffset);
  const liveBar = Math.floor(relSec / activeBarSec) + 1;
  const liveBeat = (Math.floor(relSec / activeBeatSec) % 4) + 1;

  return (
    <div className="min-h-screen bg-[#0B0D11] text-[#F1F5F9] flex flex-col">
      <TopBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onExportWav={activeTab === 'remix' ? handleExportRemixWav : handleExportWav}
        canExport={
          activeTab === 'remix'
            ? Boolean(renderedRemix?.passed) && !isSeparatingDemucs && !isSeparatingVocal
            : Boolean(rendered?.usingDemucsStems) && !isLoading && !isSeparatingDemucs
        }
        isExporting={isExporting}
        exportLabel={activeTab === 'remix' ? 'Export Remix WAV' : 'Export WAV'}
      />

      <main className="flex-1 w-full max-w-[1360px] mx-auto px-6 py-6 space-y-6">
        <section className="bg-[#12161F] border border-white/[0.08] rounded-lg px-5 py-4 flex flex-wrap items-center justify-between gap-5">
          <div className="min-w-0 space-y-1">
            <div className="flex items-center gap-3">
              <h1 className="text-lg font-bold text-slate-100 truncate max-w-md">
                {trackName}
              </h1>
              <input
                ref={fileInputRef}
                type="file"
                accept="audio/*,.mp3,.wav,.flac,.m4a,.aac,.ogg"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void handleUploadFile(file);
                  e.target.value = '';
                }}
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-300 bg-[#1B212E] border border-white/[0.08] rounded hover:bg-[#232B3B] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Upload className="w-3 h-3" />
                <span>Load Audio</span>
              </button>
            </div>
            {analysis && config && rendered && (
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 font-mono tabular-nums">
                <span className="text-slate-200">{config.bpm.toFixed(2)} BPM</span>
                <span aria-hidden="true">·</span>
                <span>8-Bar Intro ({rendered.introDurationSec.toFixed(2)}s)</span>
                <span aria-hidden="true">·</span>
                <span className="text-amber-400">Cue 1 at Bar {config.cue1Bar + 1}</span>
                <span aria-hidden="true">·</span>
                <span className={rendered.usingDemucsStems ? 'text-emerald-400' : 'text-amber-300'}>
                  {isSeparatingDemucs
                    ? stemProgress?.stage || 'Separating 4 stems with Demucs...'
                    : rendered.usingDemucsStems
                      ? demucsStems?.engineLabel || 'Demucs 4-Stem Ready'
                      : demucsError
                        ? 'Demucs Error (See Stem Panel)'
                        : 'Awaiting Demucs 4-Stem Separation'}
                </span>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <select
              aria-label="Select Studio Demo Track"
              value={DEMO_TRACKS.some((d) => d.id === trackId) ? trackId : ''}
              onChange={(e) => {
                if (e.target.value) handleSelectDemo(e.target.value);
              }}
              className="px-3 py-2 text-xs font-medium text-slate-200 bg-[#0B0D11] border border-white/[0.1] rounded-md focus:outline-none focus:border-amber-500 cursor-pointer"
            >
              {!DEMO_TRACKS.some((d) => d.id === trackId) && (
                <option value="">Custom Uploaded Track</option>
              )}
              {DEMO_TRACKS.map((d) => (
                <option key={d.id} value={d.id}>
                  Demo: {d.title} ({d.bpm} BPM)
                </option>
              ))}
            </select>

            <div className="inline-flex items-center p-0.5 bg-[#0B0D11] border border-white/[0.08] rounded-md">
              <button
                type="button"
                onClick={() => {
                  if (activeDeck !== 'edit') {
                    if (isPlaying) {
                      startPlaybackAt('edit', 0, false);
                    } else {
                      setActiveDeck('edit');
                      setCurrentTimeSec(0);
                    }
                  }
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeDeck === 'edit'
                    ? 'bg-emerald-500 text-[#0B0D11] font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                DJ Intro Edit
              </button>
              <button
                type="button"
                disabled={!demucsStems}
                onClick={() => {
                  if (activeDeck !== 'stems-mix') {
                    if (isPlaying) {
                      startPlaybackAt('stems-mix', 0, false);
                    } else {
                      setActiveDeck('stems-mix');
                      setCurrentTimeSec(0);
                    }
                  }
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-40 ${
                  activeDeck === 'stems-mix'
                    ? 'bg-sky-500 text-[#0B0D11] font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                4-Stem Mix
              </button>
              <button
                type="button"
                onClick={() => {
                  if (activeDeck !== 'original') {
                    if (isPlaying) {
                      startPlaybackAt('original', 0, false);
                    } else {
                      setActiveDeck('original');
                      setCurrentTimeSec(0);
                    }
                  }
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeDeck === 'original'
                    ? 'bg-[#252D3D] text-slate-100 font-semibold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Original Track
              </button>
            </div>

            <div className="px-3 py-1.5 bg-[#0B0D11] border border-white/[0.08] rounded-md font-mono text-xs flex items-center gap-2.5">
              <span
                className={
                  liveBar <= 8 && activeDeck === 'edit'
                    ? 'text-emerald-400 font-semibold'
                    : 'text-amber-400 font-semibold'
                }
              >
                BAR {String(liveBar).padStart(2, '0')}.{liveBeat}
              </span>
              <span className="text-slate-500">|</span>
              <span className="text-slate-300">
                {formatClock(currentTimeSec)} / {formatClock(activeDuration)}
              </span>
            </div>

            <button
              type="button"
              onClick={() => {
                const nextLoop = !loopSeamMode;
                setLoopSeamMode(nextLoop);
                if (nextLoop && rendered) {
                  const seamStart = Math.max(0, rendered.introDurationSec - rendered.barSec * 2);
                  startPlaybackAt('edit', seamStart, true);
                } else if (isPlaying) {
                  startPlaybackAt(activeDeck, currentTimeSec, false);
                }
              }}
              title="Loop Bars 7–10 around the Cue 1 transition"
              className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-md border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                loopSeamMode
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-[#1B212E] text-slate-300 border-white/[0.08] hover:bg-[#232B3B]'
              }`}
            >
              <Repeat className="w-3.5 h-3.5" />
              <span>Loop Seam</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setLoopSeamMode(false);
                if (isPlaying) {
                  startPlaybackAt(activeDeck, 0, false);
                } else {
                  setCurrentTimeSec(0);
                  playOffsetSecRef.current = 0;
                }
              }}
              aria-label="Return to start"
              className="p-2 text-slate-300 bg-[#1B212E] border border-white/[0.08] rounded-md hover:bg-[#232B3B] transition-colors cursor-pointer"
            >
              <SkipBack className="w-4 h-4" />
            </button>

            <div
              className="flex items-center gap-2 px-2.5 py-1.5 bg-[#0B0D11] border border-white/[0.08] rounded-md"
              title="Master Monitor Volume (0%–150%, peak-limited; double-click slider to reset to 100%, or press M to mute). Does not alter exported WAV levels."
            >
              <button
                type="button"
                onClick={toggleMasterMute}
                aria-label={masterMuted || masterVolume === 0 ? 'Unmute master output' : 'Mute master output'}
                className={`p-0.5 rounded transition-colors cursor-pointer ${
                  masterMuted || masterVolume === 0
                    ? 'text-red-400 hover:text-red-300'
                    : masterVolume > 1.01
                      ? 'text-amber-400 hover:text-amber-300'
                      : 'text-slate-300 hover:text-white'
                }`}
              >
                {masterMuted || masterVolume === 0 ? (
                  <VolumeX className="w-3.5 h-3.5" />
                ) : masterVolume <= 0.5 ? (
                  <Volume1 className="w-3.5 h-3.5" />
                ) : (
                  <Volume2 className="w-3.5 h-3.5" />
                )}
              </button>

              <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 hidden sm:inline">
                Master
              </span>

              <input
                type="range"
                aria-label="Master Volume"
                min={0}
                max={1.5}
                step={0.01}
                value={masterMuted ? 0 : masterVolume}
                onDoubleClick={() => {
                  setMasterMuted(false);
                  setMasterVolume(1.0);
                }}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setMasterVolume(val);
                  if (masterMuted && val > 0) setMasterMuted(false);
                }}
                className="w-24 accent-amber-500 cursor-pointer"
              />

              <span
                className={`font-mono text-[11px] tabular-nums w-11 text-right ${
                  masterMuted || masterVolume === 0
                    ? 'text-red-400'
                    : masterVolume > 1.01
                      ? 'text-amber-400 font-semibold'
                      : 'text-slate-200'
                }`}
              >
                {masterMuted || masterVolume === 0
                  ? 'MUTE'
                  : `${Math.round(masterVolume * 100)}%`}
              </span>

              <div className="flex items-end gap-0.5 h-3.5 pl-1 border-l border-white/[0.08]" aria-hidden="true">
                {[1, 2, 3, 4, 5, 6].map((seg) => {
                  const active = masterMeterLevel >= seg;
                  const segColor = !active
                    ? 'bg-slate-800'
                    : seg === 6
                      ? 'bg-red-400'
                      : seg >= 5
                        ? 'bg-amber-400'
                        : 'bg-emerald-400';
                  return (
                    <span
                      key={seg}
                      className={`w-1 h-3 rounded-xs transition-colors ${segColor}`}
                    />
                  );
                })}
              </div>
            </div>

            <button
              type="button"
              onClick={togglePlayPause}
              disabled={isLoading || !rendered}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-[#0B0D11] bg-slate-100 rounded-md hover:bg-white disabled:opacity-40 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  <span>Pause</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Play</span>
                </>
              )}
            </button>
          </div>
        </section>

        {errorMessage && (
          <div className="bg-red-500/10 border border-red-500/30 text-red-200 text-xs px-4 py-3 rounded-md">
            {errorMessage}
          </div>
        )}

        {isLoading || !analysis || !config || !rendered ? (
          <div className="bg-[#12161F] border border-white/[0.08] rounded-lg p-12 text-center space-y-2">
            <div className="text-sm font-medium text-slate-200">
              Analyzing tempo, beat grid, and preparing Demucs 4-stem separation...
            </div>
            <div className="text-xs text-slate-400">
              Detecting locked BPM, downbeat phase, Cue 1 first verse entry, and separating Vocals, Drums, Bass & Other via Demucs.
            </div>
          </div>
        ) : (
          <>
            {activeTab === 'studio' && (
              <div className="space-y-6">
                <WaveformTimeline
                  sourceBuffer={sourceBuffer}
                  demucsStems={demucsStems}
                  isSeparatingDemucs={isSeparatingDemucs}
                  analysis={analysis}
                  config={config}
                  rendered={rendered}
                  activeDeck={activeDeck}
                  gridMode={sourceGridMode}
                  currentTimeSec={currentTimeSec}
                  isPlaying={isPlaying}
                  onChangeGridMode={handleChangeSourceGridMode}
                  onSeek={(deck, sec, autoPlay = true, monitorOverride) => {
                    setLoopSeamMode(false);
                    if (autoPlay) {
                      startPlaybackAt(deck, sec, false, monitorOverride);
                    } else {
                      stopPlayback();
                      setActiveDeck(deck);
                      const maxDur =
                        deck === 'edit'
                          ? rendered?.totalDurationSec ?? sec
                          : sourceBuffer?.duration ?? sec;
                      const clamped = Math.max(0, Math.min(maxDur - 0.02, sec));
                      playOffsetSecRef.current = clamped;
                      setCurrentTimeSec(clamped);
                    }
                  }}
                  onToggleOriginalPlay={() => {
                    setLoopSeamMode(false);
                    if (isPlaying && activeDeck === 'original') {
                      if (audioCtxRef.current) {
                        const elapsed =
                          audioCtxRef.current.currentTime -
                          playStartCtxTimeRef.current +
                          playOffsetSecRef.current;
                        playOffsetSecRef.current = elapsed;
                        setCurrentTimeSec(elapsed);
                      }
                      stopPlayback();
                    } else {
                      const defaultStart =
                        sourceGridMode === 'cue1'
                          ? config.cue1ExactSec ??
                            config.firstDownbeatSec + config.cue1Bar * analysis.barSec
                          : sourceGridMode === 'donor'
                            ? config.donorStartExactSec ??
                              config.firstDownbeatSec + config.donorStartBar * analysis.barSec
                            : 0;
                      const startAt = activeDeck === 'original' ? currentTimeSec : defaultStart;
                      startPlaybackAt(
                        'original',
                        startAt,
                        false,
                        gridModeToMonitor(sourceGridMode)
                      );
                    }
                  }}
                  onUpdateCue1Bar={(barIdx, exactSec = null) => {
                    deckACustomEditedRef.current = true;
                    setConfig((p) =>
                      p ? { ...p, cue1Bar: barIdx, cue1ExactSec: exactSec } : p
                    );
                  }}
                  onUpdateDonorStartBar={handleUpdateDonorStartBar}
                />

                <DemucsStemEditor
                  analysis={analysis}
                  config={config}
                  stemSet={demucsStems}
                  capabilities={capabilities}
                  isSeparating={isSeparatingDemucs}
                  progress={stemProgress}
                  demucsError={demucsError}
                  activeDeck={activeDeck}
                  currentTimeSec={currentTimeSec}
                  isPlaying={isPlaying}
                  onChangeConfig={(updater) =>
                    setConfig((p) => (p ? updater(p) : p))
                  }
                  onRunDemucs={() => {
                    if (sourceBuffer && config) {
                      void runDemucsSeparation(sourceBuffer, config.demucsModelPreference);
                    }
                  }}
                  onSeek={(deck, sec, autoPlay = true) => {
                    setLoopSeamMode(false);
                    if (autoPlay) {
                      startPlaybackAt(deck, sec, false);
                    } else {
                      stopPlayback();
                      setActiveDeck(deck);
                      setCurrentTimeSec(sec);
                    }
                  }}
                />

                <EditControlsPanel
                  analysis={analysis}
                  config={config}
                  stemSet={demucsStems}
                  onChangeConfig={(updater) =>
                    setConfig((p) => (p ? updater(p) : p))
                  }
                  onResetAuto={handleResetAuto}
                  onReanalyzeWithBpm={handleReanalyzeWithBpm}
                />
              </div>
            )}

            {activeTab === 'remix' && (
              <RemixStudioView
                instTrackId={trackId}
                instTrackName={trackName}
                instAnalysis={analysis}
                instBpm={config.bpm}
                instFirstDownbeatSec={config.firstDownbeatSec}
                instStems={demucsStems}
                instIsSeparating={isSeparatingDemucs}
                instProgress={stemProgress}
                instError={demucsError}
                onUploadInstFile={(file) => void handleUploadFile(file, true)}
                onSelectInstDemo={(demoId) => handleSelectDemo(demoId, true)}
                onRetryInstDemucs={() => {
                  if (sourceBuffer) {
                    void runDemucsSeparation(sourceBuffer, config.demucsModelPreference);
                  }
                }}
                vocalTrackId={vocalTrackId}
                vocalTrackName={vocalTrackName}
                vocalAnalysis={vocalAnalysis}
                vocalStems={vocalStems}
                vocalIsSeparating={isSeparatingVocal}
                vocalProgress={vocalProgress}
                vocalError={vocalError}
                onUploadVocalFile={(file) => void handleUploadVocalFile(file)}
                onSelectVocalDemo={handleSelectVocalDemo}
                onRetryVocalDemucs={() => {
                  if (vocalBuffer) {
                    void runVocalDemucsSeparation(
                      vocalBuffer,
                      config.demucsModelPreference,
                      config.bpm
                    );
                  }
                }}
                remixConfig={remixConfig}
                renderedRemix={renderedRemix}
                activeDeck={activeDeck}
                currentTimeSec={currentTimeSec}
                isPlaying={isPlaying}
                isExporting={isExporting}
                beatClickEnabled={beatClickEnabled}
                onToggleBeatClick={() => setBeatClickEnabled((v) => !v)}
                onAutoSyncRemix={handleAutoSyncRemix}
                onChangeConfig={(updater) => setRemixConfig((p) => updater(p))}
                onSeekRemix={(mode, sec, autoPlay = true) => {
                  setLoopSeamMode(false);
                  if (autoPlay) {
                    startPlaybackAt(mode, sec, false);
                  } else {
                    stopPlayback();
                    setActiveDeck(mode);
                    setCurrentTimeSec(sec);
                  }
                }}
                onStopPlayback={stopPlayback}
                onExportRemixWav={handleExportRemixWav}
              />
            )}

            {activeTab === 'transition' && (
              <TransitionCheckView
                analysis={analysis}
                config={config}
                rendered={rendered}
                stemSet={demucsStems}
                isPlaying={isPlaying}
                activeDeck={activeDeck}
                currentTimeSec={currentTimeSec}
                onPlaySeamWindow={() => {
                  const seamStart = Math.max(
                    0,
                    rendered.introDurationSec - rendered.barSec * 2
                  );
                  setLoopSeamMode(true);
                  startPlaybackAt('edit', seamStart, true);
                }}
                onStop={() => {
                  setLoopSeamMode(false);
                  stopPlayback();
                }}
              />
            )}

            {activeTab === 'library' && (
              <TrackSourceView
                currentTrackId={trackId}
                currentTrackName={trackName}
                onUploadFile={(file) => void handleUploadFile(file)}
                onSelectDemo={handleSelectDemo}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}
